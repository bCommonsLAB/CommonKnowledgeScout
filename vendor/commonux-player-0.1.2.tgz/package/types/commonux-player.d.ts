/**
 * `CommonUxPlayer` — die Wurzelkomponente für Gastgeber (R-PLAYER-VERTRAG-001).
 *
 * Ein Gastgeber übergibt eine Aufführung als HumanUX-v2-JSON und bekommt eine Bühne, die sie
 * abspielt: ab der ersten Seite (oder `startSeite`), Klicks führen von Bühne zu Bühne. Was der
 * Player nicht weiß, reicht der Gastgeber herein: Seitenquelle, Einhängepunkte, Basisadresse.
 *
 * Alles liegt in einem Rahmen mit der Klasse `commonux-player`, auch die Overlays
 * (R-PLAYER-RAHMEN-001); die Stile des Players wirken nur darin (R-PLAYER-STIL-001). Der Rahmen
 * füllt seinen Platz — die Größe bestimmt der Gastgeber.
 */
import { type CSSProperties } from "react";
import type { CssViewportFitMode } from "./stage/css-layout";
import type { PlayerEinhaengen } from "./state/player-einhaengen";
import type { Seitenquelle } from "./state/seitenquelle";
/** Was ein Klick auf einen Darsteller dem Gastgeber meldet (R-PLAYER-VERTRAG-002). */
export interface DarstellerKlick {
    darstellerId: string;
    seiteId: string | null;
}
export interface CommonUxPlayerProps {
    /** Die Aufführung: HumanUX-v2-JSON als Objekt oder als Text. */
    szene: unknown;
    /** ID der Seite, mit der die Wiedergabe beginnt. Ohne: die erste. Unbekannt: Fehler im Rahmen. */
    startSeite?: string;
    /** Woher Seiten kommen, die nicht in der Szene stehen (R-PLAYER-SEITENQUELLE-001). */
    seitenquelle?: Seitenquelle;
    /** Regeln des Gastgebers (R-PLAYER-EINHAENGEN-001). */
    einhaengen?: PlayerEinhaengen;
    /** Ein Darsteller wurde geklickt (R-PLAYER-VERTRAG-002). */
    onDarstellerKlick?: (klick: DarstellerKlick) => void;
    /**
     * Basisadresse für Pfade, die mit `/` beginnen (R-PLAYER-VERTRAG-003). Gilt beim Montieren; wer
     * sie ändert, gibt der Komponente einen neuen `key`.
     */
    assetBasis?: string;
    /** `contain` (Standard): ganzes Sichtfeld mit Rändern; `cover`: füllt den Rahmen (R-PLAYER-VERTRAG-004). */
    einpassen?: CssViewportFitMode;
    /** Kein eigener Hintergrund: der Gastgeber scheint durch (R-PLAYER-VERTRAG-004). */
    durchsichtig?: boolean;
    /** Zusätzliche Klassen und Stile für den Rahmen. */
    className?: string;
    style?: CSSProperties;
}
export declare function CommonUxPlayer(props: CommonUxPlayerProps): import("react/jsx-runtime").JSX.Element;
