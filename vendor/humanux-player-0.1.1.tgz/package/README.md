# @humanux/player

Der HumanUX Player spielt eine Aufführung ab: Bühnen, Darsteller, Übergänge, Medien. In
diesem Repo nutzen ihn Commoning Methods und der Editor als Quelltext. Fremde Anwendungen
bauen ihn als Bündel ein (`humanux-player-<version>.tgz`).

Regeln: [`docs/specs/entity-player.md`](../../docs/specs/entity-player.md).

## Einbau (React 18 oder 19, z. B. Next.js App Router)

```bash
npm install ./humanux-player-0.1.1.tgz
# pnpm add ./humanux-player-0.1.1.tgz
```

```tsx
import "@humanux/player/styles.css";
import { HumanUxPlayer } from "@humanux/player";
import szene from "./meine-auffuehrung.json";

export function Hintergrund() {
  return (
    <div style={{ position: "fixed", inset: 0 }}>
      <HumanUxPlayer
        szene={szene}
        einpassen="cover"
        durchsichtig
        assetBasis="https://bilder.example.org"
        onDarstellerKlick={({ darstellerId, seiteId }) => console.log(darstellerId, seiteId)}
      />
    </div>
  );
}
```

| Prop | Bedeutung |
|---|---|
| `szene` | Die Aufführung als HumanUX-v2-JSON, als Objekt oder Text. Pflicht. |
| `startSeite` | ID der ersten Bühne. Ohne: die erste der Aufführung. |
| `seitenquelle` | Woher Bühnen kommen, die nicht in `szene` stehen: `{ naechsteSeite, seite }`. Ohne: alle stehen in `szene`. |
| `einhaengen` | Regeln des Gastgebers, z. B. welches Medium nach einer Navigation öffnet. |
| `onDarstellerKlick` | Meldet jeden angenommenen Klick: `{ darstellerId, seiteId }`. |
| `assetBasis` | Basisadresse für Pfade, die mit `/` beginnen (Bilder, SVG-Formen, Medien, Symbole des Players). Gilt beim Montieren. |
| `einpassen` | `contain` (Standard, ganzes Sichtfeld) oder `cover` (füllt den Rahmen). |
| `durchsichtig` | Kein eigener Hintergrund; der Gastgeber scheint durch. |
| `className`, `style` | Für den Rahmen. |

- Der Rahmen `.humanux-player` füllt seinen Platz; die Größe gibt der Gastgeber vor.
- Alle Stile liegen unter `.humanux-player`, auch die der Overlays, und wirken nicht auf die übrige
  Seite. Dunkles Design folgt der Klasse `dark` an einem Vorfahren.
- **Schriften** bringt der Gastgeber mit. Die Textarten nutzen `Metropolitano` und
  `Mazius Display`; fehlen sie, greift die Ersatzschrift. Eigene Familien setzt man an
  `.humanux-player` über `--textart-<id>-family`.
- Eine ungültige Aufführung zeigt die Komponente als Meldung im Rahmen und in der Konsole.
- `@humanux/player/format` liefert Schema, Compiler und Leser ohne React — für Server-Code.

## Bauen (in diesem Repo)

```bash
npm run pack:datei --workspace @humanux/player
```

Das erzeugt `packages/humanux-player/dist/` und `packages/humanux-player/humanux-player-0.1.1.tgz`.
Der Bau bricht ab, wenn eine Regel der Stile außerhalb von `.humanux-player` liegt.

**Ein neues Bündel bekommt eine neue Version** (`version` in `package.json`). Next.js hält Pakete
in `node_modules` für unveränderlich, solange Name und Version gleich bleiben, und nimmt sonst das
alte Bündel aus seinem Cache (`.next/cache`).

## Lizenz

AGPL-3.0-or-later, siehe `LICENSE`. Wer den Player in einer Anwendung im Netz betreibt und
ihn verändert, muss den veränderten Quelltext den Nutzer:innen zugänglich machen.
