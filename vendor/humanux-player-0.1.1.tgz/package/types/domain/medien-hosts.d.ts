/**
 * Hosts, von denen Inhaltsbilder und PDFs kommen dürfen, obwohl sie nicht in `public/` liegen:
 * der Speicher von KnowledgeScout (Konzept, Abschnitt 8.2). EINE Liste für die Zuordnung (welche
 * Adressen angenommen werden) und für die Bühne (welche Bildadressen gezeichnet werden).
 *
 * Bewusst eine Konstante und keine Umgebungsvariable: Die Bühne prüft im Browser, und Werte aus
 * der Umgebung des Containers kommen dort nicht an. Eine Liste, die Server und Browser
 * verschieden lesen, ließe Bilder zu, die dann nicht gezeichnet werden.
 * Spec: docs/specs/entity-manifest.md (R-MANIFEST-KS-MEDIA-HOST-001, -002).
 */
export declare const ERLAUBTE_MEDIEN_HOSTS: readonly string[];
/** True, wenn `adresse` eine `https://`-Adresse eines erlaubten Hosts ist. Vergleich ohne Groß/Klein. */
export declare function istErlaubteMedienAdresse(adresse: string, hosts?: readonly string[]): boolean;
