import type { ElementProps } from "./scene-schema";
import { type HumanUxComposedMotionSpec } from "./humanux-motion";
export type TransitionValueKind = "continuous" | "hard-switch";
export type TransitionAnchorKind = "start" | "exit" | "enter" | "end";
export interface HumanuxTransitionGraphNode {
    kind: TransitionAnchorKind;
    props: ElementProps;
    keys: ReadonlyArray<keyof ElementProps>;
}
export interface HumanuxTransitionPropertySegment {
    fromProps: ElementProps;
    toProps: ElementProps;
    valueKind: TransitionValueKind;
}
export interface HumanuxTransitionGraph {
    start: HumanuxTransitionGraphNode;
    end: HumanuxTransitionGraphNode;
    anchors?: ReadonlyArray<HumanuxTransitionGraphNode>;
    motionSpec?: HumanUxComposedMotionSpec;
}
export declare function collectAnimatedKeys(graph: HumanuxTransitionGraph): ReadonlyArray<keyof ElementProps>;
export declare function buildPropertySegmentsForKey(graph: HumanuxTransitionGraph, key: keyof ElementProps): HumanuxTransitionPropertySegment[];
export declare function evaluateTransitionGraph(graph: HumanuxTransitionGraph, progress: number): ElementProps;
