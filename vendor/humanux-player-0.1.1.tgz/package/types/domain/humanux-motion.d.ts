export type HumanUxMotionPathMode = "linear" | "bezier";
export type HumanUxMotionEasing = "linear" | "easeIn" | "easeOut" | "easeInOut";
export interface HumanUxBezierControlPoint {
    x: number;
    y: number;
}
/**
 * Phasennahe Motion-Vorgabe aus dem Authoring-Modell.
 * - `motionOut` kommt typischerweise aus `exit`
 * - `motionIn` kommt typischerweise aus `enter`
 */
export interface HumanUxMotionSpec {
    pathMode?: HumanUxMotionPathMode;
    easing?: HumanUxMotionEasing;
    bezierControl?: HumanUxBezierControlPoint;
}
/**
 * Bewegungsvorgabe bereinigen: nur gesetzte Felder bleiben; leer → `undefined` (Feld entfällt).
 * Bisher im Inspektor; jetzt der eine Weg für Editor und MCP-Brücke (Welle 0).
 */
export declare function bereinigeHumanUxBewegung(next: HumanUxMotionSpec): HumanUxMotionSpec | undefined;
export interface HumanUxComposedMotionSpec {
    pathMode: HumanUxMotionPathMode;
    easingOut: HumanUxMotionEasing;
    easingIn: HumanUxMotionEasing;
    bezierControlOut?: HumanUxBezierControlPoint;
    bezierControlIn?: HumanUxBezierControlPoint;
}
export declare const HUMANUX_DEFAULT_MOTION: HumanUxComposedMotionSpec;
export interface CatmullRomBezierSegment {
    from: HumanUxBezierControlPoint;
    cp1: HumanUxBezierControlPoint;
    cp2: HumanUxBezierControlPoint;
    to: HumanUxBezierControlPoint;
}
/**
 * Catmull-Rom-Spline durch alle Stuetzpunkte -> kubische Bezier-Segmente.
 * C1-stetig (keine Knicke). Bei nur 2 Punkten: Drittelregel-Fallback.
 * Randtangenten: gespiegelt (natuerliche Endpunkte).
 */
export declare function catmullRomToCubicBezierSegments(points: ReadonlyArray<HumanUxBezierControlPoint>): CatmullRomBezierSegment[];
export declare function composeMotionSpec(motionOut?: HumanUxMotionSpec, motionIn?: HumanUxMotionSpec): HumanUxComposedMotionSpec;
