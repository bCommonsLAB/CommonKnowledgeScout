import type { App, Page, RootObject } from "./scene-schema";
export declare class SceneParseError extends Error {
    constructor(message: string);
}
/** Eine Page aus JSON (z. B. API-Fragment) mit denselben Regeln wie `application.pages[]`. */
export declare function normalizeImportedPage(raw: unknown): Page;
export declare function parseRootObject(raw: unknown): RootObject;
/**
 * Füllt fehlendes onLoadProps bei Referenz-Elementen aus vorheriger Seite (onShow) ab.
 */
export declare function resolveOnLoadFromPreviousPages(app: App): App;
/**
 * Vollständiger Import-Pfad: parsen + Referenz-onLoad auflösen.
 */
export declare function normalizeSceneDocument(raw: unknown): RootObject;
/** Regel-Generator-Entwürfe → `Page` (Re-Export, Logik in `normalize-generated-page.ts`). */
export { normalizeGeneratedPageDraft } from "./normalize-generated-page";
