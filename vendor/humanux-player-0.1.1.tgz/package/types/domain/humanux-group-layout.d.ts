/**
 * Auto-Layout für direkte Kinder einer HumanUX-Gruppe (horizontal / vertikal / Kreis).
 * Wird beim Kompilieren angewendet; `mode: manual` oder fehlendes `layout` lässt Koordinaten unverändert.
 */
import type { SceneNode } from "./scene-schema";
import type { HumanUxApplication, HumanUxGroupDefinition, HumanUxGroupLayout, HumanUxGroupLayoutMode } from "./humanux-authoring-schema";
/** Normalisierte Werte für die Positionsberechnung. */
export type NormalizedHumanUxGroupLayout = {
    mode: "manual";
} | {
    mode: Exclude<HumanUxGroupLayoutMode, "manual">;
    gapX: number;
    gapY: number;
    originX: number;
    originY: number;
    radius: number;
    startAngleDeg: number;
    clockwise: boolean;
};
/**
 * Liefert ein normalisiertes Layout; unbekannte/fehlende Modi → manual (keine Änderung an Kindern).
 */
export declare function normalizeHumanUxGroupLayout(layout: HumanUxGroupLayout | undefined): NormalizedHumanUxGroupLayout;
/**
 * Effektives Layout: explizites `group.layout` schlägt `layoutStyleRef` → `application.groupLayoutStyles[key]`.
 */
export declare function resolveEffectiveGroupLayout(app: HumanUxApplication, def: HumanUxGroupDefinition): HumanUxGroupLayout | undefined;
/**
 * Wendet das Gruppen-Layout auf direkte Kinder an: pro Phase eigene Positionen (Größen können pro Phase variieren).
 */
export declare function applyGroupLayoutToSceneNodes(children: SceneNode[], layout: HumanUxGroupLayout | undefined): SceneNode[];
