/**
 * Die zwei Textarten der Methodenansicht nach Gesines Entwurf
 * (`260420 web-elemente.pdf`, S. 1 „Schriften"; Maße aus `260910 website-maße.pdf`).
 *
 * - **Fließtext** (Metropolitano): Stufen „Text" (light) und „Überschrift" (bold).
 * - **Auszeichnung** (Mazius Display, immer kursiv): alles, was kein Fließtext ist.
 *
 * Zentrale Quelle für Schrift, Schnitt, Größe und Zeilenhöhe. Größen stehen in
 * **Entwurfs-pt bei 1180 × 820** und werden daraus in JSON-`fontSize` bzw. Pixel im
 * Bühnenmaß umgerechnet — nie in `vw`/festen px.
 *
 * @see R-STYLE-TEXTARTEN-001 (docs/specs/entity-style.md)
 * @see docs/app-concept/PLAN-methodenansicht-runde-2.md — Tabelle „Sollgrößen"
 */
export type TextartFamilie = "fliesstext" | "auszeichnung";
export type TextartId = "fliesstext-text" | "fliesstext-ueberschrift" | "auszeichnung-light" | "auszeichnung-bold";
export type Textart = {
    id: TextartId;
    familie: TextartFamilie;
    /** Klarname für die Editor-UI (Bühnensprache, siehe docs/zielgruppe.md). */
    label: string;
    /** JSON-`fontFamily`-Alias, aufgelöst über `resolveCssFontFamilyForText`. */
    fontFamily: "Metropolitano" | "MaziusDisplay";
    /** CSS `font-weight`, passend zu den `@font-face`-Bereichen in `globals.css`. */
    fontWeight: 300 | 400 | 700;
    italic: boolean;
    /** Größe in Entwurfs-pt bei 1180 × 820 (entspricht px bei diesem Fenster). */
    sizePt: number;
    /** Zeilenhöhe als Faktor der Schriftgröße (CSS `line-height` ohne Einheit). */
    lineHeight: number;
};
/**
 * Entwurfs-Leinwand: 1180 × 820 pt deckt sich bei 1180 × 820 px exakt mit der App
 * (contain, Zoom 1) — Vorgänger-Handover, Abschnitt 0.
 */
export declare const DESIGN_CANVAS_PX: {
    readonly width: 1180;
    readonly height: 820;
};
/** `pxPerWorld` bei der Entwurfs-Leinwand (= 42.1429). */
export declare function designCanvasPxPerWorld(): number;
/**
 * Sollgrößen (Welle 0, Entscheidung der Nutzer:in 2026-09-24):
 * Fließtext 12 pt statt der gemessenen 9 pt (9 px wären am Bildschirm zu klein);
 * Zeilenhöhe behält Gesines Verhältnis 13/9. Auszeichnung wie gemessen.
 */
export declare const TEXTARTEN: Readonly<Record<TextartId, Textart>>;
export declare const TEXTART_IDS: TextartId[];
export declare function isTextartId(v: string): v is TextartId;
/** Entwurfs-pt → JSON-`fontSize` (Kehrwert von `scaleJsonFontSizeToDisplayWorld` bei 1180 × 820). */
export declare function jsonFontSizeFromDesignPt(pt: number): number;
/** JSON-`fontSize` der Textart (für Masken und Generator-Skripte). */
export declare function textartJsonFontSize(id: TextartId): number;
/** Schriftgröße in Welt-Einheiten — skaliert mit `pxPerWorld` wie jede Fläche. */
export declare function textartFontSizeWorld(id: TextartId): number;
/** Schriftgröße in px bei gegebenem `pxPerWorld` (Bühnenmaß, für DOM außerhalb der Bühne). */
export declare function textartFontSizePx(id: TextartId, pxPerWorld: number): number;
/** Name der CSS-Variablen einer Textart-Eigenschaft, z. B. `--textart-fliesstext-text-weight`. */
export declare function textartCssVarName(id: TextartId, prop: "family" | "weight" | "style" | "line-height"): string;
/** `ElementProps.textart` → Textart; `""` oder unbekannt → `undefined` (kein Fallback). R-STYLE-TEXTARTEN-002-EC-01. */
export declare function resolveTextart(value: string | undefined | null): Textart | undefined;
/** Schrift, Schnitt, Stil, Zeilenhöhe und Silbentrennung einer Textart als CSS-Eigenschaften (ohne Größe). */
export declare function textartCssProps(id: TextartId): {
    fontFamily: string;
    fontWeight: number;
    fontStyle: "italic" | "normal";
    lineHeight: number;
    hyphens: "none";
    WebkitHyphens: "none";
};
/** Schnitt für ausgezeichnete Inline-Stellen (`**fett**`) innerhalb einer Textart. */
export declare const TEXTART_INLINE_BOLD_WEIGHT = 700;
/**
 * Masken-Werte einer Textart für Inspektor und Generator-Skripte: setzt `textart`, `fontFamily`
 * (für Canvas/Schätzung) und `fontSize` (auf 3 Stellen gerundet) in einem Schritt.
 */
export declare function textartMaskPatch(id: TextartId): {
    textart: TextartId;
    fontFamily: Textart["fontFamily"];
    fontSize: number;
};
