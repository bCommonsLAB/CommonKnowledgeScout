import type { EditPhase, Element, ElementProps, SceneGroupNode } from "./scene-schema";
/** Knoten mit Phasen-Props (Entity-Blatt oder Gruppen-Container). */
export type ElementPhaseNode = Element | SceneGroupNode;
/** Props-Snapshot für die angegebene Phase (nach Normalisierung hat onLoad immer Werte). */
export declare function getPropsForPhase(el: ElementPhaseNode, phase: EditPhase): ElementProps;
