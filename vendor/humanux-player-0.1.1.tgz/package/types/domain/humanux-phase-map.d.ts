import type { EditPhase } from "./scene-schema";
/** Editor v2: gewählte Autoren-Phase (HumanUX v2 `entityStates`). */
export type HumanUxEditPhase = "enter" | "active" | "exit";
/** Phasen-Labels ↔ Laufzeit-`Element`-Phasen für CssStage / getPropsForPhase. */
export declare function humanUxPhaseToEditPhase(phase: HumanUxEditPhase): EditPhase;
/** Umkehrabbildung fuer Preview/Editor-Synchronisation. */
export declare function editPhaseToHumanUxPhase(phase: EditPhase): HumanUxEditPhase;
