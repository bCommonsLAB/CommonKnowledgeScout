import type { EditPhase, ElementProps } from "./scene-schema";
import { type HumanuxTransitionIntent } from "./humanux-transition-intent";
import type { PreviewPhaseNode, PreviewTransitionFrame, TransitionSide } from "../stage/preview-transition-frames";
export declare function resolveNodeTransitionFrame(node: PreviewPhaseNode, fromPhase: EditPhase, toPhase: EditPhase): PreviewTransitionFrame;
export declare function resolveCrossPageNodeTransitionFrame(fromNode: PreviewPhaseNode | undefined, toNode: PreviewPhaseNode | undefined, fromPhase: EditPhase, toPhase: EditPhase): PreviewTransitionFrame | null;
/**
 * Remappt den globalen Progress (0..1) fuer einseitige Cross-Page-Elemente:
 * - "exit-only": Animation laeuft in der ersten Haelfte (0→0.5 → remapped 0→1)
 * - "enter-only": Animation laeuft in der zweiten Haelfte (0.5→1 → remapped 0→1)
 * - undefined: kein Remapping (Element auf beiden Seiten)
 */
export declare function remapProgressForSide(progress: number, side: TransitionSide | undefined): number;
export declare function evaluateTransitionProps(frame: PreviewTransitionFrame, progress: number): ElementProps;
export declare function buildEditorScrubTransitionIntent(linear: number, pageCount: number): HumanuxTransitionIntent | null;
