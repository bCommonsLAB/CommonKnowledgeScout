/**
 * Lineare Zeitleiste: Views × 3 Phasen (enter/active/exit) — gemeinsam für Timeline-UI und Scrub-Interpolation.
 */
import type { HumanUxEditPhase } from "./humanux-phase-map";
export declare const TIMELINE_PHASES: readonly HumanUxEditPhase[];
export declare const TIMELINE_PHASES_PER_VIEW: number;
export declare function linearIndex(viewIndex: number, phase: HumanUxEditPhase): number;
export declare function fromLinear(linear: number): {
    viewIndex: number;
    phase: HumanUxEditPhase;
};
/** Letzter gültiger Index für `pageCount` Views (je 3 Phasen). */
export declare function maxTimelineLinearIndex(pageCount: number): number;
