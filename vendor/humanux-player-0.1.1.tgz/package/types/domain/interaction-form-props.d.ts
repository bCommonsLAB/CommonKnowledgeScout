import type { ElementProps } from "./scene-schema";
export type FormInteractionKind = "none" | "hover" | "pressed" | "open";
/**
 * Priorität: offen > gedrückt > Hover; während Drag dieses Elements kein Interaktions-Override
 * (ruhige Anzeige). `openId` = Darsteller, dessen Media-Overlay offen ist
 * (R-ENTITY-MEDIA-OVERLAY-ACTIVE-STATE-002).
 */
export declare function computeFormInteractionKind(elementId: string, hoveredId: string | null, pressedId: string | null, draggingId: string | null, openId?: string | null, 
/** Zurück-Knopf, solange kein Bühnenmedium offen ist (R-ENTITY-MEDIA-STAGE-ROLE-001). */
restoreAktiv?: boolean): FormInteractionKind;
/**
 * Normalisiert einen SVG-Pfad-Override wie im Editor (`svg:/…` oder `/…svg`).
 */
export declare function normalizeInteractionSvgShapeInput(raw: string): string;
/**
 * Effektive `ElementProps` für Rendering: nur `materialColor`, `transparency`, bei SVG `shape`.
 * Alle anderen Felder bleiben von `base`.
 */
export declare function mergeFormInteractionProps(base: ElementProps, kind: FormInteractionKind): ElementProps;
/** Erlaubte Werte für `interactionBlendMode` (R-STYLE-INTERACTION-BLEND-001). */
export declare const INTERACTION_BLEND_MODES: readonly ["", "multiply"];
/**
 * CSS `mix-blend-mode` des Quads: nur bei Hover/Klick und nur mit gesetztem, bekanntem Modus.
 * In Ruhe und „offen" nie — ein weißes Ruhe-Icon würde multipliziert verschwinden.
 */
export declare function interactionBlendModeFor(props: Pick<ElementProps, "interactionBlendMode">, kind: FormInteractionKind): "multiply" | undefined;
/** Wird das Quad bei offenem Overlay ausgeblendet? Nur ohne Aktiv-Bild (Ohr-Player). */
export declare function hidesQuadWhileOpen(props: Pick<ElementProps, "shape" | "openSvgShape">): boolean;
/**
 * Weicht der Darsteller einem offenen Bühnenmedium (`mediaStageRole: "yield"`)? Dann ist er
 * ausgeblendet, solange irgendein Medium offen ist. R-ENTITY-MEDIA-STAGE-ROLE-001.
 */
export declare function weichtBuehnenmedium(props: Pick<ElementProps, "mediaStageRole">, mediumOffen: boolean): boolean;
/**
 * Reine Kulisse (`mediaStageRole: "backdrop"`)? Dann ist der Darsteller nie Bedien-Ziel — kein
 * Hover, kein Klick, Klicks fallen durch — und weicht wie `"yield"` einem offenen Medium.
 * R-ENTITY-MEDIA-STAGE-ROLE-001.
 */
export declare function istBuehnenKulisse(props: Pick<ElementProps, "mediaStageRole">): boolean;
/**
 * Ist der Zurück-Knopf (`mediaStageRole: "restore"`) aktiv? Ja, solange KEIN Medium offen ist —
 * dann ist die Bühne mit ihrem eigenen Inhalt zu sehen. R-ENTITY-MEDIA-STAGE-ROLE-001.
 */
export declare function holtBuehneZurueckAktiv(props: Pick<ElementProps, "mediaStageRole">, mediumOffen: boolean): boolean;
