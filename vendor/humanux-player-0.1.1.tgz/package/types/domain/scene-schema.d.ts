import type { HumanUxMotionSpec } from "./humanux-motion";
/**
 * Domänenmodell für Szenen-JSON (Laufzeit, Legacy-kompatibel).
 * HumanUX v2 (Autor:innen): `docs/humanux-v2/` → Kompilat nach `RootObject` via `humanux-compiler.ts`.
 * Ältere Fachdoku: `docs/scene description editor/scene-description-spec-1.0/` (teils archiviert).
 */
export interface RootObject {
    application: App;
}
export interface App {
    id: string;
    name: string;
    /** Optional: Vorgabe für `ElementProps.fontFamily`, wenn dort leer (`""`). */
    defaultFontFamily?: string;
    pages: Page[];
}
export interface Element {
    id: string;
    name: string;
    className: string | null;
    draggable: boolean;
    posConstX: boolean;
    posConstY: boolean;
    rotConstZ: boolean;
    /** Legacy: Trigger-Flag, nicht „Collider ja/nein“. */
    collision: boolean;
    onLoadProps: ElementProps | null;
    onShowProps: ElementProps;
    onLeaveProps: ElementProps;
    /** HumanUX v2 Preview: markiert, welche Phasen echte Roh-Keyframes haben. */
    previewPhaseHints?: PreviewPhaseHints;
    /** HumanUX v2 Preview: optionale Regie-Motion je Phase (enter/exit). */
    previewPhaseMotionHints?: PreviewPhaseMotionHints;
    /** Durchgereichte Media-URL aus der Entity-Definition. */
    mediaUrl?: string;
    /**
     * **Autorierter Klartext** als Medium — Alternative zu `mediaUrl` für Darsteller, die keinen
     * Link öffnen, sondern einen Text in die Bühnenmitte stellen (z. B. das txt-Symbol einer
     * Methode). Wird als gesetzter Fließtext gerendert, **nicht** als Markdown.
     * Verbindlich: R-METHODE-TXT-BESCHREIBUNG-001.
     */
    mediaText?: string;
    /** Volltext zu `mediaText` — Mehr-lesen-Blase im Overlay klappt ihn auf (R-METHODE-TXT-VOLLTEXT-002). */
    mediaTextVoll?: string;
    /** Inline-Lesefeld: Darsteller der Überschrift, rückt mit dem Feld (R-PROZESS-TXT-LESEFELD-002). */
    lesefeldTitelId?: string;
    /** Anzeige-/Tooltip-Titel des Mediums (instanz-spezifisch, nicht mergeable). */
    documentTitle?: string;
    /** Medientyp (pdf, video, audio, embed, markdown, image). */
    mediaType?: string;
    /** Anzeige-Modus: "onClick" (Overlay) oder "onStage" (inline). */
    mediaDisplay?: string;
    /** Breite des Medien-Containers in Welt-Einheiten. */
    mediaSizeX?: number;
    /** Hoehe des Medien-Containers in Welt-Einheiten. */
    mediaSizeY?: number;
    /** Shape fuer den geoeffneten Medien-Container (ersetzt Standard-Rahmen). */
    mediaShape?: string;
    /** SVG-Pfad unter public/ wenn mediaShape ein SVG-Praefix hat. */
    mediaSvgUrl?: string;
    /** Abstand (Welt-Einheiten) zwischen Shape-Rand und Medieninhalt. */
    mediaShapePadding?: number;
    /** Fuellfarbe des Overlay-Shapes (Hex). */
    mediaShapeColor?: string;
    /** Deckkraft des Overlay-Shapes (0…1). */
    mediaShapeOpacity?: number;
    /** Breite des Overlay-Shapes in Welt-Einheiten (unabhaengig von mediaSizeX). */
    mediaShapeSizeX?: number;
    /** Hoehe des Overlay-Shapes in Welt-Einheiten (unabhaengig von mediaSizeY). */
    mediaShapeSizeY?: number;
    /** Vertikaler Versatz NUR des Shapes ggü. dem zentrierten Medieninhalt (Welt-Einheiten, + = nach oben). */
    mediaShapeOffsetY?: number;
}
export interface SceneWorldBounds {
    minX: number;
    maxX: number;
    minY: number;
    maxY: number;
}
/**
 * Runtime-Gruppe als Metadaten-Knoten.
 * `children` bleibt fuer Legacy-Importe erhalten, HumanUX v2 rendert Gruppen aber flach ueber `Page.groups`.
 */
export interface SceneGroupNode {
    kind: "group";
    id: string;
    name: string;
    className: string | null;
    draggable: boolean;
    posConstX: boolean;
    posConstY: boolean;
    rotConstZ: boolean;
    collision: boolean;
    onLoadProps: ElementProps | null;
    onShowProps: ElementProps;
    onLeaveProps: ElementProps;
    /** HumanUX v2 Preview: markiert, welche Phasen echte Roh-Keyframes haben. */
    previewPhaseHints?: PreviewPhaseHints;
    /** HumanUX v2 Preview: optionale Regie-Motion je Phase (enter/exit). */
    previewPhaseMotionHints?: PreviewPhaseMotionHints;
    children: SceneNode[];
    /** Blatt-Entities dieser Gruppe in Render-/Layout-Reihenfolge. */
    memberIds?: string[];
    /** Welt-Bounds pro Phase fuer Auswahlrahmen, Zoom und Debugging. */
    boundsByPhase?: Partial<Record<EditPhase, SceneWorldBounds | null>>;
    /**
     * Viewport-fixierte Gruppe: Im Preview/Play-Modus wird die Gruppe
     * an einer Bildschirmecke gedockt, unabhaengig von Zoom/Pan.
     */
    viewportFixed?: boolean;
    /** Bildschirmecke. Default: "top-right". */
    viewportAnchor?: string;
    /** Horizontaler Offset vom Anker in Welteinheiten. */
    viewportOffsetX?: number;
    /** Vertikaler Offset vom Anker in Welteinheiten. */
    viewportOffsetY?: number;
    /**
     * Kulisse-Ebene (nur viewport-fixierte Gruppen im Preview): "top" = Vordergrund (Default),
     * "normal" = mit dem Bühneninhalt, "background" = dahinter. Siehe R-GROUP-KULISSE-ZLAYER-001.
     */
    zLayer?: "top" | "normal" | "background";
}
export type SceneNode = Element | SceneGroupNode;
export interface PreviewPhaseHints {
    explicitOnLoad: boolean;
    explicitOnShow: boolean;
    explicitOnLeave: boolean;
    /** Optional: explizite Roh-Keys je Phase (Property-Flow präziser als reine Bool-Hints). */
    explicitKeysOnLoad?: string[];
    explicitKeysOnShow?: string[];
    explicitKeysOnLeave?: string[];
}
export interface PreviewPhaseMotionHints {
    motionIn?: HumanUxMotionSpec;
    motionOut?: HumanUxMotionSpec;
}
export declare function isSceneGroupNode(n: SceneNode): n is SceneGroupNode;
/** Vorschau: Standard-Klickverhalten der Seite, wenn das geklickte Element kein eigenes Ziel setzt. */
export type PageDefaultClickBehavior = "none" | "next" | "goTo" | "jumpTo";
/**
 * Bühnen-Hintergrund hinter dem 28×16-Sichtfeld (CSS-Preview).
 * Kompiliert aus HumanUX `view.viewStyleRef` + `application.styles[key]` (nur relevante Felder).
 */
export interface PageStageStyle {
    materialColor: string;
    /** Deckkraft 0…1; optional, Standard 1. */
    transparency?: number;
}
export interface Page {
    id: string;
    name: string;
    /** Runtime-Renderliste: flach in Weltkoordinaten. */
    elements: SceneNode[];
    /** Gruppen-Metadaten fuer Editor/Preview; kein Render-Container fuer Child-Entities. */
    groups?: SceneGroupNode[];
    interaction: boolean;
    /**
     * Aus HumanUX-View kompiliert: Default-Klick pro Seite (Element-Navigation hat Vorrang).
     * `none` oder fehlend: kein automatischer Wechsel; `next` wechselt explizit zur nächsten Seite.
     */
    defaultClickBehavior?: PageDefaultClickBehavior;
    /** Ziel-View-ID oder Page-Name, wenn `defaultClickBehavior` goTo oder jumpTo. */
    defaultClickTargetView?: string;
    /** Optional: Vollflächen-Hintergrund der Preview-Bühne (nicht die logische 28×16-Fläche). */
    stageStyle?: PageStageStyle;
}
export interface ElementProps {
    positionX: number;
    positionY: number;
    sizeX: number;
    sizeY: number;
    rotationZ: number;
    /** Geometrie/Fläche; Presets u. a. `square`, `circle`, `amorph-tag`, `text-path-tag`, `svg:/…`, `image:/…`. */
    shape: string;
    materialColor: string;
    transparency: number;
    /** Textfarbe (HumanUX); fehlt im JSON → Default. */
    fontColor: string;
    /** Textdeckkraft 0…1; unabhängig von `transparency` der Fläche. */
    transpFont: number;
    /**
     * Schriftart für Textplatten (CSS `font-family`).
     * Leer = Default. Kurzformen `RobotoMono`, `MaziusDisplay`, `Metropolitano` → siehe `css-font-family.ts` / `globals.css`.
     */
    fontFamily: string;
    /**
     * Textart der Methodenansicht (`""` = keine). Gesetzt → Schrift, Schnitt, Stil und Zeilenhöhe
     * kommen aus `TEXTARTEN` (`packages/humanux-player/src/domain/textarten.ts`), die Größe bleibt `fontSize`.
     * Unbekannte Werte ignoriert der Renderer. R-STYLE-TEXTARTEN-002.
     */
    textart: string;
    fontSize: number;
    contentSizeX: number;
    contentSizeY: number;
    /**
     * Verschiebung des Textblocks relativ zur Mitte der Textplatte (Welt-Einheiten wie `positionX`/`positionY`).
     * 0 = zentriert; positives X nach rechts, positives Y nach oben auf der Bühne.
     */
    textPositionX: number;
    textPositionY: number;
    /**
     * Textplatte vertikal OBEN verankern statt (Default) mittig: `true` = die Oberkante des Textes
     * liegt fest an der Boxoberkante und längerer Text wächst nur nach UNTEN. `false` (Default) =
     * bisheriges Verhalten (vertikal zentriert, Text breitet sich von der Mitte nach oben+unten aus).
     * Nutzen: Fließtext-Blöcke, die unter einer Überschrift beginnen und nicht in sie hineinlaufen sollen.
     */
    textAnchorTop: boolean;
    /**
     * Textplatte vertikal UNTEN verankern statt (Default) mittig: `true` = die Unterkante des Textes
     * liegt fest an der Boxunterkante und mehr Zeilen wachsen nach OBEN. `false` (Default) = zentriert.
     * Gegenstück zu {@link textAnchorTop}; sinnvoll z. B. für eine Überschrift, deren Unterrand
     * unabhängig von der Zeilenzahl konstant über einem darunterliegenden Textblock bleiben soll.
     * Hat `textAnchorTop` Vorrang (beide `true` → oben).
     */
    textAnchorBottom: boolean;
    /**
     * Text für Textplatten/Overlays. Rohstring in JSON unverändert (HumanUX/Animationen unberührt).
     * Auf der CSS-Bühne: Inline-Markdown (`**fett**`, `*kursiv*`, `~~…~~`, `[t](url)`, Zeilenumbruch) — siehe `scene-text-content.ts`.
     */
    content: string;
    acceleration: number;
    density: number;
    onGravityClass: string;
    gravity: string;
    doStop: boolean;
    maxDist: number;
    eventType: string;
    eventAttribute: string | null;
    /**
     * Nur bei `shape === "amorph-tag"`: Stärke der radialen Verformung (0…1, typisch 0.2–0.5).
     */
    amorphAmount: number;
    /** Nur bei `amorph-tag`: Geschwindigkeit der langsamen Bewegung (0…1). */
    amorphSpeed: number;
    /** Nur bei `amorph-tag`: Wechsel zwischen eher stehend/liegend (0…1). */
    amorphStretch: number;
    /** Nur bei `amorph-tag`: Weichheit der Kurve (0…1, höher = ruhiger/rundere Übergänge). */
    amorphSoftness: number;
    /**
     * Form-Interaktion (Bühne): optionaler Override bei Hover.
     * Leer / null = Basiswerte (`materialColor` / `transparency` / `shape`) nutzen.
     */
    hoverMaterialColor: string;
    /** `null` = kein Override der Flächen-Deckkraft. */
    hoverTransparency: number | null;
    /** Nur bei SVG-Basis-`shape`: optional anderer Pfad (`svg:/…` oder `/…svg`). */
    hoverSvgShape: string;
    /** Optionaler Textfarben-Override bei Hover. Leer = `fontColor` (Basis) nutzen. */
    hoverFontColor: string;
    /** Optionaler Override während PointerDown (Priorität über Hover). */
    activeMaterialColor: string;
    activeTransparency: number | null;
    activeSvgShape: string;
    /**
     * SVG-Bild für „aktiv" (Media-Overlay dieses Darstellers offen), nur bei SVG-Basis-Shape.
     * Leer → das Quad wird bei offenem Overlay ausgeblendet (Ohr-Player). R-ENTITY-MEDIA-OVERLAY-ACTIVE-STATE-002.
     */
    openSvgShape: string;
    /**
     * Mischmodus NUR während Hover/Klick (`""` | `"multiply"`), z. B. Gesines Grau-Fassungen, die mit
     * dem Hintergrund multipliziert werden. R-STYLE-INTERACTION-BLEND-001.
     */
    interactionBlendMode: string;
    /** Optionaler Textfarben-Override während PointerDown (Priorität über Hover). */
    activeFontColor: string;
    /**
     * Preview-Zwilling (R-STYLE-PREVIEW-TWIN-001): zweite, symbolische Erscheinung
     * desselben Darstellers unter derselben ID (`image:/…` oder `svg:/…`).
     * Leer = kein Zwilling. Analog zu `hoverSvgShape` ein statisches (diskretes) Feld.
     */
    previewShape: string;
    /**
     * Mischregler 0…1 zwischen Original (`shape`) und Vorschau (`previewShape`):
     * 1 = nur Vorschau, 0 = nur Original, dazwischen Crossfade. Kontinuierlich —
     * wird wie `transparency` interpoliert. Nur wirksam mit gesetztem `previewShape`.
     */
    previewBlend: number;
    /**
     * Verhalten gegenüber einem offenen Bühnenmedium (R-ENTITY-MEDIA-STAGE-ROLE-001):
     * `""` keines · `"yield"` weicht (ausgeblendet, solange ein Medium offen ist) ·
     * `"backdrop"` Kulisse (nie klickbar, weicht wie „yield") ·
     * `"restore"` holt die Bühne zurück (aktiv, solange keins offen ist; Klick schließt es).
     * Phasenfeld, damit dieselbe Entity nur auf einer Bühne weicht. Optional für ältere Fixtures.
     */
    mediaStageRole?: string;
}
/** Bearbeitbare Phasen-Snapshots (DOM-Events sind es nicht). */
export type EditPhase = "onLoad" | "onShow" | "onLeave";
export declare const EDIT_PHASES: readonly EditPhase[];
