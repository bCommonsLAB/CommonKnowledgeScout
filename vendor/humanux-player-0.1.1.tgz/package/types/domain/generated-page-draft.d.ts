import type { ElementProps } from "./scene-schema";
/**
 * Reduzierter Entwurf eines Elements für regelbasierte Generierung.
 * Fehlende Felder werden serverseitig mit Defaults ergänzt.
 */
export interface GeneratedElementDraft {
    id: string;
    name?: string;
    className?: string | null;
    draggable?: boolean;
    posConstX?: boolean;
    posConstY?: boolean;
    rotConstZ?: boolean;
    collision?: boolean;
    /** `undefined` oder `null`: kein eigener onLoad-Snapshot (wie im JSON-Import). */
    onLoadProps?: Partial<ElementProps> | null;
    onShowProps?: Partial<ElementProps>;
    onLeaveProps?: Partial<ElementProps>;
}
/** Reduzierte Page; nach Normalisierung vollständiges `Page`-Schema. */
export interface GeneratedPageDraft {
    id: string;
    name: string;
    interaction?: boolean;
    elements: GeneratedElementDraft[];
}
/** Szenen-Kennung für Bootstrap und `next-page` im Dateimodus/Mockmodus. */
export type MockSetId = "test-a" | "test-b";
