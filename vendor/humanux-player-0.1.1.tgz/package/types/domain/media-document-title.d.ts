/**
 * Ableitung eines lesbaren Dokumenttitels aus einer Media-URL — Fallback, wenn
 * `entity.documentTitle` nicht gesetzt ist (R-ENTITY-DOCUMENT-TITLE-001).
 * Beispiel: `/media/wissenslandkarte_2026_01_12.pdf` → `wissenslandkarte 2026 01 12`.
 */
export declare function documentTitleFromMediaUrl(mediaUrl: string): string;
/** Effektiver Anzeigetitel: explizites `documentTitle`, sonst aus der URL abgeleitet. */
export declare function resolveMediaDocumentTitle(documentTitle: string | undefined, mediaUrl: string | undefined): string;
