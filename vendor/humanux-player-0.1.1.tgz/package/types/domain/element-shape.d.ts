/**
 * Erkennung von Asset-Shapes in `ElementProps.shape`.
 *
 * Unterstuetzte Formen:
 * - Explizites Praefix `svg:` gefolgt von einem Pfad unter `public/`, z. B. `svg:/icons/foo.svg`
 * - Oder direkt ein oeffentlicher Pfad: `/icons/foo.svg` (muss mit `/` beginnen und auf `.svg` enden)
 * - Explizites Praefix `image:` gefolgt von einem Pfad unter `public/`,
 *   z. B. `image:/images/foo.png` (png|jpg|jpeg|webp|gif)
 * - Oder `image:` gefolgt von einer `https://`-Adresse eines erlaubten Medien-Hosts
 *   (Speicher von KnowledgeScout, `ERLAUBTE_MEDIEN_HOSTS`) — jede andere fremde Adresse
 *   bleibt abgewiesen (R-MANIFEST-KS-MEDIA-HOST-002).
 *
 * Primitives (`square`, `circle`, `quad`, …) bleiben unveraendert; alles andere ohne SVG-Muster
 * verhaelt sich wie bisher (Legacy-Strings).
 */
/**
 * True, wenn `shape` ein SVG-Asset aus `public/` referenziert (nicht Primitive).
 */
export declare function isSvgShapeShape(shape: string): boolean;
/**
 * Liefert die URL fuer `<img src>` / Next `public`-Assets, oder `null` wenn kein SVG-Shape.
 * Der Pfad ist relativ zur Web-Root (z. B. `/icons/x.svg`).
 */
export declare function getSvgShapePublicUrl(shape: string): string | null;
/** True, wenn `shape` ein Bild-Asset aus `public/` referenziert (nicht Primitive). */
export declare function isImageShapeShape(shape: string): boolean;
/**
 * Liefert die URL fuer `<img src>` / Next `public`-Assets, oder `null` wenn kein Bild-Shape.
 * Akzeptiert `image:/...` mit Dateiendungen png|jpg|jpeg|webp|gif — und `image:https://...`,
 * wenn der Host auf der Erlaubt-Liste steht (die Adresse bleibt dann unveraendert).
 */
export declare function getImageShapePublicUrl(shape: string): string | null;
/** Eingebautes Shape: organischer Blob im Renderer, kein externe Datei. */
export declare const AMORPH_TAG_SHAPE: "amorph-tag";
export declare function isAmorphTagShape(shape: string): boolean;
/** Eingebautes Shape: Text auf SVG-Pfad (Ring), später erweiterbar (Morph, Hover). */
export declare const TEXT_PATH_TAG_SHAPE: "text-path-tag";
export declare function isTextPathTagShape(shape: string): boolean;
/**
 * Primitive Rechteck-Flächen mit CSS-Fill in sizeX/sizeY (nicht Kreis, kein Asset).
 * Text wird wie beim Kreis zentriert über die Fläche gelegt, statt die Fläche zu ersetzen (Textplatte).
 */
export declare function isPrimitiveRectShape(shape: string): boolean;
