/**
 * Einheitliche Farbstrings für Anzeige und Vergleich.
 * Legacy kann #RGB, #RRGGBB oder #RRGGBBAA liefern.
 */
export declare function normalizeMaterialColor(input: string): string;
