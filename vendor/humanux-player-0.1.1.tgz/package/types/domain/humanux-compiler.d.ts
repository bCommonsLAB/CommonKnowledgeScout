/**
 * Kompiliert HumanUX-v2-Autor:innen-JSON in das bestehende Laufzeitmodell `RootObject`.
 * Kanonische Regeln: `docs/humanux-v2/02_format-spezifikation.md`.
 */
import type { HumanUxApplication, HumanUxEntityDefinition, HumanUxEntityPhaseStates, HumanUxGroupDefinition, HumanUxPhasePatch, HumanUxRootObject } from "./humanux-authoring-schema";
import type { HumanUxEditPhase } from "./humanux-phase-map";
import type { Element, ElementProps, RootObject } from "./scene-schema";
/**
 * Für optimistischen Runtime-Merge im Editor: Patch kann `goToView`/`jumpToView` setzen oder leeren.
 * Leere Strings setzen Event-Felder auf Default zurück.
 */
export declare function mergeHumanUxPhasePatchIntoElementProps(base: ElementProps, patch: HumanUxPhasePatch): ElementProps;
export declare function getEffectiveStageGroupsForView(app: HumanUxApplication, viewIndex: number): Record<string, HumanUxGroupDefinition>;
/** Gleiche Fallbacks wie {@link humanuxGroupDefinitionAsEntityDef} — statische UI ohne redundantes JSON. */
export declare function humanUxEntityNodeFlags(def: HumanUxEntityDefinition): Pick<Element, "draggable" | "posConstX" | "posConstY" | "rotConstZ" | "collision">;
/**
 * Gruppen-Stammdaten → gleiche Form wie Entity-Definition für {@link materializeHumanUxPhaseProps}
 * und {@link explainHumanUxGroupPropSource}.
 */
export declare function humanuxGroupDefinitionAsEntityDef(def: HumanUxGroupDefinition, groupId: string): HumanUxEntityDefinition;
/**
 * Rohdaten prüfen und HumanUX-v2-Application parsen.
 */
export declare function parseHumanUxRootObject(raw: unknown): HumanUxRootObject;
export declare function isHumanUxV2Raw(raw: unknown): boolean;
/** Hinweis des Compilers, der nicht abbricht (bisher nur `console.warn`). */
export interface KompilierWarnung {
    code: "kulisse-selbst" | "kulisse-unbekannt" | "kulisse-doppelt";
    text: string;
    buehne: string;
    kulisse: string;
    id?: string;
}
/**
 * Kompiliert v2 → `RootObject` und wendet anschließend `normalizeSceneDocument` an
 * (Font-Defaults, Referenz-onLoad, …). Hinweise, die nicht abbrechen, landen in der Konsole;
 * wer sie braucht, nimmt {@link kompiliereHumanUxMitWarnungen}.
 */
export declare function compileHumanUxToRootObject(raw: unknown): RootObject;
/** Wie {@link compileHumanUxToRootObject}, liefert die Kulissen-Hinweise aber zurück (R-SCENE-PRUEFEN-001). */
export declare function kompiliereHumanUxMitWarnungen(raw: unknown): {
    root: RootObject;
    warnungen: KompilierWarnung[];
};
/**
 * Legacy-Migration: fruehe Runtime-Gruppen speicherten Mitglieder in Weltkoordinaten.
 * Seit echte CSS-Container genutzt werden, muessen Kinder lokal zur Gruppe gespeichert sein.
 */
export declare function normalizeHumanUxGroupCoordinateSpace(doc: HumanUxRootObject): HumanUxRootObject;
/**
 * Aufgelöste `entityStates` pro Entity fuer eine View (lineare Zeitachse).
 * Fuer Editor-Lineage und effektive Props ohne erneuten Compile.
 */
export declare function getResolvedEntityStatesForView(app: HumanUxApplication, viewIndex: number): Record<string, HumanUxEntityPhaseStates>;
/** Aufgelöste Gruppen-Phasen pro View (Keyframe-Logik wie Entities). */
export declare function getResolvedGroupStatesForView(app: HumanUxApplication, viewIndex: number): Record<string, HumanUxEntityPhaseStates>;
/** Basis-Props wie im Compiler: Default → Legacy-Style → Bereichs-Styles → Entity-`defaults`. */
export declare function computeHumanUxEntityBaseProps(app: HumanUxApplication, _entityId: string, def: HumanUxEntityDefinition): ElementProps;
/**
 * Effektive `ElementProps` fuer eine Entity in einer View/Phase — gleiche Logik wie `buildElement`,
 * inkl. `interactions.byEntity` fuer `active`.
 */
export declare function materializeHumanUxAuthoringPhaseProps(app: HumanUxApplication, entityId: string, viewIndex: number, phase: HumanUxEditPhase): ElementProps;
/**
 * Effektive Gruppen-Props für eine View/Phase (wie Entity, ohne Interactions).
 */
export declare function materializeHumanUxAuthoringGroupPhaseProps(app: HumanUxApplication, groupId: string, viewIndex: number, phase: HumanUxEditPhase): ElementProps | null;
