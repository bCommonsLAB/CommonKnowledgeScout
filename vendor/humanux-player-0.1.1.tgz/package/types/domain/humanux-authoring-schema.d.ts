/**
 * HumanUX v2 — Autor:innen-Schema (nicht identisch mit dem Laufzeit-`RootObject`).
 * Kanonische Fachdoku: `docs/humanux-v2/`.
 */
import type { ElementProps } from "./scene-schema";
import type { HumanUxMotionSpec } from "./humanux-motion";
export declare const HUMANUX_VERSION: 2;
/**
 * Optionale Shortcut-Felder pro Phase; `goToView`/`jumpToView` werden beim Kompilieren in
 * `eventType`/`eventAttribute` übersetzt und erscheinen nicht als eigenes ElementProps-Feld.
 */
export type HumanUxPhasePatch = Partial<ElementProps> & {
    goToView?: string;
    /**
     * Direkter Sprung zur Zielseite (ohne Exit/Enter-Animation der Seiten).
     * Wenn gesetzt (nicht-leer), hat Vorrang vor `goToView`.
     */
    jumpToView?: string;
    /**
     * Explizit zur nächsten View in der Reihenfolge (nicht nur impliziter Runtime-Fallback).
     * Kompiliert zu `eventType: "nextView"`.
     */
    navigateNextView?: boolean;
    /** Regie-Modell: Bewegungsstart beim Verlassen der Seite. */
    motionOut?: HumanUxMotionSpec;
    /** Regie-Modell: Bewegungsende beim Betreten der Seite. */
    motionIn?: HumanUxMotionSpec;
};
export interface HumanUxEntityPhaseStates {
    enter?: HumanUxPhasePatch;
    active?: HumanUxPhasePatch;
    exit?: HumanUxPhasePatch;
}
/**
 * v3 (stage-zentriert): `stage` ist der dominante Seitenzustand.
 * `enterAnchor`/`exitAnchor` sind optionale Stuetzpunkte auf dem kontinuierlichen Verlauf.
 */
export interface HumanUxStageFlowStates {
    stage?: HumanUxPhasePatch;
    enterAnchor?: HumanUxPhasePatch;
    exitAnchor?: HumanUxPhasePatch;
}
/**
 * Legacy-Feld aus früheren Entwürfen. `enterFromPreviousExit` wird nicht mehr ausgewertet
 * (Migration: kann aus JSON entfernt werden).
 */
export interface HumanUxViewPhaseLinks {
    enterFromPreviousExit?: boolean;
}
/** Unterstuetzte Medientypen fuer Entity-Assets. */
export type HumanUxMediaType = "pdf" | "video" | "audio" | "audio-embed" | "embed" | "markdown" | "image"
/** Autorierter Klartext aus `mediaText` statt einer Datei (R-METHODE-TXT-BESCHREIBUNG-001). */
 | "text";
/** Wann das Medium angezeigt wird: Overlay bei Klick oder direkt auf der Buehne. */
/** `inline`: Lesetext steht als Lesefeld direkt auf der Bühne (R-PROZESS-TXT-LESEFELD-001). */
export type HumanUxMediaDisplay = "onClick" | "onStage" | "inline";
/** Globale Entity-Definition (ein Objekt, mehrere Views referenzieren Zustände). */
export interface HumanUxEntityDefinition {
    name: string;
    className: string | null;
    /**
     * Fehlen diese Felder im JSON, gelten Compiler-Defaults wie bei Gruppen:
     * draggable false, posConstX/Y/rotConstZ true, collision false (statische UI-Elemente).
     */
    draggable?: boolean;
    posConstX?: boolean;
    posConstY?: boolean;
    rotConstZ?: boolean;
    collision?: boolean;
    /** Schlüssel in `application.styles`. */
    style?: string;
    defaults?: Partial<ElementProps>;
    /** URL zu einem Asset (lokal unter public/ oder extern, z.B. YouTube/PeerTube). */
    mediaUrl?: string;
    /**
     * **Autorierter Klartext** als Medium — Alternative zu `mediaUrl` für Darsteller, die keinen
     * Link öffnen, sondern einen Text in die Bühnenmitte stellen (z. B. das txt-Symbol einer
     * Methode). Wird als gesetzter Fließtext gerendert, **nicht** als Markdown.
     * Verbindlich: R-METHODE-TXT-BESCHREIBUNG-004.
     */
    mediaText?: string;
    /**
     * Optionaler Volltext zu `mediaText` — die Mehr-lesen-Blase im Overlay klappt ihn auf.
     * Wird über den {@link block-markdown}-Renderer dargestellt (Überschriften/Listen/Absätze).
     * Verbindlich: R-METHODE-TXT-VOLLTEXT-002.
     */
    mediaTextVoll?: string;
    /** Inline-Lesefeld: Darsteller der zugehörigen Überschrift, rückt mit dem Feld (R-PROZESS-TXT-LESEFELD-002). */
    lesefeldTitelId?: string;
    /**
     * Anzeige-/Tooltip-Titel des Mediums (instanz-spezifisch). Nicht über Styles oder
     * View-Phasen mergeable — siehe R-ENTITY-DOCUMENT-TITLE-001. Fallback: Dateiname aus `mediaUrl`.
     */
    documentTitle?: string;
    /** Medientyp — manuell per Dropdown im Inspector gewaehlt. */
    mediaType?: HumanUxMediaType;
    /** Anzeige-Modus: Overlay bei Klick oder direkt auf der Buehne. Default: "onClick". */
    mediaDisplay?: HumanUxMediaDisplay;
    /** Breite des Medien-Containers in Welt-Einheiten (analog zu contentSizeX). */
    mediaSizeX?: number;
    /** Hoehe des Medien-Containers in Welt-Einheiten (analog zu contentSizeY). */
    mediaSizeY?: number;
    /** Shape fuer den geoeffneten Medien-Container (ersetzt Standard-Rahmen). Leer = Standard-Rahmen. */
    mediaShape?: string;
    /** SVG-Pfad unter public/ wenn mediaShape = "svg:/…". */
    mediaSvgUrl?: string;
    /** Abstand (Welt-Einheiten) zwischen Shape-Rand und Medieninhalt auf jeder Seite. Default: 1. */
    mediaShapePadding?: number;
    /** Fuellfarbe des Overlay-Shapes (Hex). Default: #808080. */
    mediaShapeColor?: string;
    /** Deckkraft des Overlay-Shapes (0…1). Default: 1. */
    mediaShapeOpacity?: number;
    /** Breite des Overlay-Shapes in Welt-Einheiten (unabhaengig von mediaSizeX). Default: mediaSizeX. */
    mediaShapeSizeX?: number;
    /** Hoehe des Overlay-Shapes in Welt-Einheiten (unabhaengig von mediaSizeY). Default: mediaSizeY. */
    mediaShapeSizeY?: number;
    /** Vertikaler Versatz NUR des Shapes ggü. dem zentrierten Medieninhalt (Welt-Einheiten, + = nach oben). */
    mediaShapeOffsetY?: number;
}
/** Anker fuer viewport-fixierte Gruppen — Bildschirmecke oder Kantenmitte. */
export type HumanUxViewportAnchor = "top-left" | "top-right" | "bottom-left" | "bottom-right" | "top-center" | "bottom-center" | "center-left" | "center-right";
/**
 * Auto-Layout nur für direkte Kinder der Gruppe (Reihenfolge = `members`).
 * `manual`: Koordinaten aus Entity-/Gruppen-States wie bisher.
 */
export type HumanUxGroupLayoutMode = "manual" | "horizontal" | "vertical" | "circular";
export interface HumanUxGroupLayout {
    mode: HumanUxGroupLayoutMode;
    /** Abstand zwischen benachbarten Bounding-Boxen entlang der Hauptachse (horizontal: X, vertikal: Y). */
    gapX?: number;
    gapY?: number;
    /** Startpunkt des ersten Kindes (Mitte); Standard 0/0. */
    originX?: number;
    originY?: number;
    /** Nur `circular`: Radius in lokalen Einheiten (wie positionX/Y). */
    radius?: number;
    /** Nur `circular`: Startwinkel in Grad (0 = rechts). */
    startAngleDeg?: number;
    /** Nur `circular`: Drehrichtung (Standard: im Uhrzeigersinn). */
    clockwise?: boolean;
}
/**
 * Daten-Bindung eines Slots (Template-Bühnen): beschreibt, womit ein Resolver die
 * Mitglieder dieser Gruppe aus dem Inhalts-Datenlayer (`public/scenes/commoning/manifest.json`)
 * füllt. **Resolver-Ebene über dem Compiler** — `compileHumanUxToRootObject` wertet das Feld
 * nicht aus (wie `application.styleMeta`); Auswertung ausschließlich durch
 * Materialisierungs-Werkzeuge. Verbindlich: `R-GROUP-DATA-BINDING-001`
 * (docs/specs/entity-group.md), Konzept: docs/app-concept/detailseiten-konzept.md §4.
 */
export interface HumanUxGroupDataBinding {
    /** Benannte Mengen-Abfrage (ein Darsteller je Treffer), z. B. "karten-derselben-familie". */
    query?: string;
    /** Einzelwert-Pfad am aufgerufenen Item, z. B. "item.assets.front" — genau ein Darsteller. */
    bind?: string;
    /** Maske (`application.styles`-Key) je erzeugtem Darsteller. */
    itemStyle?: string;
    /** Optionale Treffer-Obergrenze für `query`. */
    limit?: number;
}
/**
 * Gruppen-Definition (Editor + Kompilat): Mitgliederliste + optionale Stammdaten wie bei Entities.
 * Phasen-Overrides pro View liegen in {@link HumanUxView.groupStates}.
 */
export interface HumanUxGroupDefinition {
    members: string[];
    /**
     * Optional: Daten-Bindung des Slots (nur Template-Bühnen). Compiler-ignoriert;
     * Platzhalter-Mitglieder dienen der Gestaltung im Editor und werden vom Resolver ersetzt.
     */
    dataBinding?: HumanUxGroupDataBinding;
    /** Optional: automatische Anordnung der direkten Kinder beim Kompilieren. */
    layout?: HumanUxGroupLayout;
    /**
     * Benannter Verweis auf `application.groupLayoutStyles[key]` — nur wenn `layout` nicht gesetzt.
     * Ersetzt das frühere `sectionStyles.layout`.
     */
    layoutStyleRef?: string;
    /** Legacy-Migration: fruehe Gruppen speicherten Mitglieder in Weltkoordinaten. */
    memberTransformSpace?: "local";
    name?: string;
    className?: string | null;
    draggable?: boolean;
    posConstX?: boolean;
    posConstY?: boolean;
    rotConstZ?: boolean;
    collision?: boolean;
    style?: string;
    defaults?: Partial<ElementProps>;
    /**
     * Viewport-fixierte Gruppe: Im Preview/Play-Modus wird die Gruppe
     * an einer Bildschirmecke gedockt, unabhaengig von Zoom/Pan.
     * Im Editor bleibt die Positionierung in Weltkoordinaten.
     */
    viewportFixed?: boolean;
    /** Bildschirmecke, an die die Gruppe gedockt wird. Default: "top-right". */
    viewportAnchor?: HumanUxViewportAnchor;
    /** Horizontaler Abstand vom Anker in Welteinheiten. Default: 0. */
    viewportOffsetX?: number;
    /** Vertikaler Abstand vom Anker in Welteinheiten. Default: 0. */
    viewportOffsetY?: number;
    /**
     * Kulisse-Ebene (nur bei `viewportFixed`, nur Preview): "top" = Vordergrund (Default für
     * Kulissen), "normal" = mit dem Bühneninhalt, "background" = dahinter (R-GROUP-KULISSE-ZLAYER-001).
     */
    zLayer?: "top" | "normal" | "background";
}
/**
 * Rein organisatorische Gruppierung von Views in der Sidebar-Liste.
 * Hat keinen Einfluss auf Kompilierung oder Runtime — dient nur der Uebersicht im Editor.
 */
export interface HumanUxViewGroup {
    name?: string;
    /** View-IDs, die zu dieser Gruppe gehoeren, in Anzeigereihenfolge. */
    viewIds: string[];
}
/** Vorschau-Default: Klick auf Elemente ohne eigenes Navigationsziel. */
export type HumanUxViewDefaultClickBehavior = "none" | "next" | "goTo" | "jumpTo";
export interface HumanUxView {
    id: string;
    name: string;
    interaction: boolean;
    /**
     * Standard-Klickverhalten dieser View, wenn das geklickte Element keine Navigation setzt.
     * `none`: kein Wechsel bei Klick; zur nächsten Seite nur mit `next`.
     */
    defaultClickBehavior?: HumanUxViewDefaultClickBehavior;
    /** Ziel-View-ID oder Page-Name bei `goTo` oder `jumpTo`. */
    defaultClickTargetView?: string;
    /**
     * Bühnen-Hintergrund (gesamte Preview-Fläche): Hex wie `#RRGGBB` (wie `ElementProps.materialColor`).
     * Hat **Vorrang** vor `viewStyleRef`. Leer/fehlend → optional Fallback über Style-Paket.
     */
    stageBackgroundColor?: string;
    /**
     * Deckkraft 0…1 (wie `ElementProps.transparency`). Gilt nur mit gesetzter `stageBackgroundColor`.
     */
    stageBackgroundTransparency?: number;
    /**
     * Optional: `application.styles[key]` für Bühnenfarbe, wenn **keine** `stageBackgroundColor` gesetzt ist.
     * Es werden nur `materialColor` und optional `transparency` aus dem Paket gelesen.
     */
    viewStyleRef?: string;
    /** @deprecated Legacy-JSON; wird nicht mehr ausgewertet. */
    phaseLinks?: HumanUxViewPhaseLinks;
    /** Pro View: welche Entity in welcher Phase welche Props hat. */
    entityStates?: Record<string, HumanUxEntityPhaseStates>;
    /** Alias für `entityStates` (gleiche Bedeutung). */
    phaseStates?: Record<string, HumanUxEntityPhaseStates>;
    /** Pro View: Gruppen-IDs → Phasen-Overrides (Merge/Vererbung wie `entityStates`). */
    groupStates?: Record<string, HumanUxEntityPhaseStates>;
    /** Alias für `groupStates`. */
    phaseGroupStates?: Record<string, HumanUxEntityPhaseStates>;
    /** v3: stage-zentrierte Entity-Flows (Primary in contract-first Migration). */
    entityFlowStates?: Record<string, HumanUxStageFlowStates>;
    /** v3: stage-zentrierte Gruppen-Flows (Primary in contract-first Migration). */
    groupFlowStates?: Record<string, HumanUxStageFlowStates>;
    /**
     * View-spezifische Bühnen-Gruppen.
     * Fehlt das Feld, kann die Runtime auf `application.groups` als Vorlage zurückfallen.
     */
    stageGroups?: Record<string, HumanUxGroupDefinition>;
    /**
     * View-IDs, deren kompilierte Entities/Gruppen in diese Page gemerged werden.
     * Nur eine Ebene — transitive overlayViewRefs der referenzierten Views werden ignoriert.
     */
    overlayViewRefs?: string[];
    /**
     * Kennzeichnet diese Bühne als **Detail-Template** für einen Item-Typ des
     * Inhalts-Datenlayers (z. B. „musterkarte", „methode"). Der Laufzeit-Resolver
     * materialisiert daraus bei Navigation auf eine fehlende `v_md__<item>`-Seite
     * flüchtig die Detail-Bühne (`src/domain/detail-template-resolver.ts`).
     * Compiler-ignoriert (wie `styleMeta`/`dataBinding`). Verbindlich:
     * `R-VIEW-DETAIL-TEMPLATE-001` (docs/specs/entity-view.md).
     */
    detailTemplate?: {
        /** Item-Typ aus dem Manifest (`item.type`), den diese Vorlage darstellt. */
        itemType: string;
        /** Web-Pfad des Manifests (unter `public/`), z. B. "/scenes/commoning/manifest.json". */
        manifestUrl: string;
    };
}
export interface HumanUxInteractions {
    /** z. B. `{ "navNext": { "onClick": { "goToView": "p2" } } }` */
    byEntity?: Record<string, {
        onClick?: {
            goToView?: string;
            jumpToView?: string;
        };
    }>;
}
export interface HumanUxLayoutDef {
    type: string;
    params?: Record<string, unknown>;
}
/**
 * Erweiterte `application`-Form für v2. Wird nach `RootObject` kompiliert.
 */
export interface HumanUxApplication {
    humanuxVersion: typeof HUMANUX_VERSION;
    id: string;
    name: string;
    defaultFontFamily?: string;
    /** Benannte Style-Pakete (`Partial<ElementProps>`); Verweis über `entity.style` / `group.style`. */
    styles?: Record<string, Partial<ElementProps>>;
    /**
     * Optionale Anzeige-Metadaten je Maske (Schlüssel = Style-Key aus `styles`).
     * `name` ist der laienfreundliche Klarname für UI/Dropdown; fehlt er, gilt der technische Schlüssel.
     * Vom Compiler ignoriert (reine Editor-/Anzeige-Ebene), aber persistiert (Shell-`application`).
     * Siehe `R-STYLE-DISPLAY-NAME-001`.
     */
    styleMeta?: Record<string, {
        name?: string;
    }>;
    /**
     * Benannte Gruppen-Layouts; Verweis über `group.layoutStyleRef` (oder Inline `group.layout`).
     */
    groupLayoutStyles?: Record<string, HumanUxGroupLayout>;
    entities: Record<string, HumanUxEntityDefinition>;
    /** Gruppen: Mitglieder + optional Stammdaten; Legacy `{ members }` bleibt gültig. */
    groups?: Record<string, HumanUxGroupDefinition>;
    layouts?: Record<string, HumanUxLayoutDef>;
    views: HumanUxView[];
    /**
     * Optionale, rein organisatorische Gruppen fuer die Sidebar-Ansicht.
     * Werden vom Compiler ignoriert; nur im Editor fuer Uebersichtlichkeit.
     */
    viewGroups?: Record<string, HumanUxViewGroup>;
    transitions?: Record<string, unknown>;
    lodRules?: Record<string, unknown>;
    interactions?: HumanUxInteractions;
}
export interface HumanUxRootObject {
    application: HumanUxApplication;
}
