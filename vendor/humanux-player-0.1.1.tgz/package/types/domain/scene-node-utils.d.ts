/**
 * Hilfen für rekursive {@link SceneNode}-Bäume (Laufzeit-Seiten).
 */
import type { Element, Page, SceneGroupNode, SceneNode } from "./scene-schema";
export declare function findElementInPage(page: Page, elementId: string): Element | undefined;
export declare function findSceneNodeInPage(page: Page, id: string): SceneNode | undefined;
export declare function findSceneGroupInPage(page: Page, groupId: string): SceneGroupNode | undefined;
/** Anzahl aller Knoten (Gruppen + Blätter) in DFS-Reihenfolge — für Z-Index auf der Bühne. */
export declare function countSceneNodesInTree(nodes: readonly SceneNode[]): number;
/** Nur Entity-Blätter (keine Gruppen-IDs), DFS. */
export declare function flattenLeafEntityIds(nodes: readonly SceneNode[]): string[];
/** Tiefensuche: alle Blatt-IDs (Entities) und Gruppen-IDs in Baum-Reihenfolge. */
export declare function flattenSceneNodeIds(nodes: readonly SceneNode[]): string[];
export declare function flattenPageNodeIds(page: Page): string[];
