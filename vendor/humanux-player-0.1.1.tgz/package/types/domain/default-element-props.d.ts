import type { ElementProps } from "./scene-schema";
/**
 * Minimal sinnvolle Defaults, falls einzelne Felder in alten JSONs fehlen.
 */
export declare function createDefaultElementProps(): ElementProps;
