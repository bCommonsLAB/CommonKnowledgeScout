import type { HumanUxRootObject } from "./humanux-authoring-schema";
/**
 * Contract-first v3 migration: erzeugt stage-zentrierte Flow-States je View.
 * Legacy-Phasefelder bleiben als Kompatibilitaet erhalten, werden aber nicht mehr als primaere Quelle benoetigt.
 */
export declare function migrateHumanUxToStageFlow(doc: HumanUxRootObject): HumanUxRootObject;
