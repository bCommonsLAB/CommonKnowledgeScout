import type { EditPhase } from "./scene-schema";
export type HumanuxTransitionReason = "preview" | "editor-scrub";
export interface HumanuxTransitionIntent {
    reason: HumanuxTransitionReason;
    fromPageIndex: number;
    toPageIndex: number;
    fromPhase: EditPhase;
    toPhase: EditPhase;
    /** 0..1 */
    progress: number;
}
export declare function clampTransitionProgress(progress: number): number;
