/**
 * Strukturprüfungen einer HumanUX-v2-Aufführung — **gesammelt** statt beim ersten Fund geworfen
 * (R-SCENE-PRUEFEN-001).
 *
 * Eine Logik, zwei Aufrufer: Der Compiler wirft weiterhin den ERSTEN Fehler
 * ({@link wirfErstenStrukturFehler}, gleiche Meldung und Reihenfolge wie vorher), die Prüfung
 * (`humanux-pruefen.ts`) zeigt ALLE. Die Texte sind die technischen Compiler-Meldungen; die
 * Prüfung übersetzt sie für Menschen.
 *
 * Kein Import aus `humanux-compiler.ts` (sonst Zyklus): Bühnengruppen je Bühne reicht der
 * Aufrufer herein.
 */
import type { HumanUxApplication, HumanUxEntityDefinition, HumanUxGroupDefinition } from "./humanux-authoring-schema";
export type StrukturFehlerCode = "doppelte-buehnen-id" | "id-kollision" | "maske-unbekannt" | "layoutmaske-unbekannt" | "gruppe-selbst-mitglied" | "gruppe-mehrfach-mitglied" | "darsteller-mehrfach-mitglied" | "mitglied-unbekannt" | "gruppen-zyklus" | "zustand-unbekannter-darsteller";
export interface StrukturFehler {
    code: StrukturFehlerCode;
    /** Technische Meldung, wortgleich mit der früheren Compiler-Ausnahme. */
    text: string;
    buehne?: string;
    darsteller?: string;
    gruppe?: string;
    maske?: string;
}
/** Compiler-Weg: wirft den ersten Fehler als `SceneParseError`, sonst nichts. */
export declare function wirfErstenStrukturFehler(fehler: StrukturFehler[]): void;
/** Doppelte Bühnen-Ids, Kollision Darsteller/Gruppe (global), unbekannte Masken/Layoutmasken. */
export declare function sammleIdUndMaskenFehler(app: HumanUxApplication): StrukturFehler[];
/**
 * `entity.style` / `group.style` (inkl. View-`stageGroups`) und `group.layoutStyleRef` müssen auf
 * existierende Schlüssel verweisen — R-ENTITY-STYLE-RESOLUTION-001.
 */
export declare function sammleMaskenFehler(app: HumanUxApplication): StrukturFehler[];
/**
 * Gruppenmitglieder (R-GROUP-VALIDITY-001): Darsteller in höchstens einer Gruppe, Gruppe in
 * höchstens einer Elterngruppe, nur bekannte Mitglieder, keine Zyklen.
 */
export declare function sammleGruppenFehler(groups: Record<string, HumanUxGroupDefinition>, entities: Record<string, HumanUxEntityDefinition>, buehne?: string): StrukturFehler[];
/**
 * Prüfungen einer Bühne, in der Reihenfolge des Compilers: Kollision Bühnengruppe/Darsteller,
 * Gruppenmitglieder, Zustände unbekannter Darsteller (R-ENTITY-CROSS-REF-001).
 */
export declare function sammleBuehnenFehler(app: HumanUxApplication, viewIndex: number, stageGroups: Record<string, HumanUxGroupDefinition>): StrukturFehler[];
/** Alle Strukturfehler, in der Reihenfolge, in der der Compiler sie träfe. Doppelte zusammengefasst. */
export declare function sammleStrukturFehler(app: HumanUxApplication, stageGroupsJeBuehne: Array<Record<string, HumanUxGroupDefinition>>): StrukturFehler[];
