import type { App, Page } from "./scene-schema";
/**
 * Pro Element-ID: Index der ersten Seite und des Elements (kanonisch).
 * Spätere Vorkommen gelten als Referenz auf dasselbe fachliche Objekt.
 */
export interface CanonicalIndex {
    readonly firstPageIndex: number;
    readonly firstElementIndex: number;
}
/**
 * Map elementId -> erste Position in der Seitenliste.
 * Rekursive Pages: Index in **DFS-Blattreihenfolge** (ohne Gruppen-Container-IDs).
 */
export declare function buildCanonicalMap(pages: Page[]): Map<string, CanonicalIndex>;
/** True, wenn dieses Element auf dieser Seite die kanonische Instanz ist. */
export declare function isCanonical(app: App, pageIndex: number, elementIndex: number): boolean;
