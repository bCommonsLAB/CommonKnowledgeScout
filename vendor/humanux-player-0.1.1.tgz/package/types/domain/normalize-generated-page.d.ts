import type { GeneratedPageDraft } from "./generated-page-draft";
import type { ElementProps, Page } from "./scene-schema";
/**
 * Baut vollständige `ElementProps` aus Teilfeldern (Generator-Output).
 */
export declare function mergeElementPropsDefaults(partial: Partial<ElementProps>): ElementProps;
/** Generator-Entwurf → validiertes `Page` (ohne `resolveOnLoadFromPreviousPages`). */
export declare function normalizeGeneratedPageDraft(draft: GeneratedPageDraft): Page;
