/**
 * Block-Markdown-Renderer für den Methoden-Volltext hinter der Mehr-lesen-Blase
 * (`mediaTextVoll`, R-METHODE-TXT-VOLLTEXT-002).
 *
 * Nur drei Blockarten, weil die KnowledgeScout-Textdateien nicht mehr enthalten
 * (R-STYLE-BLOCK-MARKDOWN-002):
 *   - `## …` / `### …`  → Zwischenüberschrift (h3/h4, beide Fließtext · Überschrift, gleiche Größe)
 *   - `- …`              → Aufzählung mit Einzug
 *   - Leerzeile          → Absatzgrenze
 *
 * Inline-Formatierung (`**fett**`, `*kursiv*`, `[text](url)`) läuft über den vorhandenen
 * Parser {@link parseInlineMarkdownLines} — nichts doppelt gebaut. **Keine** Bilder,
 * **keine** Tabellen — die Quelldateien enthalten keine.
 */
import type { ReactNode } from "react";
/**
 * Beide Überschriftenstufen: Fließtext · Überschrift (Metropolitano bold), GLEICHE Größe wie der
 * Lesetext (`1em` — erbt das Bühnenmaß vom Overlay). R-STYLE-BLOCK-MARKDOWN-002.
 */
export declare const HEADING_STYLE: React.CSSProperties;
/** Rendert `mediaTextVoll` als gesetzten Fließtext mit Zwischenüberschriften und Listen. */
export declare function BlockMarkdown({ text }: {
    text: string;
}): ReactNode;
