/**
 * Lesefeld für den Beschreibungstext eines Prozessschritts — steht direkt auf der Bühne
 * (kein Klick-Overlay). Vorbild ist der Methoden-Lesetext: Einleitung fett, darunter der Rest.
 *
 * - Zugeklappt: höchstens {@link LESEFELD_ZEILEN} Zeilen, bei Überlänge die Mehr-lesen-Blase.
 * - Aufgeklappt: ganzer Text, das Feld scrollt in seiner Box.
 * - Kopieren und Maximieren oben rechts; Maximieren öffnet das Leseblatt in Bühnenfarbe.
 * - Zugeklappt stehen Überschrift (eigener Darsteller, `titelId`) und Text zusammen senkrecht
 *   mittig auf der Bühne; beim Aufklappen rücken beide an ihre autorierte Position hoch.
 *
 * R-PROZESS-TXT-LESEFELD-001, R-PROZESS-TXT-LESEFELD-002.
 */
import { type RefObject } from "react";
/** Sichtbare Zeilen im zugeklappten Lesefeld. */
export declare const LESEFELD_ZEILEN = 5;
/** Höhe (px) von `zeilen` Zeilen Fließtext · Text im Bühnenmaß. */
export declare function lesefeldKlappHoehePx(pxPerWorld: number, zeilen?: number): number;
/**
 * Versatz nach unten, der den Block [Titel-Oberkante … Text-Unterkante] senkrecht auf die
 * Bühnenmitte setzt. Nie negativ — der Block rückt nur nach unten, nie über die autorierte Lage.
 */
export declare function ruheVersatzZurMittePx(blockObenPx: number, blockUntenPx: number, mittePx: number): number;
export declare function ProzessLesefeld({ einleitung, volltext, pxPerWorld, buehneRef, farbe, titelId, }: {
    einleitung: string;
    volltext?: string;
    pxPerWorld: number;
    /** Bühnen-Container — seine Farbe wird die Blattfarbe des Readers. */
    buehneRef: RefObject<Element | null>;
    farbe?: string;
    /** Darsteller der Überschrift — rückt zugeklappt mit in die Mitte. */
    titelId?: string;
}): import("react/jsx-runtime").JSX.Element;
