/**
 * Lesefeld hinter dem txt-Knopf einer Musterkarte: Leitfrage (`## …` → Fließtext · Überschrift)
 * und Haupttext (Fließtext · Text) auf einmal — ohne Mehr-lesen-Blase, der Text ist kurz.
 * Senkrecht mittig im Feld; wird er höher als das Feld, beginnt er oben und das Feld scrollt.
 *
 * Verbindlich: R-VIEW-DETAIL-MUSTERKARTE-TXT-001.
 */
import type { CSSProperties } from "react";
export declare function MusterkartenLesetext({ text, style }: {
    text: string;
    style: CSSProperties;
}): import("react/jsx-runtime").JSX.Element;
