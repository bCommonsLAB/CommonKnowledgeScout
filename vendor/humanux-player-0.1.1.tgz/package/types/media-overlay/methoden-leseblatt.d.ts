/**
 * Reader für den Lesetext einer Methode: ein DIN-A4-Blatt in Bühnenfarbe, mittig über der Seite.
 * Öffnet nur über den Maximieren-Knopf des Lesetext-Overlays. R-METHODE-TXT-READER-001.
 */
import { type ReactNode, type RefObject } from "react";
/** DIN A4: Höhe = Breite · √2. */
export declare const A4_VERHAELTNIS: number;
/** Blattmaß (px) für ein Fenster: 90 % Höhe, bei schmalem Fenster auf 92 % Breite begrenzt. */
export declare function leseblattMass(fensterBreite: number, fensterHoehe: number): {
    width: number;
    height: number;
};
/** Erste deckende Hintergrundfarbe ab `el` aufwärts — die Farbe der Bühne. */
export declare function deckendeHintergrundfarbe(el: Element | null | undefined): string | undefined;
export declare function MethodenLeseblatt({ buehneRef, onClose, onVerkleinern, zusatzKnoepfe, children, }: {
    /** Bühnen-Container; seine Farbe wird die Blattfarbe (siehe {@link deckendeHintergrundfarbe}). */
    buehneRef: RefObject<Element | null>;
    onClose: () => void;
    onVerkleinern: () => void;
    /** Knöpfe links neben Verkleinern (z. B. Kopieren, R-METHODE-TXT-KOPIEREN-001). */
    zusatzKnoepfe?: ReactNode;
    /** Der Lesetext; füllt das Blatt und scrollt selbst. */
    children: ReactNode;
}): import("react").ReactPortal | null;
