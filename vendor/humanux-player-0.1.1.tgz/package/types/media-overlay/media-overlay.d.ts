/**
 * Media-Overlay: Portal in den Rahmen der Overlays (R-PLAYER-RAHMEN-001; ohne Rahmen document.body)
 * mit position:fixed (Viewport-Koordinaten).
 * Kein Backdrop. Koordinaten kommen aus der Stage-Container-Rect + lokaler Offset —
 * so entkoppeln wir Subframe-Painting von verschachtelten Layern (Electron/Cursor).
 *
 * activeSrc: drei rAF plus kurzer setTimeout — mindert Races (StrictMode / Embedded-Browser).
 */
import { type RefObject } from "react";
import { type TextartId } from "../domain/textarten";
/** YouTube/PeerTube Watch-URL → Embed-URL konvertieren. */
/**
 * Typografie einer Textart im Bühnenmaß für DOM außerhalb der Bühne (Overlay, Ohr-Player).
 * `pxPerWorld` kommt von der Bühne; Größe skaliert mit wie jede Fläche. R-STYLE-TEXTARTEN-002.
 */
export declare function overlayTextartStyle(id: TextartId, pxPerWorld: number): React.CSSProperties;
export type MediaAvailability = "checking" | "available" | "missing";
/**
 * Auswertung der Probe-Antwort: nur ein klarer Fehlstatus (404/403/5xx) gilt als „fehlt".
 * Ein geworfener Fetch-Fehler (Netzwerk/CORS) wird NICHT hier behandelt, sondern blockiert
 * bewusst nicht — dann rendern wir normal weiter (R-MEDIA-MISSING-LINK-PREFLIGHT-001).
 */
export declare function classifyMediaResponse(ok: boolean): MediaAvailability;
/**
 * URL, an der sich die Erreichbarkeit CORS-sauber prüfen lässt — oder `null`, wenn nicht prüfbar.
 * - Same-origin-Assets (pdf/video/audio/image/markdown/default): die Datei selbst (HEAD).
 * - Funkwhale-Audio (`audio-embed`, z. B. open.audio): CORS-fähige Track-API `/api/v1/tracks/<id>/`.
 *   Die Embed-URL selbst ist NICHT prüfbar (CORS); die Provider-API dagegen schon.
 * - PeerTube (`embed`): CORS-fähige Video-API `/api/v1/videos/<id>`.
 * - YouTube & unbekannte Embeds: `null` (keine offene CORS-API → nicht von außen prüfbar).
 * Verbindlich: R-MEDIA-MISSING-LINK-PREFLIGHT-001.
 */
export declare function resolveMediaProbeUrl(mediaUrl: string, mediaType: string): string | null;
/**
 * Neue Wiedergabeposition nach ±Skip, geklemmt auf [0, duration].
 * Exportiert für Unit-Tests (R-AUDIO-PLAYER-SKIP-CLAMP-001).
 */
export declare function clampSkipTarget(currentTime: number, deltaSeconds: number, duration: number): number;
export declare function formatAudioTime(seconds: number): string;
/**
 * Maße des Ohr-Players in WELT-Einheiten (Entwurf `260910 website-maße.pdf`, S. 7) — sie skalieren
 * mit `pxPerWorld` wie die ganze Bühne. Verbindlich: R-OVERLAY-AUDIO-MITTE-001.
 */
export declare const AUDIO_PLAYER_MASS_WELT: {
    /** Ohr 144 × 200.5 pt. */
    readonly ohrHoehe: 4.758;
    readonly ohrSeitenverhaeltnis: number;
    /** Fortschrittslinie 171.5 pt breit … */
    readonly linieBreite: 4.07;
    /** … ihre Mitte 21 pt unter der Ohr-Unterkante. */
    readonly linieAbstand: 0.498;
    /** Punkt Ø 10 pt. */
    readonly punkt: 0.237;
    /** ±15-s-Ohren: Anteil der Ohrhöhe (bisheriges Verhältnis 48 : 88). */
    readonly seitenohrAnteil: number;
    /** Lücke zwischen Ohr und Seitenohr: Anteil der Ohrhöhe (bisher 14 : 88). */
    readonly lueckeAnteil: number;
};
/** Player-Maße in Pixel beim gegebenen Bühnenmaß. */
export declare function audioPlayerMassPx(pxPerWorld: number): {
    ohrHoehe: number;
    ohrBreite: number;
    seitenohrHoehe: number;
    seitenohrBreite: number;
    luecke: number;
    linieBreite: number;
    linieAbstand: number;
    punkt: number;
};
export declare function StageMediaOverlay({ mediaUrl, mediaText, mediaTextVoll, mediaType, stageContainerRef, pxPerWorld, leftPx, topPx, widthPx, heightPx, onClose, mediaShape, mediaShapePaddingPx, mediaShapeColor, mediaShapeOpacity, shapeWidthPx, shapeHeightPx, shapeOffsetYPx, audioTitle, audioTargetLeftPx, audioTargetTopPx, audioClosing, onAudioCloseFinished, }: {
    mediaUrl: string;
    /**
     * Autorierter Klartext statt Link. Ist er gesetzt, zeigt das Overlay ihn als gesetzten
     * Fliesstext — `mediaUrl` bleibt dann leer. R-METHODE-TXT-BESCHREIBUNG-004.
     */
    mediaText?: string;
    /** Volltext zu `mediaText` — die Mehr-lesen-Blase klappt ihn auf. R-METHODE-TXT-VOLLTEXT-002. */
    mediaTextVoll?: string;
    mediaType: string;
    /** Buehnen-Container (relative Koordinatenbasis fuer leftPx/topPx). */
    stageContainerRef: RefObject<HTMLElement | null>;
    /** Bühnenmaß (px je Welt-Einheit) — Schriftgrößen der Textarten folgen ihm. R-STYLE-TEXTARTEN-002. */
    pxPerWorld?: number;
    leftPx: number;
    topPx: number;
    widthPx: number;
    heightPx: number;
    onClose: () => void;
    /** Optionales Shape fuer den Overlay-Container (ersetzt Standard-Rahmen). */
    mediaShape?: string;
    /** Padding in Pixel zwischen Shape-Rand und Medieninhalt (bereits in px umgerechnet). */
    mediaShapePaddingPx?: number;
    /** Fuellfarbe des Shapes. */
    mediaShapeColor?: string;
    /** Deckkraft des Shapes (0…1). */
    mediaShapeOpacity?: number;
    /** Breite des Shape-Containers in Pixel (unabhaengig von widthPx). Fallback: widthPx. */
    shapeWidthPx?: number;
    /** Hoehe des Shape-Containers in Pixel (unabhaengig von heightPx). Fallback: heightPx. */
    shapeHeightPx?: number;
    /** Versatz NUR des Shapes nach oben (px); das Video bleibt zentriert. */
    shapeOffsetYPx?: number;
    /** Ohr-Player (mediaType „audio"): Anzeigetitel unter der Fortschrittsleiste. */
    audioTitle?: string;
    /** Ohr-Player: Ziel-X (Bühnen-Container-relativ, px) — „Mitte unten unter der Kartenwand". */
    audioTargetLeftPx?: number;
    /** Ohr-Player: Ziel-Y (Bühnen-Container-relativ, px). */
    audioTargetTopPx?: number;
    /** Ohr-Player: Fly-back-Phase aktiv (Ohr schwebt zurück zum Ursprung, dann `onAudioCloseFinished`). */
    audioClosing?: boolean;
    /** Ohr-Player: Fly-back-Animation beendet → Overlay endgültig schließen. */
    onAudioCloseFinished?: () => void;
}): import("react/jsx-runtime").JSX.Element | null;
/**
 * Ist `mediaShape` eine **Bild**-Form (SVG/Bitmap) statt eines Primitivs (circle/square/…)?
 *
 * Bild-Formen rendern als `<img>` und leiten ihre Höhe aus dem Seitenverhältnis der Datei ab —
 * `mediaShapeSizeY` ist für sie wirkungslos. Verbindlich: R-STYLE-MEDIA-SHAPE-IMAGE-RATIO-001.
 * Exportiert für den Inspektor (sperrt das Feld) und für Tests.
 */
export declare function istBildShape(mediaShape: string | undefined | null): boolean;
