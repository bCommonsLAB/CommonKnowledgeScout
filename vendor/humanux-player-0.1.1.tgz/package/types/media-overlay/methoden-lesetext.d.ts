/**
 * Lesetext hinter dem txt-Symbol einer Methode: Einleitung (erster Absatz, R-METHODE-TXT-BESCHREIBUNG-004)
 * als Überschrift, der Rest des Volltexts wächst darunter.
 *
 * - Ruhe: Einleitung (Fließtext · Überschrift) + Mehr-lesen-Blase senkrecht mittig im Feld.
 *   R-METHODE-TXT-BESCHREIBUNG-003.
 * - Aufklappen: Einleitung rückt nach oben, der Rest blendet darunter ein; Zuklappen umgekehrt.
 *   R-METHODE-TXT-VOLLTEXT-002.
 *
 * `expanded` kommt von außen (`StageMediaOverlay`, Rücksetzen beim Medienwechsel); diese
 * Komponente führt daraus die Lese-Phase mit Aus-Blende vor dem Aushängen.
 */
import { type CSSProperties } from "react";
/** Dauer je Übergangsschritt (Rücken bzw. Blende). */
export declare const LESETEXT_UEBERGANG_MS = 450;
export type LesePhase = "ruhe" | "offen" | "schliesst";
/**
 * Zustandsfolge des Lesetexts (R-METHODE-TXT-VOLLTEXT-002):
 * ruhe —aufklappen→ offen —zuklappen→ schliesst —ausgeblendet→ ruhe.
 * Wird während `schliesst` wieder aufgeklappt, geht es direkt zurück nach `offen`.
 */
export declare function naechsteLesePhase(phase: LesePhase, ereignis: "aufklappen" | "zuklappen" | "ausgeblendet"): LesePhase;
/** Volltext eingehängt? Nur in `offen` und während der Aus-Blende. */
export declare function volltextEingehaengt(phase: LesePhase): boolean;
/**
 * Versatz, der den Summary-Block in Ruhe senkrecht mittig setzt (R-METHODE-TXT-BESCHREIBUNG-003).
 * Höher als das Feld → 0 (oben bündig, das Feld scrollt).
 */
export declare function summaryRuheVersatzPx(feldInnenHoehePx: number, blockHoehePx: number): number;
export declare function MethodenLesetext({ summary, volltext, expanded, onToggleExpanded, style, }: {
    summary: string;
    volltext?: string;
    expanded: boolean;
    onToggleExpanded?: () => void;
    /** Feld-Stil (Größe, Innenabstand, Textart-Basis) vom Aufrufer. */
    style: CSSProperties;
}): import("react/jsx-runtime").JSX.Element;
/**
 * Sichtbarer Lesetext als Markdown: zugeklappt nur die Einleitung, aufgeklappt Einleitung + Volltext.
 * R-METHODE-TXT-KOPIEREN-001.
 */
export declare function lesetextMarkdown(summary: string, volltext: string | undefined, expanded: boolean): string;
/** Bestätigungs-Haken nach dem Kopieren. */
export declare const KOPIERT_ANZEIGE_MS = 1500;
/** Kopieren-Knopf im Stil der Overlay-Knöpfe. R-METHODE-TXT-KOPIEREN-001. */
export declare function LesetextKopierenKnopf({ text }: {
    text: string;
}): import("react/jsx-runtime").JSX.Element;
