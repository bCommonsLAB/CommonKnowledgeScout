import { SceneParseError } from "../domain/scene-normalizer";
import type { RootObject } from "../domain/scene-schema";
export { SceneParseError };
/**
 * JSON-Text aus Datei oder Fetch → Laufzeit-`RootObject`.
 * **Nur HumanUX v2** (`application.humanuxVersion === 2`); Legacy-`pages[]` ohne v2 wird abgelehnt.
 */
export declare function readSceneFromJsonText(text: string): RootObject;
/**
 * Schon geparstes JSON (z. B. ein importiertes Objekt) → Laufzeit-`RootObject`. Gleiche Prüfung wie
 * {@link readSceneFromJsonText}: nur HumanUX v2.
 */
export declare function readSceneFromJson(raw: unknown): RootObject;
