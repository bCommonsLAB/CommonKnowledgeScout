import type { Page, RootObject } from "../domain/scene-schema";
/**
 * Fügt eine vom Server gelieferte Page ins Dokument ein.
 * Gleiche `id` → Ersetzen (Idempotenz bei wiederholtem Fetch).
 * Danach Referenz-onLoad wie beim großen JSON-Import.
 */
export declare function mergePageIntoDocument(doc: RootObject, page: Page): RootObject;
