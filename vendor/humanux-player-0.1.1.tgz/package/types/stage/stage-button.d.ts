/**
 * Symbol-Knopf des Players: Zoom-Knöpfe der Bühne, Schließen und Vergrößern am Media-Overlay.
 *
 * Der Player darf nichts aus den UI-Bausteinen der Anwendung importieren
 * (R-PLAYER-GRENZE-001, docs/specs/entity-player.md). Dieser Knopf ersetzt deshalb
 * `components/ui/button` an den zehn Stellen, an denen Bühne und Media-Overlay ihn nutzten.
 * Er gibt je Art genau die Klassen aus, die dort vorher herauskamen (Variante „ghost" samt
 * der Zusätze der Aufrufstelle) — am Aussehen ändert sich nichts. Mit den eigenen Stilen des
 * Players (Plan, Etappe 5) werden daraus eigene Regeln.
 */
import type { ButtonHTMLAttributes } from "react";
declare const ARTEN: {
    /** Zoom-Knöpfe unten rechts an der Bühne. */
    readonly werkzeug: "size-8 h-8 w-8 rounded-lg pointer-events-auto hover:bg-muted [&_svg:not([class*='size-'])]:size-4";
    /** Kleines Symbol ohne eigene Fläche. */
    readonly symbol: "size-6 in-data-[slot=button-group]:rounded-lg [&_svg:not([class*='size-'])]:size-3 rounded-[min(var(--radius-md),10px)] text-foreground hover:bg-muted";
    /** Kleines Symbol auf heller Fläche, über einem Medium. */
    readonly flaeche: "size-6 in-data-[slot=button-group]:rounded-lg [&_svg:not([class*='size-'])]:size-3 rounded-[min(var(--radius-md),10px)] bg-background/80 text-foreground hover:bg-background";
    /** Wie `flaeche`, eingeschaltet. */
    readonly "flaeche-an": "size-6 in-data-[slot=button-group]:rounded-lg [&_svg:not([class*='size-'])]:size-3 rounded-[min(var(--radius-md),10px)] bg-background/80 text-primary hover:bg-background";
    /** Rund, mit Schatten. */
    readonly rund: "size-6 in-data-[slot=button-group]:rounded-lg [&_svg:not([class*='size-'])]:size-3 rounded-full bg-background text-foreground shadow hover:bg-background";
};
export type StageButtonArt = keyof typeof ARTEN;
export interface StageButtonProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "className" | "type"> {
    art: StageButtonArt;
}
export declare function StageButton({ art, ...props }: StageButtonProps): import("react/jsx-runtime").JSX.Element;
export {};
