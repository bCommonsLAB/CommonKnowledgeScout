import type { ElementProps } from "../domain/scene-schema";
/** @see scene-text-content — Re-Export für ältere Importe. */
export { stripHtmlTagsForCss } from "./scene-text-content";
/** Entspricht der früheren Heuristik „Textplatte ja/nein“. */
export declare function shouldRenderTextPlateCss(props: ElementProps): boolean;
/**
 * HumanUX 6.1.5: `contentSizeX` = TMP-Textfläche (Umbruchbreite), `sizeX` = äußere Geometrie.
 * Früher wurde `sizeX` bevorzugt — dann ignoriert der Editor sichtbare `contentSizeX`-Werte,
 * sobald das Quad (z. B. Rand/Marker) eine eigene Breite hat.
 */
export declare function textColumnWorldW(props: ElementProps): number;
/**
 * Vertikale Begrenzung der Textfläche: `contentSizeY` wie TMP, sonst Fallback `sizeY`.
 */
export declare function textPlateMaxClipHeightWorld(props: ElementProps): number;
/**
 * HEURISTIK: Geschätzte Welt-Höhe der Textplatte (für %-Höhe im CSS-Stage).
 *
 * `textAnchorTop`/`textAnchorBottom` (R-STYLE-TEXT-ANCHOR-TOP-001): die Box nimmt dann IMMER die
 * volle `contentSizeY`-Kappe ein statt auf den geschätzten Inhalt zu schrumpfen — sonst füllt der
 * (kürzere) Text die Box ohnehin randvoll aus und `alignItems` (oben/unten) hat keinen Spielraum,
 * um etwas zu bewirken. Nur mit fester Boxhöhe hält die verankerte Kante Zeilenzahl-unabhängig Stand.
 */
export declare function estimateTextPlateWorldHeight(props: ElementProps): number;
