/**
 * Lineare Interpolation zwischen zwei ElementProps (Timeline-Scrub zwischen Phasen).
 */
import type { ElementProps } from "../domain/scene-schema";
/** Interpoliert sichtbare numerische und Farbfelder; diskrete Felder per Schwellwert. */
export declare function lerpElementProps(a: ElementProps, b: ElementProps, t: number): ElementProps;
