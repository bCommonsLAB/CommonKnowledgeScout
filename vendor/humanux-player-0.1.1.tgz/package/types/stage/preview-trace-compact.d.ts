/**
 * Kompaktwerte für den Wiedergabe-Trace: die zehn Eigenschaften, die die Bühne je Momentaufnahme
 * mitschreibt, Zahlen auf drei Nachkommastellen gerundet. Liegt bei der Bühne, weil sie die
 * Werte erzeugt (R-PLAYER-GRENZE-001); die Debug-Auswertung des Editors nutzt dieselben
 * Funktionen (`features/editor-v2/humanux-timeline-debug-semantics.ts`).
 */
import type { ElementProps } from "../domain/scene-schema";
import type { HumanuxCompactKey } from "../state/humanux-preview-trace-types";
export declare const HUMANUX_COMPACT_KEYS: readonly HumanuxCompactKey[];
export declare function compactPick(props: ElementProps, keys: readonly HumanuxCompactKey[]): Partial<Pick<ElementProps, HumanuxCompactKey>>;
export declare function roundUnknown(value: unknown): unknown;
