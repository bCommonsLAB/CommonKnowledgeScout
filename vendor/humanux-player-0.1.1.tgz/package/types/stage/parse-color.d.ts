/**
 * Farbparsing für die CSS-Bühne und (historisch) für Materialfarben aus dem JSON.
 * Keine Abhängigkeit von Babylon — RGB als 0–1 Floats für konsistente Tests und CSS-Ausgabe.
 */
/** RGB in 0…1 (wie früher Babylon Color3.r/g/b, ohne Engine-Typ). */
export type RgbFloat = {
    r: number;
    g: number;
    b: number;
};
/**
 * materialColor (#RRGGBB oder #RRGGBBAA) → RGB 0…1 (Alpha ignorieren).
 */
export declare function parseMaterialColorToRgbFloat(hex: string): RgbFloat;
/**
 * materialColor (#RRGGBB oder #RRGGBBAA) — RGB + optionales Hex-Alpha.
 */
export declare function parseMaterialColorWithAlpha(hex: string): {
    color: RgbFloat;
    /** Technisch aus AA gelesen; für mat.alpha nicht verwendet (siehe resolveEffectiveMaterialAlpha). */
    alphaFromHex: number | undefined;
};
/** CSS-Farbe für Canvas (nur RGB, kein Alpha aus Hex). */
export declare function materialColorToCssRgb(hex: string): string;
/**
 * CSS `rgba(...)` — RGB aus Hex, Alpha separat (z. B. `transpFont` für Text).
 */
export declare function materialColorToCssRgba(hex: string, alpha: number): string;
/**
 * Effektives `alpha` aus dem JSON-Feld `transparency` (Deckkraft / Opazität):
 * 0 = unsichtbar, 1 = undurchsichtig.
 * Hinweis: Einige Legacy-JSONs hatten Headlines fälschlich mit 0 — dann war nichts zu sehen.
 * Kein Hex-Alpha — `materialColor` ist nur `#RRGGBB` (bzw. RGB aus 9-stelligem Hex).
 */
export declare function resolveEffectiveMaterialAlpha(transparency: number): number;
