/**
 * Legacy-Semantik: JSON-Größe 8 = halbe Referenz in der vertikalen Skala (wie im Original
 * gedacht). Maßstab ist die halbe **Höhe** des roten Rahmens (nicht die Breite):
 * halbe logische Bildschirmhöhe in Welt = (maxY−minY)/2. Mit Referenz 8 gilt:
 * sizeX = sizeY = 8 → Kreisdurchmesser = halbe Rahmenhöhe in Welt.
 *
 * X und Y nutzen denselben Faktor, damit Quadrate/Kreise isotrop in Welt-Einheiten bleiben.
 *
 * Zusätzlich {@link JSON_SIZE_WORLD_SCALE_MULTIPLIER}: visueller Feintuning-Faktor (aktuell 3×),
 * bis JSON-Größen und Kamera optisch „passen“ — Positionen bleiben unverändert, nur Größen.
 */
export declare const JSON_SIZE_UNITS_HALF_SCREEN = 8;
/** Globale Verstärkung der JSON-Größen gegenüber dem reinen Referenzmaßstab (nur size*, nicht position*). */
export declare const JSON_SIZE_WORLD_SCALE_MULTIPLIER = 3;
/** JSON sizeX / contentSizeX → Welt (Breite von Planes, Text, Bounds). */
export declare function scaleJsonSizeXToWorld(sizeX: number): number;
/** JSON sizeY → Welt (Höhe). */
export declare function scaleJsonSizeYToWorld(sizeY: number): number;
/**
 * Roh-Maß: gleiche JSON→Welt-Pipeline wie `sizeY` (für Vergleiche / Tests).
 * Für **Anzeige** (CSS) siehe {@link scaleJsonFontSizeToDisplayWorld}.
 */
export declare function scaleJsonFontSizeToWorld(fontSize: number): number;
/**
 * TMP-`fontSize` ist **keine** Flächengröße; volle `scaleJsonSizeYToWorld`-Größe wirkt
 * in CSS ~10× zu groß. Dieser Faktor kalibriert Schrift + Zeilenhöhe zur Bühne.
 * Die resultierende Pixelgröße skaliert mit Zoom wie die Flächen — ohne separates CSS-`clamp`.
 */
/** Feintuning Display-Schrift (CSS + Zeilenhöhe); bei Bedarf anpassen. */
export declare const JSON_FONT_DISPLAY_SCALE = 0.095;
/** Welt-Einheiten für Text (CSS-Schriftgröße und Zeilenhöhe der Textplatte). */
export declare function scaleJsonFontSizeToDisplayWorld(fontSize: number): number;
