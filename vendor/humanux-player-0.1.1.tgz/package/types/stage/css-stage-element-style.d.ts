import type { CSSProperties } from "react";
import type { ElementProps } from "../domain/scene-schema";
import type { CssElementLayout } from "./scene-to-css-mapping";
export declare function computeStageElementZIndex(_layout: CssElementLayout, isSelected: boolean, isDragging: boolean, 
/** Styles-Modus: Paket-Hervorhebung (unter Auswahl, über Normalzustand). */
isStyleHighlight?: boolean, 
/** Reihenfolge aus `pages[].elements` (0 = hinten). */
renderOrder?: number): number;
/** Ebenen-Auswahl der Kulisse (viewport-fixierte Overlay-Gruppen). Default „top" (Vordergrund). */
export type ViewportGroupZLayer = "top" | "normal" | "background";
/**
 * z-index einer viewport-fixierten Overlay-Gruppe (Kulisse) relativ zum Bühneninhalt.
 * Bühnen-Elemente liegen bei `renderOrder×10` (bis einige Tausend), Hover-Tooltips bei ~200000.
 * - `top` (Default der Kulisse): über allem Bühneninhalt (auch Hover-Tooltips).
 * - `normal`: konkurriert mit dem Bühneninhalt (Alt-Verhalten — kann überdeckt werden).
 * - `background`: hinter dem Bühneninhalt (containerRef ist isoliert → bleibt über dem Hintergrund).
 * Verbindlich: R-GROUP-KULISSE-ZLAYER-001.
 */
export declare function viewportGroupZIndex(zLayer: ViewportGroupZLayer | undefined): number;
/** Preview-Phasenwechsel: Ease-in-out (Material-ähnlich). */
export declare const CSS_PREVIEW_PHASE_EASING = "cubic-bezier(0.4, 0, 0.2, 1)";
export type CssStageElementStyleArgs = {
    layout: CssElementLayout;
    zIndex: number;
    inPreviewTransition: boolean;
    transitionDurationMs: number;
    isSelected: boolean;
    /** Styles-Editor: Element nutzt das ausgewählte Paket — strichlierte Kontur (wie Auswahl, Farbe unten). */
    isStyleHighlight?: boolean;
    /** Optional: `Element.className` aus der Szene. */
    sceneClassName?: string | null;
};
/**
 * Inline-Styles für ein absolut positioniertes Szenenelement (Mittelpunkt-Semantik).
 */
export declare function buildCssStageElementStyle(args: CssStageElementStyleArgs): CSSProperties;
export type CssStageTextSpanStyleArgs = {
    fontSizePx: number | null;
    fontBold: boolean;
    /** Gesetzt wenn JSON `fontFamily` gesetzt (z. B. RobotoMono). */
    fontFamily: string | undefined;
    /**
     * Optional: Verschiebung des Textblocks in CSS-Pixel (`translate`).
     * Kommt aus `textPositionX`/`textPositionY` × pxPerWorld (siehe {@link textPositionOffsetPx}).
     */
    offsetPx?: {
        x: number;
        y: number;
    };
    /**
     * JSON `textart` (R-STYLE-TEXTARTEN-002): gesetzt und bekannt → Schrift, Schnitt, Stil,
     * Zeilenhöhe und `hyphens: none` aus der Textart (überschreibt `fontFamily`/`fontBold`).
     * Leer oder unbekannt → bisheriges Verhalten.
     */
    textart?: string;
};
/**
 * JSON `textPositionX`/`textPositionY` (Welt) → Pixel für CSS `translate` auf dem Text-`span`.
 * Gleiche X/Y-Semantik wie die Elementposition: positives Y auf der Bühne = nach oben → negatives `translateY`.
 */
export declare function textPositionOffsetPx(props: Pick<ElementProps, "textPositionX" | "textPositionY">, pxPerWorld: number): {
    x: number;
    y: number;
};
/**
 * Schriftgröße **ohne** zusätzliche CSS-Min/Max: nur `fontSizePx` aus derselben
 * Welt→Pixel-Kette wie Breite/Höhe (`scene-to-css-mapping` × Zoom). Beim Rauszoomen
 * wird die Schrift entsprechend klein (ggf. unsichtbar) — absichtlich, damit das Layout
 * nicht durch willkürliche `clamp`-Deckel verzerrt wird.
 */
export declare function buildCssStageTextSpanStyle(args: CssStageTextSpanStyleArgs): CSSProperties;
/**
 * Hover-Titel an Icons (Leader Line, R-ENTITY-DOCUMENT-TITLE-001): Fließtext · Überschrift
 * (Metropolitano bold) im Bühnenmaß — Entscheidung 2 der Nutzer:in, R-STYLE-TEXTARTEN-002.
 * Einzeilig (`nowrap`), deshalb Zeilenhöhe 1 statt der Textart-Zeilenhöhe.
 */
export declare function hoverTitleStyle(pxPerWorld: number): CSSProperties;
