/**
 * JSON `fontFamily` → CSS bzw. Canvas-`font`-String.
 * Leer = kein Override (Browser-/Editor-Default).
 *
 * Alias `RobotoMono` / `Roboto Mono` nutzt die in `layout.tsx` geladene Variable
 * `--font-roboto-mono` (Next.js `Roboto_Mono`).
 * `MaziusDisplay` / `Metropolitano`: selbst gehostet unter `public/fonts/` (siehe `globals.css`).
 */
export declare function normalizeFontFamilyKey(raw: string): string;
/** CSS `font-family` für die DOM-Textplatte (kann `var(--font-…)` nutzen). */
export declare function resolveCssFontFamilyForText(jsonFontFamily: string): string | undefined;
/**
 * Canvas 2D `font` — keine CSS-Variablen; feste Stack-Namen, wenn die Schrift
 * auf der Seite geladen ist (Next/font lädt „Roboto Mono“; Mazius/Metropolitano via `@font-face`).
 */
export declare function resolveCanvasFontFamilyForText(jsonFontFamily: string): string;
