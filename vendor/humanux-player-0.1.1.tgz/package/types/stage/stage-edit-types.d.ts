/**
 * Formen, über die der Editor mit der Bühne spricht: was beim Ziehen flüchtig gezeigt wird, was
 * der Inspektor vorab zeigt und was aus dem Baum auf die Bühne fällt. Sie liegen bei der Bühne,
 * weil sie deren Eigenschaften beschreiben; der Zustand des Editors bezieht sie von hier
 * (R-PLAYER-GRENZE-001, docs/specs/entity-player.md).
 */
import type { EditPhase, ElementProps } from "../domain/scene-schema";
export interface HumanuxStageDragPreview {
    kind: "entity" | "stageGroup";
    id: string;
    viewIndex: number;
    worldPositionX?: number;
    worldPositionY?: number;
    rotationZ?: number;
    sizeX?: number;
    sizeY?: number;
}
export interface HumanuxInspectorPreviewPatch {
    kind: "entity" | "stageGroup";
    id: string;
    viewIndex: number;
    phase: EditPhase;
    patch: Partial<ElementProps>;
}
export type HumanuxTreeDropItem = {
    kind: "entity";
    id: string;
} | {
    kind: "semanticGroup";
    id: string;
} | {
    kind: "stageGroup";
    id: string;
};
