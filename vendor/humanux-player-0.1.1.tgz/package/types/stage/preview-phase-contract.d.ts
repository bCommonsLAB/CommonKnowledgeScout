import type { EditPhase, ElementProps } from "../domain/scene-schema";
import { type PreviewPhaseNode } from "./preview-transition-frames";
export declare function resolvePreviewPhaseForNode(node: PreviewPhaseNode, fromPhase: EditPhase, toPhase: EditPhase, side: "from" | "to"): EditPhase;
export declare function resolvePreviewPropsForNode(node: PreviewPhaseNode, fromPhase: EditPhase, toPhase: EditPhase, side: "from" | "to"): ElementProps;
export declare function resolveCrossPageTransitionProps(fromNode: PreviewPhaseNode | undefined, toNode: PreviewPhaseNode | undefined, fromPhase?: EditPhase, toPhase?: EditPhase): {
    fromProps: ElementProps | null;
    toProps: ElementProps | null;
};
