/** Deterministischer Start-Offset aus Element-ID (verschiedene Instanzen nicht synchron). */
export declare function hashStringToSeed(s: string): number;
export declare function AmorphTagBlobSvg({ elementId, materialColor, transparency, amorphAmount, amorphSpeed, amorphStretch, amorphSoftness, }: {
    elementId: string;
    materialColor: string;
    transparency: number;
    amorphAmount: number;
    amorphSpeed: number;
    amorphStretch: number;
    amorphSoftness: number;
}): import("react/jsx-runtime").JSX.Element;
