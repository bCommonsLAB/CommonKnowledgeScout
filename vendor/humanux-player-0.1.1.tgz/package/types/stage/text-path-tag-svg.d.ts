/**
 * Statisches Inline-SVG für `shape === "text-path-tag"`: Text auf Ring-Pfad um eine Mitte.
 * Hover/Morph/Welle: spätere Iteration (Pfad-Animation, zweiter Pfad).
 */
import type { SceneTextSegment } from "./scene-text-segment-types";
export declare function TextPathTagSvg({ elementId, materialColor, transparency, fontColor, transpFont, fontSizePx, fontFamilyCss, segments, }: {
    /** Eindeutige DOM-`id` für Pfad-Referenz (mehrere Instanzen auf der Bühne). */
    elementId: string;
    materialColor: string;
    transparency: number;
    fontColor: string;
    transpFont: number;
    fontSizePx: number;
    /** Bereits aufgelöster Stack, z. B. `"Metropolitano", sans-serif` */
    fontFamilyCss: string | null;
    segments: readonly SceneTextSegment[];
}): import("react/jsx-runtime").JSX.Element;
