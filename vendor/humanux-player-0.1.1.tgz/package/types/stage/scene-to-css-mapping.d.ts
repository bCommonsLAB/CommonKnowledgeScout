import type { ElementProps } from "../domain/scene-schema";
import type { SceneTextSegment } from "./scene-text-segment-types";
export { stripHtmlTagsForCss, shouldRenderTextPlateCss, estimateTextPlateWorldHeight, } from "./scene-to-css-text-plate";
export type { SceneTextSegment } from "./scene-text-segment-types";
/**
 * HEURISTIK: Rotationswinkel für CSS `transform: rotate(...)`.
 *
 * - `square` / `quad`: wie Kreis nur `rotationZ` — sonst wären Handles/Text bei symmetrischem Quad um 180° versetzt.
 * - Sonstige planare Legacy-Flächen: +180° (3D-Plane-Basis).
 * - Textplatte (`isText`): nur `rotationZ`.
 */
export declare function cssRotationDegFromProps(props: ElementProps, isText: boolean): number;
/**
 * Welt-Breite/-Höhe eines Elements (gleiche Heuristik wie {@link buildCssElementLayout}) —
 * für verschachtelte Parent-Boxen auf der CssStage.
 */
export declare function elementWorldDimensions(props: ElementProps): {
    worldW: number;
    worldH: number;
};
/** Metriken vom Viewport-Rechteck in Weltkoordinaten (Ausgabe von `computeViewportMetrics` in css-layout). */
export type CssViewportMetrics = {
    spanX: number;
    spanY: number;
    minXv: number;
    maxYv: number;
    pxPerWorld: number;
};
export interface CssElementLayout {
    /** Prozent relativ zum Stage-Container (0–100). */
    leftPct: number;
    topPct: number;
    widthPct: number;
    heightPct: number;
    rotationDeg: number;
    opacity: number;
    /** Fill für Flächen bzw. Textfarbe. */
    colorCss: string;
    /** Nur Flächen (nicht Text). */
    backgroundColorCss: string;
    borderRadiusPct: string;
    /** Wenn gesetzt: `shape` referenziert ein SVG unter `public/` — Bühne rendert `<img>`. */
    svgPublicUrl: string | null;
    /** Wenn gesetzt: `shape` referenziert ein Bild unter `public/` — Bühne rendert `<img>`. */
    imagePublicUrl: string | null;
    /** `shape === "amorph-tag"`: Bühne rendert inline `<svg>`-Blob statt CSS-Fläche. */
    amorphTag: boolean;
    /** `shape === "text-path-tag"`: Bühne rendert Text auf SVG-Pfad (Ring). */
    textPathTag: boolean;
    isText: boolean;
    /** Nur Text: sichtbarer Klartext (ohne HTML/Markdown-Syntax). */
    textContent: string;
    /** Nur Text: Inline-Segmente für Fett/Kursiv/Links (CSS-Bühne). */
    textInlineSegments: readonly SceneTextSegment[];
    /**
     * Nur Text: einheitlich „fett“ (ein Segment, nur bold) — für Kompatibilität;
     * gemischte Styles laufen über {@link textInlineSegments}.
     */
    fontBold: boolean;
    /**
  
     * Nur Text: Pixelgröße aus derselben Welt→Pixel-Skalierung wie die restliche Bühne.
  
     */
    fontSizePx: number | null;
    /** Nur Text: `font-family` oder `null` (Default). */
    fontFamilyCss: string | null;
    /** Nur Text: `true` = oben verankert (Text wächst nach unten); `false` = vertikal zentriert (Default). */
    textAnchorTop: boolean;
    /** Nur Text: `true` = unten verankert (Zeilen wachsen nach oben). `textAnchorTop` hat Vorrang. */
    textAnchorBottom: boolean;
}
/**

 * NORMATIV (Mapping): Mittelpunkt `positionX/Y` → Prozent; Y-Achse Bildschirm nach oben

 * (`topPct` aus `maxYv - positionY`).

 *

 * HEURISTIK: Welt-Breite/-Höhe aus JSON (Textplatte, Kreis, Rechteck) wie Doku.

 */
export declare function buildCssElementLayout(props: ElementProps, metrics: CssViewportMetrics): CssElementLayout;
