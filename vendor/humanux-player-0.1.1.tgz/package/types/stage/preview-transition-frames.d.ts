import type { EditPhase, ElementProps, PreviewPhaseHints } from "../domain/scene-schema";
import { type HumanUxComposedMotionSpec } from "../domain/humanux-motion";
import type { PreviewPhaseMotionHints } from "../domain/scene-schema";
export type PreviewPhaseNode = {
    id?: string;
    onLoadProps: ElementProps | null;
    onShowProps: ElementProps;
    onLeaveProps: ElementProps;
    previewPhaseHints?: PreviewPhaseHints;
    previewPhaseMotionHints?: PreviewPhaseMotionHints;
};
/**
 * Sequentielles Timing bei Cross-Page-Transitionen:
 * - "exit-only": Element existiert nur auf der Quellseite (verschwindet) → erste Haelfte
 * - "enter-only": Element existiert nur auf der Zielseite (erscheint) → zweite Haelfte
 * - undefined: Element auf beiden Seiten → voller Progress (keine Aenderung)
 */
export type TransitionSide = "exit-only" | "enter-only";
export type PreviewTransitionFrame = {
    fromProps: ElementProps;
    toProps: ElementProps;
    fromPhaseSource: EditPhase;
    toPhaseSource: EditPhase;
    fromKeys?: ReadonlyArray<keyof ElementProps>;
    toKeys?: ReadonlyArray<keyof ElementProps>;
    exitAnchorProps?: ElementProps;
    enterAnchorProps?: ElementProps;
    exitAnchorKeys?: ReadonlyArray<keyof ElementProps>;
    enterAnchorKeys?: ReadonlyArray<keyof ElementProps>;
    exitAnchorSource?: EditPhase;
    enterAnchorSource?: EditPhase;
    composedMotionSpec?: HumanUxComposedMotionSpec;
    /** Sequentielles Timing: exit-only animiert in erster Haelfte, enter-only in zweiter. */
    transitionSide?: TransitionSide;
};
export declare function resolvePreviewTransitionFrameForNode(node: PreviewPhaseNode, fromPhase: EditPhase, toPhase: EditPhase): PreviewTransitionFrame;
export declare function resolvePreviewTransitionFrameAcrossPages(fromNode: PreviewPhaseNode | undefined, toNode: PreviewPhaseNode | undefined, fromPhase?: EditPhase, toPhase?: EditPhase): PreviewTransitionFrame | null;
