/**
 * Geometrie fuer das eingebaute Shape `amorph-tag`: 8 radiale Stuetzpunkte,
 * weich geschlossene Kubik-Bezier-Kurve. Reine Funktionen fuer Tests und Renderer.
 */
export type AmorphBlobOptions = {
    /** 0…1, skaliert intern auf moderate Deformation */
    amount: number;
    /** 0…1, skaliert intern auf langsamen Wechsel stehend/liegend */
    stretch: number;
    /** 0…1, hoeher = weichere Kurven (Tension) */
    softness: number;
    /** 0…1: Geschwindigkeit der Phasenbewegung (langsam … etwas schneller). */
    speed: number;
};
/**
 * Skaliert alle Punkte vom Zentrum so, dass der groesste Abstand `targetMaxR` ist.
 * Die **relative** Form bleibt (wie bei kleinem baseR), die Silhouette fuellt aber die ViewBox
 * wie ein Kreis — ohne den weissen Rand, den baseR=38 ohne Skalierung erzeugt haette.
 */
export declare function scalePointsToMaxRadius(points: {
    x: number;
    y: number;
}[], cx: number, cy: number, targetMaxR: number): void;
/**
 * 8 Punkte auf einem annaehernd kreisfoermigen Blob; `t` in Sekunden.
 * `seed` unterscheidet Instanzen deterministisch.
 */
export declare function computeAmorphBlobPoints(t: number, opts: AmorphBlobOptions, seed: number): {
    x: number;
    y: number;
}[];
/**
 * Geschlossene Kubik-Bezier durch die Stützpunkte — **uniform Catmull-Rom → Cubic Bezier**.
 *
 * Wichtig: Der klassische Faktor ist **1/6** pro Segment (C1-stetig, keine sichtbaren Kanten).
 * Früher war die untere Grenze zu klein (≈0,12) — dann liegen C1/C2 fast auf der Sehne und
 * man sieht ein **Vieleck mit geraden Kanten**. `softness` skaliert nur noch **ab** 1/6 nach oben.
 */
export declare function pointsToClosedSmoothPath(points: {
    x: number;
    y: number;
}[], softness01: number): string;
export declare function buildAmorphBlobPathD(tSec: number, opts: AmorphBlobOptions, seed: number): string;
