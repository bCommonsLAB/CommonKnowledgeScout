import type { CSSProperties, ReactNode } from "react";
import type { SceneTextSegment } from "./scene-text-segment-types";
type Props = {
    segments: readonly SceneTextSegment[];
    /**
     * Basis-Stil — kommt von {@link buildCssStageTextSpanStyle} mit `fontBold: false`.
     * `fontWeight`/`fontStyle` daraus gelten für NICHT ausgezeichnete Segmente (z. B. light 300 /
     * kursiv einer Textart, R-STYLE-TEXTARTEN-002).
     */
    baseSpanStyle: CSSProperties;
};
/** Schnitt eines Segments: `**fett**` → 600 (ohne Textart) bzw. 700 (Textart), sonst der Basis-Schnitt. */
export declare function segmentFontWeight(bold: boolean, baseWeight: CSSProperties["fontWeight"], hasTextart: boolean): CSSProperties["fontWeight"];
/**
 * Rendert Markdown-Segmente auf der CSS-Bühne (Fett/Kursiv/Links/Durchstreichung).
 */
export declare function SceneTextSegments({ segments, baseSpanStyle }: Props): ReactNode;
export {};
