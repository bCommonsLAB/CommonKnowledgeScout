/**
 * Szenen-Text (`ElementProps.content`): Legacy-HTML + eingeschränktes Inline-Markdown
 * nur für die CSS-Bühne. Gespeicherter String bleibt unverändert — keine Auswirkung
 * auf HumanUX-Compiler, JSON oder Animationslogik.
 *
 * Unterstützt: **fett**, *kursiv*, ***fett+kursiv***, __fett__, _kursiv_, ~~durchgestrichen~~,
 * Zeilenumbrüche, [Label](https://url) (nur http/https oder Pfade ab /).
 *
 * Parser: {@link inline-markdown-parse}
 */
export type { SceneTextSegment } from "./scene-text-segment-types";
/** Legacy: HTML-Tags für Höhen-/Breitenheuristik entfernen (sichtbarer Text). */
export declare function stripHtmlTagsForCss(raw: string): string;
/** `<b>`, `<strong>`, `<i>`, `<em>`, `<br>` → Markdown-äquivalent; übrige Tags entfernen. */
export declare function preprocessSceneTextContent(raw: string): string;
/** Sichtbarer Klartext für Textplatten-Höhe/Zeilenschätzung (ohne Markdown-Syntax). */
export declare function plainTextFromSceneContent(raw: string): string;
/**
 * Parst Inline-Markdown nach Vorverarbeitung (kein Roh-HTML mehr).
 */
export declare function parseInlineMarkdown(preprocessed: string): import("./scene-text-segment-types").SceneTextSegment[];
