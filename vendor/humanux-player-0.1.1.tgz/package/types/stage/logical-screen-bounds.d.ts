/**
 * Logischer „Bildschirm“ in Weltkoordinaten (Proportionen wie Monitor/Canvas-Seitenverhältnis).
 * X: −14 … +14 (Breite 28); Y: −8 … +8 (Höhe 16) — gleiche Einheit wie position/size.
 *
 * **Projektentscheidung (Viewport):** Dieses Rechteck ist das **feste Anzeige-Fenster** der
 * orthographischen Bühne (roter Rahmen in CSS). Es ist **nicht** automatisch
 * identisch mit den in HumanUX empfohlenen **inhaltlichen** Arbeitsbereichen — JSON-Objekte
 * dürfen weiter außerhalb liegen; der Editor zeigt sie per Zoom/Pan.
 *
 * Doku: `docs/scene description editor/scene-description-spec-1.0/css-render-mapping-and-viewport.md`
 */
export declare const LOGICAL_SCREEN_BOUNDS: {
    readonly minX: -14;
    readonly maxX: 14;
    readonly minY: -8;
    readonly maxY: 8;
    /** Leicht vor der Szene, damit der Rahmen sichtbar bleibt (CSS nutzt dieselbe Logik visuell). */
    readonly z: 0.02;
};
/**
 * **Medienmitte der Bühne** — der Ort, an dem ein Media-Overlay erscheint.
 *
 * Bewusst **nicht** (0, 0): Die Mittelachse des Entwurfs (260910 website-maße.pdf, S. 2/3)
 * liegt bei Seiten-X 501.9 pt, also Welt X **−2.09** — rechts belegen Icon-Spalte und Menü
 * mehr Raum als die linke Spalte, die optische Mitte wandert dadurch nach links.
 * Der Y-Wert 0.656 setzt die Oberkante des Players auf die Oberkante des Bühnenfelds.
 *
 * In **Welt**-Einheiten gehalten, nicht in Pixeln: die Komposition skaliert uniform
 * (`fitMode: "contain"`), damit sitzt das Overlay bei jeder Fenstergröße auf der Achse.
 *
 * Verbindlich: R-OVERLAY-MITTELACHSE-001 (`docs/specs/entity-overlay.md`).
 */
export declare const BUEHNEN_MEDIEN_MITTE_WELT: {
    readonly x: -2.084;
    readonly y: 0.656;
};
