import type { EditPhase, Page } from "../domain/scene-schema";
export interface WorldBounds {
    minX: number;
    maxX: number;
    minY: number;
    maxY: number;
}
export declare function computePageBoundsOnShow(page: Page): WorldBounds;
/**
 * Kamera-Rahmen: aktuelle Edit-Phase (wie die Meshes) + roter Logik-Bildschirm.
 */
export declare function computePageBoundsForCamera(page: Page, editPhase: EditPhase): WorldBounds;
/**
 * Bounding Box nur für die gewählte Gruppe oder Entity (Teilbaum ab diesem Knoten) in der Phase —
 * für manuelles „Zoom Selection“ auf der Bühne.
 */
export declare function computeSubtreeBoundsForPhase(page: Page, nodeId: string, editPhase: EditPhase): WorldBounds | null;
