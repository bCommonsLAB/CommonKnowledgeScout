/**
 * CSS-Bühne: **Viewport-Mathematik** (Zoom/Pan, Client → Welt, Referenzrahmen in Prozent).
 *
 * Die Übersetzung **ElementProps → Layout/Farbe/Rotation** liegt in `scene-to-css-mapping.ts`
 * (Norm vs. Heuristik: siehe `docs/.../css-render-mapping-and-viewport.md`).
 */
import type { ElementProps } from "../domain/scene-schema";
import type { WorldBounds } from "./page-bounds";
import { type CssElementLayout, type CssViewportMetrics } from "./scene-to-css-mapping";
export type { CssElementLayout };
/** Re-Exports für Aufrufer, die weiterhin `css-layout` importieren. */
export { stripHtmlTagsForCss, shouldRenderTextPlateCss, estimateTextPlateWorldHeight, cssRotationDegFromProps, } from "./scene-to-css-mapping";
/**
 * Sichtfenster für CSS-Bühne — gleiche Zoom-Semantik wie orthographisches Einpassen des roten Rahmens:
 * `zoomScale` 1 = voller logischer Rahmen; &lt;1 = stärker reinzoomen; &gt;1 = rauszoomen.
 */
export type CssViewport = {
    targetX: number;
    targetY: number;
    zoomScale: number;
};
export type CssViewportFitMode = "contain" | "cover";
export declare const DEFAULT_CSS_VIEWPORT: CssViewport;
type CssContainerSize = {
    widthPx: number;
    heightPx: number;
};
export declare function computeViewportMetrics(viewport: CssViewport, containerSize: CssContainerSize, fitMode: CssViewportFitMode): {
    spanX: number;
    spanY: number;
    minXv: number;
    maxYv: number;
    pxPerWorld: number;
};
/**
 * Clientpunkt → Welt mit aktuellem Viewport (Zoom/Pan). Ohne Zoom wie bisheriges Verhalten.
 */
export declare function clientPointToWorldWithViewport(containerRect: DOMRectReadOnly, clientX: number, clientY: number, viewport: CssViewport, fitMode?: CssViewportFitMode): {
    positionX: number;
    positionY: number;
};
/**
 * Bildschirm-/Clientpunkt relativ zum Stage-Container → Welt (voller logischer Rahmen, Zoom 1).
 */
export declare function clientPointToWorldPosition(containerRect: DOMRectReadOnly, clientX: number, clientY: number): {
    positionX: number;
    positionY: number;
};
/**
 * Neuer Viewport-Mittelpunkt, sodass `worldX/worldY` unter dem Cursor beim Zoomen bleibt.
 */
export declare function computeCssZoomTargetPreservingWorldPoint(worldX: number, worldY: number, oldTargetX: number, oldTargetY: number, newZoomScale: number, oldZoomScale: number): {
    tx: number;
    ty: number;
};
/**
 * Viewport so, dass die gegebenen Welt-Bounds in die Stage passen (wie Kamera-Fit).
 * Roter Referenzrahmen (28×16) liegt in `computePageBoundsForCamera` bereits in den Bounds —
 * gleiche Quelle wie im Editor-Viewport.
 */
export declare function computeViewportFitWorldBounds(bounds: WorldBounds, options?: {
    zoomMin?: number;
    zoomMax?: number;
    margin?: number;
}): CssViewport;
/** Menü-Zoom: diskrete Schrittweite (multiplikativ). ~`MENU_ZOOM_STEPS` Stufen vom fit (zoom-all). */
export declare const MENU_ZOOM_STEP_FACTOR = 1.35;
/** Anzahl Stufen von „ganz groß" (max rein) bis „zoom all" (fit, raus-Grenze). */
export declare const MENU_ZOOM_STEPS = 10;
/**
 * Eine Zoomstufe des Menü-`+`/`−`. `direction: "out"` → Richtung **zoom-all** (geclampt am fit),
 * `"in"` → Richtung **ganz groß** (geclampt bei `fit / FACTOR^(STEPS-1)`).
 * Zentriert auf das fit-Zentrum (Bildschirmmitte ≈ Inhalts-Zentrum).
 */
/**
 * Zoom-Grenzen relativ zum Seiten-Fit: `zoomOut` = **zoom-all** (raus-Grenze, = fit),
 * `zoomIn` = **ganz groß** (rein-Grenze). Höherer `zoomScale` = weiter draußen.
 */
export declare function menuZoomScaleBounds(fit: CssViewport): {
    zoomIn: number;
    zoomOut: number;
};
export declare function computeMenuZoomStep(currentScale: number, fit: CssViewport, direction: "in" | "out"): CssViewport;
/**
 * Sichtfenster innerhalb der Seiten-Ränder halten (Pan-Clamp): ragt das Fenster über
 * `bounds` hinaus, wird `target` nach innen geschoben. Ist das Fenster **größer** als der
 * Inhalt (voll herausgezoomt), wird auf das Inhalts-Zentrum zentriert. So bleibt beim
 * Hineinzoomen der Cursor-Fixpunkt erhalten, solange das Fenster im Rahmen liegt.
 */
export declare function constrainViewportTargetToBounds(viewport: CssViewport, containerSize: CssContainerSize, fitMode: CssViewportFitMode, bounds: WorldBounds): CssViewport;
/**
 * Roter Referenzrahmen (`LOGICAL_SCREEN_BOUNDS`): feste 28×16 Welt-Einheiten, Mittelpunkt (0,0).
 * Gleiche Abbildung wie bei Elementen — zoomt/pannt mit dem Viewport, nicht als fester HTML-Rand.
 */
export declare function logicalScreenFramePercentLayout(viewport: CssViewport): {
    leftPct: number;
    topPct: number;
    widthPct: number;
    heightPct: number;
};
export declare function logicalScreenFramePercentLayoutForContainer(viewport: CssViewport, containerSize: CssContainerSize, fitMode?: CssViewportFitMode): {
    leftPct: number;
    topPct: number;
    widthPct: number;
    heightPct: number;
};
/**
 * Mappt ElementProps auf Prozent-Layout im logischen Bildschirm (28×16 Welt-Einheiten).
 * `viewport`: Zoom/Pan — gleiche Idee wie eine orthographische 2D-Kamera.
 */
export declare function elementPropsToCssLayout(props: ElementProps, viewport?: CssViewport, containerSize?: CssContainerSize, fitMode?: CssViewportFitMode): CssElementLayout;
/**
 * Viewport-Metriken für Kinder **innerhalb** der Parent-Box in Weltkoordinaten
 * (Parent-Mittelpunkt ± halbe Ausdehnung wie `buildCssElementLayout`).
 */
export declare function viewportMetricsForParentWorldBox(parentProps: ElementProps, globalMetrics: CssViewportMetrics): CssViewportMetrics;
