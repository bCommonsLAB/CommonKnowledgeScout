/**
 * Gemeinsamer Typ für Szenen-Text-Segmente (CSS-Bühne).
 */
/** Sichtbarer Textlauf mit optionalen Inline-Stilen (und optional Link). */
export type SceneTextSegment = {
    text: string;
    bold: boolean;
    italic: boolean;
    strike?: boolean;
    /** Wenn gesetzt: klickbarer Link (nur sichere hrefs). */
    href?: string;
};
