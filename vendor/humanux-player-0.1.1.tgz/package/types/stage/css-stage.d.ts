import { type ReactNode } from "react";
import type { EditPhase, ElementProps, RootObject } from "../domain/scene-schema";
import type { HumanuxInspectorPreviewPatch, HumanuxStageDragPreview, HumanuxTreeDropItem } from "./stage-edit-types";
import { type CssViewportFitMode } from "./css-layout";
/**
 * „Aktiv"-Render des vierten Interaktionszustands: solange das Media-Overlay eines Darstellers
 * offen ist, wird sein ruhendes Quad hartcodiert AUSGEBLENDET — der Darsteller schwebt stattdessen
 * als Player in die Bühnenmitte (kein Authoring-Feld).
 * Verbindlich: R-ENTITY-MEDIA-OVERLAY-ACTIVE-STATE-001 (docs/specs/entity-entity.md).
 */
export declare const MEDIA_OVERLAY_ACTIVE_CLASS = "is-media-overlay-source";
/** „Aktiv"-Zustand: ruhendes Ohr ausgeblendet (Darsteller schwebt als Player in die Mitte). */
export declare const MEDIA_OVERLAY_SOURCE_HIDDEN_OPACITY = 0;
/** Blende, mit der ein weichender Darsteller einem Bühnenmedium Platz macht (R-ENTITY-MEDIA-STAGE-ROLE-001). */
export declare const MEDIUM_WEICHT_BLENDE_MS = 300;
type TransformPatch = Partial<Pick<ElementProps, "positionX" | "positionY" | "rotationZ" | "sizeX" | "sizeY">>;
export interface CssStageProps {
    document: RootObject | null;
    pageIndex: number;
    editPhase: EditPhase;
    selectedElementId: string | null;
    /** Runtime-Gruppe: Auswahlrahmen auf Gruppen-Container. */
    selectedGroupId?: string | null;
    onSelectElement: (id: string | null) => void;
    /** Optional: Gruppe auf der Bühne wählen (HumanUX-Editor). */
    onSelectGroup?: (id: string | null) => void;
    onTransformElement?: (id: string, patch: TransformPatch) => void;
    onDropTreeItem?: (item: HumanuxTreeDropItem, x: number, y: number) => void;
    /** Flüchtige Weltposition während Drag; Inspector kann daraus sofort Live-Zahlen anzeigen. */
    onStageDragPreviewChange?: (preview: HumanuxStageDragPreview | null) => void;
    onStageDragPreviewClear?: () => void;
    inspectorPreviewPatch?: HumanuxInspectorPreviewPatch | null;
    isElementDraggable: (id: string) => boolean;
    /**
     * Hintergrund-Ebene der Bühne: füllt den Container, liegt hinter allen Elementen (auch hinter
     * Kulisse-Gruppen) und über der Seitenfarbe. Für eingebettete Fremdinhalte (z. B. die
     * KnowledgeScout-Galerie auf der Seite „Index“); Mausrad und Klicks kommen dort an.
     */
    underlay?: ReactNode;
    /**
     * HumanUX v2 Styles-Modus: Entity-IDs, die das aktuell gewählte Style-Paket nutzen —
     * strichlierte Kontur auf der Bühne (zusätzlich zur normalen Auswahl).
     */
    styleHighlightElementIds?: readonly string[] | null;
    /** Optional: v2 kann die Preview-Dauer pro Transition an View-Grenzen anpassen. */
    previewTransitionDurationMs?: number | null;
    /**
     * HumanUX: float-Zeitleisten-Position beim Ziehen — Bühne interpoliert zwischen benachbarten Phasen.
     * null = kein aktives Scrub.
     */
    timelineScrubLinear?: number | null;
    /**
     * Wie die Bühne in ihren Rahmen passt (R-PLAYER-VERTRAG-004): `contain` (Standard) zeigt das
     * ganze Sichtfeld 28×16 mit Rändern, `cover` füllt den Rahmen und schneidet am Rand ab.
     */
    einpassen?: CssViewportFitMode;
    /**
     * Durchsichtiger Hintergrund (R-PLAYER-VERTRAG-004): ohne eigene Farbe der Bühne malt sie nichts
     * und der Gastgeber scheint durch. Eine Farbe aus `Page.stageStyle` gilt weiterhin.
     */
    durchsichtig?: boolean;
}
/**
 * DOM/CSS-Preview-Bühne: Phasen-Logik onLoad/onShow/onLeave, Übergänge per CSS `transition`.
 * Abschluss per Timeout mit Dauer aus `preview-timing` (gleiche Referenzdauer wie die Zeitleiste).
 * Editor: Auswahl, Drag (wenn `draggable`), gestrichelter Auswahlrahmen.
 * Roter Rahmen = logisches Premium-Sichtfeld (28×16 Welt). Zoom/Pan: Mausrad, Mittelklick;
 * Einpassen nur über die Buttons rechts unten (Fit Inhalt, Bühne, Auswahl).
 */
export declare function CssStage({ document, pageIndex, editPhase, selectedElementId, selectedGroupId, onSelectElement, onSelectGroup, onTransformElement, onDropTreeItem, onStageDragPreviewChange, onStageDragPreviewClear, inspectorPreviewPatch, isElementDraggable, underlay, styleHighlightElementIds, previewTransitionDurationMs, timelineScrubLinear, einpassen, durchsichtig, }: CssStageProps): import("react/jsx-runtime").JSX.Element;
export {};
