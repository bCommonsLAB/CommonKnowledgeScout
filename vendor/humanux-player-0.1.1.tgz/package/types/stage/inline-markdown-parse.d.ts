/**
 * Inline-Markdown-Parser für {@link scene-text-content} (keine React-Abhängigkeit).
 */
import type { SceneTextSegment } from "./scene-text-segment-types";
export declare function parseInlineMarkdownLines(preprocessed: string): SceneTextSegment[];
