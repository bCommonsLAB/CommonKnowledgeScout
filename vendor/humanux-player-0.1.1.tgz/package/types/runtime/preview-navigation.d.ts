import type { RootObject } from "../domain/scene-schema";
/** Laufzeit: explizite „nächste View“ (HumanUX `navigateNextView`). */
export declare const PREVIEW_EVENT_NEXT_VIEW = "nextView";
/** Laufzeit: `humanux-compiler` setzt `jumpTo` bei `jumpToView`. */
export declare const PREVIEW_EVENT_JUMP_TO = "jumpTo";
export type PreviewNavigationResolution = {
    targetIndex: number;
    /** True bei `jumpTo` oder View-Default `jumpTo`. */
    isJump: boolean;
    /** True bei explizitem Ziel (Jump, Go, nächste View, Legacy-Attribut-Treffer, …). */
    isExplicit: boolean;
    /**
     * True: kein Seitenwechsel (z. B. View-Default „Keins“ oder fehlendes Go-/Jump-Ziel).
     * Dann bleibt die Preview in onShow; kein onLeave zur nächsten Seite.
     */
    stayOnPage?: boolean;
};
/**
 * Vollständige Auflösung: zuerst Element-Navigation, dann View-Default.
 * Ohne explizites „Nächste View“ am Element oder an der View gibt es **keinen** automatischen
 * Wechsel (früher: Fallback „nächste Seite“).
 */
export declare function resolvePreviewNavigation(doc: RootObject, currentPageIndex: number, clickedElementId: string): PreviewNavigationResolution;
/**
 * True, wenn die Preview **Jump-to** ausführen soll (kein onShow→onLeave, kein onLoad→onShow auf Ziel).
 */
export declare function isJumpPreviewNavigation(doc: RootObject, currentPageIndex: number, clickedElementId: string): boolean;
/**
 * True, wenn das Element eine **explizite** Zielseite setzt (Page-ID/Name oder goto mit Attribut).
 * Bei implizitem „nächste Seite“ (Wrap) false — damit unterscheidet der Store z. B.
 * „von letzter Seite zurück zur ersten“ (Wrap) von „explizit erste Seite verlinkt“.
 */
export declare function isExplicitPreviewNavigation(doc: RootObject, currentPageIndex: number, clickedElementId: string): boolean;
/**
 * Ermittelt die Zielseite nach einem Klick im Preview.
 * Zuerst Element-`eventType`/`eventAttribute`, dann View-`defaultClickBehavior`.
 * Ohne explizites Ziel und mit View-Default **Keins** bleibt der Index unverändert (kein Wrap).
 * HumanUX-v2: `goToView`/`jumpToView` → Compiler setzt `eventAttribute` = Ziel-ID.
 */
export declare function resolveNextPageIndex(doc: RootObject, currentPageIndex: number, clickedElementId: string): number;
/**
 * `eventAttribute` verweist auf eine Page (id oder name), die im Dokument noch fehlt.
 * Dann kann die Ziel-Page z. B. per API nachgeladen werden.
 */
export declare function isNavigationTargetMissingInDocument(doc: RootObject, currentPageIndex: number, clickedElementId: string): boolean;
