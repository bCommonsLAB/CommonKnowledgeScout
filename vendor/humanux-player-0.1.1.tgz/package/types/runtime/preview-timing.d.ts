/**
 * Eine Quelle für Preview-Übergänge (FPS/Frames als Referenz für Dauer) und UI-Zeitleiste (Sekunden).
 * Änderungen hier wirken auf `phase-transition-animations` und die Timeline gleich mit.
 */
export declare const PREVIEW_FPS = 60;
/** Frames für onLoad → onShow (~0,5 s bei 60 FPS). */
export declare const PREVIEW_FRAMES_LOAD_TO_SHOW = 30;
/** Frames für onShow → onLeave (~0,75 s bei 60 FPS). */
export declare const PREVIEW_FRAMES_SHOW_TO_LEAVE = 45;
export declare function previewFramesToMs(frames: number): number;
/** Dauer Load→Show in Millisekunden (Basis für Timeline). */
export declare const PREVIEW_MS_LOAD_TO_SHOW: number;
/** Dauer Show→Leave in Millisekunden. */
export declare const PREVIEW_MS_SHOW_TO_LEAVE: number;
/**
 * Darstellungsbreite der „Klick/OnShow“-Zone auf der UI-Zeitachse (keine feste Dauer aus der Engine).
 * Der Marker bleibt in diesem Intervall stehen, bis ein Klick OnLeave auslöst.
 */
export declare const PREVIEW_AXIS_MS_INTERACTION = 1000;
/** Ein Seitenzyklus auf der Achse [ms] = Load→Show + Interaktion + Show→Leave. */
export declare function previewAxisPageCycleMs(): number;
/** @deprecated Alias — nutze `previewAxisPageCycleMs`. */
export declare function previewAxisTotalMs(): number;
