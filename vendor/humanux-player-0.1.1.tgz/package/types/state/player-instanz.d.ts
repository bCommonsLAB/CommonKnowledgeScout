/**
 * Player-Instanz: Wiedergabe-Zustand und Trace einer Bühne (R-PLAYER-INSTANZ-001).
 *
 * Jede Bühne bekommt ihre eigene Instanz über den `PlayerProvider`. Zwei Bühnen auf einer Seite
 * teilen sich nichts. Ohne Provider wirft die Bühne (R-PLAYER-INSTANZ-002) — es gibt keine
 * globale Instanz, auf die sie still zurückfallen könnte.
 */
import { type ReactNode } from "react";
import { type StoreApi, type UseBoundStore } from "zustand";
import { type AppActions, type AppState } from "./app-store";
import { type HumanuxPreviewTraceState } from "./humanux-preview-trace-store";
import type { PlayerEinhaengen } from "./player-einhaengen";
import type { Seitenquelle } from "./seitenquelle";
export type WiedergabeZustand = AppState & AppActions;
export interface PlayerInstanz {
    /** Wiedergabe-Zustand: Dokument, aktuelle Seite, Phase, Übergang, Media-Overlay. */
    zustand: StoreApi<WiedergabeZustand>;
    /** Trace der Wiedergabe: Ereignisse und Momentaufnahmen, für Debug und Editor. */
    trace: StoreApi<HumanuxPreviewTraceState>;
    /** Adresse eines Pfads der Szene oder des Players, mit der Basisadresse (R-PLAYER-VERTRAG-003). */
    adresse: (pfad: string) => string;
}
export interface PlayerInstanzOptionen {
    /** Einhängepunkte des Gastgebers (R-PLAYER-EINHAENGEN-001). */
    einhaengen?: PlayerEinhaengen;
    /**
     * Woher Seiten kommen, die nicht im Dokument stehen (R-PLAYER-SEITENQUELLE-001). Ohne: alle
     * Seiten stehen im Dokument.
     */
    seitenquelle?: Seitenquelle;
    /**
     * Basisadresse für Pfade, die mit `/` beginnen — Bilder, SVG-Formen, Medien und die Symbole des
     * Players (R-PLAYER-VERTRAG-003). Ohne: Pfade gelten gegenüber der Seite des Gastgebers.
     */
    assetBasis?: string;
}
/**
 * Macht aus einem Pfad, der mit `/` beginnt, eine Adresse unter `basis`. Volle Adressen
 * (`https:`, `data:`, `blob:`) und Adressen ohne Schema (`//…`) bleiben, wie sie sind.
 */
export declare function adresseMitBasis(basis: string | undefined): (pfad: string) => string;
/** Eine neue, unabhängige Instanz — je Bühne eine. */
export declare function createPlayerInstanz(optionen?: PlayerInstanzOptionen): PlayerInstanz;
/** Stellt der Bühne darunter ihre Instanz bereit. */
export declare function PlayerProvider({ instanz, children }: {
    instanz: PlayerInstanz;
    children: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
/** Adresse eines Pfads der Szene oder des Players (R-PLAYER-VERTRAG-003). */
export declare function usePlayerAdresse(): (pfad: string) => string;
/** Die Instanz der umgebenden Bühne. Wirft ohne `PlayerProvider` (R-PLAYER-INSTANZ-002). */
export declare function usePlayerInstanz(): PlayerInstanz;
/** Wert aus dem Wiedergabe-Zustand der umgebenden Bühne. */
export declare function usePlayerZustand<T>(auswahl: (zustand: WiedergabeZustand) => T): T;
/**
 * Hook für einen Gastgeber, der seine Instanz außerhalb der Bühne liest und schreibt — mit
 * `getState`/`setState` wie ein gewöhnlicher Zustand-Hook. Für eine Anwendung mit genau einer
 * Bühne (Commoning Methods): `const useAppStore = bindePlayerHook(instanz.zustand)`.
 */
export declare function bindePlayerHook<T>(api: StoreApi<T>): UseBoundStore<StoreApi<T>>;
