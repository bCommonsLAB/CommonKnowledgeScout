/**
 * Formen des Wiedergabe-Trace: was Bühne und Wiedergabe-Zustand beim Abspielen mitschreiben —
 * Ereignisse, Momentaufnahmen, Sitzung. Sie liegen beim Player, weil Bühne und Trace-Store sie
 * brauchen (R-PLAYER-GRENZE-001, docs/specs/entity-player.md). Das Export-Format des Editors
 * baut darauf auf: `features/editor-v2/humanux-trace-export-types.ts`.
 */
import type { ElementProps } from "../domain/scene-schema";
export type HumanuxTraceTargetKind = "entity" | "group";
export type HumanuxCompactKey = "positionX" | "positionY" | "rotationZ" | "sizeX" | "sizeY" | "transparency" | "materialColor" | "content" | "eventType" | "eventAttribute";
export interface HumanuxTraceTargetRef {
    kind: HumanuxTraceTargetKind;
    id: string;
}
export interface HumanuxPreviewTraceEvent {
    type: "preview-enter" | "preview-exit" | "transition-start" | "transition-end" | "click" | "jump" | "restart" | "capture-skipped" | "media-overlay-open" | "media-overlay-close" | "media-overlay-auto-open";
    timestampMs: number;
    timestampIso?: string;
    sincePreviousMs?: number;
    interactionId?: string;
    pageIndex: number;
    pageId: string | null;
    phase: string | null;
    target: HumanuxTraceTargetRef | null;
    detail?: Record<string, unknown>;
}
export interface HumanuxPreviewTraceSample {
    t: number;
    timestampIso?: string;
    sincePreviousMs?: number;
    at: string;
    reason: string;
    sampleRole: "from" | "to" | "stable";
    kind: HumanuxTraceTargetKind;
    id: string;
    pageIndex: number;
    pageId: string | null;
    fromPageIndex: number | null;
    fromPageId: string | null;
    toPageIndex: number | null;
    toPageId: string | null;
    phase: string;
    previewEffectivePhase?: string;
    fromPhaseSource?: string;
    toPhaseSource?: string;
    rect: [number, number, number, number] | null;
    runtimeUsed?: Partial<Pick<ElementProps, HumanuxCompactKey>>;
    previewEffectiveUsed?: Partial<Pick<ElementProps, HumanuxCompactKey>>;
    fromProps?: Partial<Pick<ElementProps, HumanuxCompactKey>>;
    toProps?: Partial<Pick<ElementProps, HumanuxCompactKey>>;
    animatedKeys?: string[];
    exitAnchorKeys?: string[];
    enterAnchorKeys?: string[];
    progress?: number;
    transitionDurationMs?: number;
}
export interface HumanuxPreviewTraceSessionExport {
    sessionId: string;
    startedAt: string;
    storage: "memory";
}
