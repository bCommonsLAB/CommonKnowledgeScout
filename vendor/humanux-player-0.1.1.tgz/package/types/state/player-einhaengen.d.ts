/**
 * Einhängepunkte des Players: Hier reicht der Gastgeber herein, was der Player nicht selbst
 * wissen darf — Regeln einer einzelnen Anwendung. Der Player importiert nichts davon
 * (R-PLAYER-GRENZE-001); er fragt nur diese Formen ab. Ohne Einhängepunkte läuft er allein.
 *
 * Spec: docs/specs/entity-player.md (R-PLAYER-EINHAENGEN-001).
 */
/**
 * Klick: welches Medium nach einer Navigation öffnet.
 *
 * Beispiel Commoning Methods: Auf dem Teppich liegen die Symbole eines Methodenkoffers hinter dem
 * Sack. Der Klick trifft den Sack; nach der Ankunft auf der Detailseite soll das Video der Methode
 * öffnen, ohne Video ihr PDF.
 */
export interface KlickEinhaengen {
    /**
     * Ein Darsteller wurde geklickt und der Player hat den Klick angenommen (er wartet auf einen
     * Klick, kein Übergang läuft). Kommt vor Navigation und Medium. R-PLAYER-VERTRAG-002.
     */
    geklickt?: (ereignis: {
        darstellerId: string;
        seiteId: string | null;
    }) => void;
    /**
     * Der geklickte Darsteller navigiert und trägt selbst kein Medium: Welcher Darsteller soll nach
     * der Ankunft sein Medium öffnen? `null` = keiner.
     */
    mediumNachAnkunft?: (geklickteId: string) => string | null;
    /**
     * Der Darsteller, der nach der Ankunft öffnen sollte, trägt auf der Zielseite kein Medium:
     * Welcher springt ein? `null` = keiner.
     */
    ersatzMedium?: (darstellerId: string) => string | null;
}
export interface PlayerEinhaengen {
    klick?: KlickEinhaengen;
}
