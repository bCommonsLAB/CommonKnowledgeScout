import { type StoreApi } from "zustand";
import type { EditPhase, Element, ElementProps, RootObject } from "../domain/scene-schema";
import type { HumanuxPreviewTraceState } from "./humanux-preview-trace-store";
import type { PreviewTransition } from "./preview-runtime-types";
import type { PlayerEinhaengen } from "./player-einhaengen";
import { type Seitenquelle } from "./seitenquelle";
import { type HumanuxTransitionIntent } from "../domain/humanux-transition-intent";
export type EditorMode = "edit" | "preview";
export interface AppState {
    document: RootObject | null;
    currentPageIndex: number;
    selectedElementId: string | null;
    editPhase: EditPhase;
    dirty: boolean;
    mode: EditorMode;
    /**
     * Preview-Runtime: stabile Phase nach abgeschlossener Animation.
     * Editor nutzt weiterhin `editPhase`; die Bühne im Preview liest diese Felder.
     */
    previewRuntimePhase: EditPhase;
    /** Aktive Transition (Animation läuft) oder null. */
    previewTransition: PreviewTransition | null;
    /** In onShow: Klick erwartet, um onLeave zu starten. */
    previewWaitingForClick: boolean;
    /** Nach Klick: Zielseite für den Übergang nach onLeave (hybride Navigation). */
    previewPendingTargetPage: number | null;
    /** Während nachgeladener Seiten-Fetch: keine zweiten Klicks. */
    previewRemoteLoading: boolean;
    /**
     * Woher Seiten kommen, die nicht im Dokument stehen (R-PLAYER-SEITENQUELLE-001). Der Gastgeber
     * setzt sie; Laden, Leeren und der Wechsel in den Bearbeitungsmodus setzen sie auf die Seitenquelle
     * zurück, mit der die Instanz angelegt wurde.
     */
    seitenquelle: Seitenquelle;
    /**
     * true: jeder Klick fragt die Seitenquelle (`naechsteSeite`) — der Gastgeber führt die Navigation.
     * false: gefragt wird nur, wenn die Ziel-Page im Dokument fehlt.
     */
    serverDrivenNavigation: boolean;
    /** Einheitliche, aktuell gerenderte Transition (Preview oder Editor-Scrub). */
    sharedTransitionIntent: HumanuxTransitionIntent | null;
    /** Offenes Media-Overlay (bei Klick oder automatisch bei onStage). Nur eines gleichzeitig. */
    mediaOverlay: {
        entityId: string;
        /** Leer, wenn das Medium autorierter Klartext ist (dann traegt `mediaText` den Inhalt). */
        mediaUrl: string;
        /** Autorierter Klartext statt Link (R-METHODE-TXT-BESCHREIBUNG-004). */
        mediaText?: string;
        /** Volltext zu `mediaText` — Mehr-lesen-Blase klappt ihn auf (R-METHODE-TXT-VOLLTEXT-002). */
        mediaTextVoll?: string;
        mediaType: string;
        mediaSizeX?: number;
        mediaSizeY?: number;
        /** Optionales Shape fuer den Overlay-Container (ersetzt Standard-Rahmen). */
        mediaShape?: string;
        mediaSvgUrl?: string;
        mediaShapePadding?: number;
        mediaShapeColor?: string;
        mediaShapeOpacity?: number;
        mediaShapeSizeX?: number;
        mediaShapeSizeY?: number;
        mediaShapeOffsetY?: number;
    } | null;
    /**
     * Zweiphasiges Schließen des Ohr-Audio-Players: `true` = Fly-back-Animation läuft (Ohr schwebt
     * zurück an seinen Ursprung), `mediaOverlay` bleibt noch gesetzt. Erst `endMediaOverlay()` nullt.
     * Andere Medientypen (PDF/Video/Embed) schließen weiterhin sofort und lassen dieses Flag `false`.
     */
    mediaOverlayClosing: boolean;
    /**
     * Variante 1 (Methodenkoffer): Klick auf ein medienführendes Navigations-Symbol (z. B. PDF-Icon
     * auf dem Teppich) merkt sich dessen Entity-ID. Navigation läuft normal; NACH Ankunft auf der
     * Zielseite öffnet `autoOpenOnStageOverlay` das Medium dieses Darstellers (gleiche ID dort).
     */
    pendingAutoOpenMediaEntityId: string | null;
    /**
     * Einhängepunkte des Gastgebers (R-PLAYER-EINHAENGEN-001): Regeln einer einzelnen Anwendung, die
     * der Player nicht selbst kennt — etwa welches Medium nach einer Navigation öffnet. Leer = der
     * Player läuft allein.
     */
    einhaengen: PlayerEinhaengen;
}
export interface AppActions {
    loadDocument: (doc: RootObject) => void;
    clearDocument: () => void;
    setPage: (index: number) => void;
    selectElement: (id: string | null) => void;
    setEditPhase: (phase: EditPhase) => void;
    setMode: (mode: EditorMode) => void;
    patchSelectedProps: (patch: Partial<ElementProps>) => void;
    /** Verschieben per Bühne: gleiche Phase wie im Inspector. */
    patchElementPropsById: (elementId: string, patch: Partial<ElementProps>) => void;
    patchSelectedElementMeta: (patch: Partial<Pick<Element, "name" | "draggable" | "collision" | "posConstX" | "posConstY" | "rotConstZ" | "className">>) => void;
    markSaved: () => void;
    /** Preview starten: ab `startPageIndex` (Default: 0), Phase onLoad. */
    enterPreview: (startPageIndex?: number) => void;
    exitPreview: () => void;
    beginPreviewTransition: (from: EditPhase, to: EditPhase) => void;
    /** Wird von der Bühne nach Ende der Preview-Animation (CSS-Transition / Timeout) aufgerufen. */
    completePreviewTransition: () => void;
    /** Klick auf Element im Preview (nur wenn previewWaitingForClick). */
    previewElementClicked: (elementId: string) => void | Promise<void>;
    /**
     * Deep-Link: direkt auf die Seite mit `pageId` springen (für `?view=<pageId>` beim Reload).
     * Lädt die Seite bei Bedarf über die Seitenquelle nach (`seite`),
     * mergt sie und landet ohne Übergangsanimation auf `onShow` (wartet wieder auf Klick).
     */
    deepLinkToPage: (pageId: string) => Promise<void>;
    /**
     * Preview: aktuelle Seite erneut von OnLoad abspielen (Animation neu starten).
     * Kein Seitenwechsel; bricht laufende Transition durch State-Reset ab (Bühne synchronisiert).
     */
    restartPreviewPlayback: () => void;
    /** Seitenquelle des Gastgebers setzen (R-PLAYER-SEITENQUELLE-001). */
    setSeitenquelle: (seitenquelle: Seitenquelle) => void;
    setServerDrivenNavigation: (value: boolean) => void;
    /** Einhängepunkte des Gastgebers setzen (R-PLAYER-EINHAENGEN-001). */
    setEinhaengen: (einhaengen: PlayerEinhaengen) => void;
    setSharedTransitionIntent: (intent: HumanuxTransitionIntent | null) => void;
    setSharedTransitionProgress: (progress: number) => void;
    /** Media-Overlay oeffnen (ersetzt ein eventuell bereits offenes). */
    openMediaOverlay: (payload: NonNullable<AppState["mediaOverlay"]>) => void;
    /** Media-Overlay schliessen. */
    closeMediaOverlay: () => void;
    /** Ohr-Player: Fly-back-Animation beendet → Overlay endgültig entfernen. */
    endMediaOverlay: () => void;
}
export interface WiedergabeOptionen {
    /** Trace derselben Instanz. */
    trace: StoreApi<HumanuxPreviewTraceState>;
    /** Einhängepunkte des Gastgebers (R-PLAYER-EINHAENGEN-001); ohne läuft der Player allein. */
    einhaengen?: PlayerEinhaengen;
    /** Seitenquelle des Gastgebers (R-PLAYER-SEITENQUELLE-001); ohne werden keine Seiten nachgeladen. */
    seitenquelle?: Seitenquelle;
}
/**
 * Wiedergabe-Zustand einer Player-Instanz. Jede Bühne bekommt ihren eigenen
 * (R-PLAYER-INSTANZ-001); angelegt wird er über `createPlayerInstanz`.
 */
export declare function erzeugeWiedergabeZustand(optionen: WiedergabeOptionen): StoreApi<AppState & AppActions>;
/**
 * Abgeleiteter Snapshot für Inspector/Sidebar.
 * In Komponenten immer mit useShallow nutzen, sonst neue Objekt-Referenz → React-19-Loop.
 */
export declare function selectEditorSnapshot(state: AppState & AppActions): {
    element: Element | null;
    props: ElementProps | null;
    isCanonical: boolean;
};
