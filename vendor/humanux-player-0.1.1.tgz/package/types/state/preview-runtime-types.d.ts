import type { EditPhase } from "../domain/scene-schema";
/** Laufende Preview-Transition zwischen zwei Phasen (Meshes werden von `from` nach `to` animiert). */
export type PreviewTransition = {
    kind?: "legacy-phase" | "stage-flow";
    interactionId?: string;
    from: EditPhase;
    to: EditPhase;
    fromPageIndex?: number;
    toPageIndex?: number;
};
