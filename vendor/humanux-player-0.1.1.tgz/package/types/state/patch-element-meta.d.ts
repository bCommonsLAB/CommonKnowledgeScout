import type { Element, RootObject } from "../domain/scene-schema";
/**
 * Metadaten am Element (nicht Phasen-Props): z. B. draggable.
 */
export declare function patchElementMeta(doc: RootObject, pageIndex: number, elementId: string, patch: Partial<Pick<Element, "name" | "draggable" | "collision" | "posConstX" | "posConstY" | "rotConstZ" | "className">>): RootObject;
