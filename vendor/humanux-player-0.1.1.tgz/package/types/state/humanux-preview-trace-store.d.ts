import { type StoreApi } from "zustand";
import type { HumanuxPreviewTraceEvent, HumanuxPreviewTraceSample, HumanuxPreviewTraceSessionExport } from "./humanux-preview-trace-types";
export type HumanuxPreviewTraceState = {
    session: (HumanuxPreviewTraceSessionExport & {
        startedPerfMs: number;
    }) | null;
    events: HumanuxPreviewTraceEvent[];
    samples: HumanuxPreviewTraceSample[];
    beginSession: () => HumanuxPreviewTraceSessionExport;
    reset: () => void;
    logEvent: (event: Omit<HumanuxPreviewTraceEvent, "timestampMs"> & {
        timestampMs?: number;
    }) => void;
    logSample: (sample: Omit<HumanuxPreviewTraceSample, "t"> & {
        t?: number;
    }) => void;
};
/**
 * Trace einer Player-Instanz (R-PLAYER-INSTANZ-001): Ereignisse und Momentaufnahmen der Wiedergabe,
 * für Debug-Fenster und Zeitachse des Editors. Jede Instanz hat ihren eigenen; der Zähler der
 * Sitzungen lebt in der Instanz, nicht auf Modulebene (R-PLAYER-INSTANZ-003).
 */
export declare function erzeugeTraceZustand(): StoreApi<HumanuxPreviewTraceState>;
