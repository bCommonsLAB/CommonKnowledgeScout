import type { EditPhase, ElementProps, RootObject } from "../domain/scene-schema";
/**
 * Wendet partielle Änderungen auf die Props der aktiven Phase des Elements an.
 */
export declare function patchElementPhaseProps(doc: RootObject, pageIndex: number, elementId: string, phase: EditPhase, patch: Partial<ElementProps>): RootObject;
