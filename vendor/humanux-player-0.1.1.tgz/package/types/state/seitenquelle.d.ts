/**
 * Seitenquelle: woher der Player Seiten holt, die nicht im Dokument stehen (R-PLAYER-SEITENQUELLE-001).
 *
 * Der Player kennt keinen Server. Ein Gastgeber mit Server (Commoning Methods) reicht seine
 * Aufrufe herein; ein Gastgeber ohne Server übergibt die ganze Aufführung als JSON und braucht
 * keine Seitenquelle — dann stehen alle Seiten im Dokument.
 */
import type { Page } from "../domain/scene-schema";
/** Antwort einer Seitenquelle. `prefetchPage` darf eine weitere Seite vorab mitbringen. */
export type SeitenAntwort = {
    ok: true;
    page: Page;
    prefetchPage?: Page;
} | {
    ok: false;
    error: string;
};
export interface Seitenquelle {
    /**
     * Klick auf `elementId` auf der Seite `fromPageId`: welche Seite kommt als Nächstes? Gefragt wird,
     * wenn das Ziel im Dokument fehlt oder die Navigation über die Seitenquelle läuft
     * (`serverDrivenNavigation`).
     */
    naechsteSeite?: (anfrage: {
        fromPageId: string;
        elementId: string;
    }) => Promise<SeitenAntwort>;
    /** Eine Seite per ID — für den Sprung über die Adresse (`?view=<pageId>`). */
    seite?: (pageId: string) => Promise<SeitenAntwort>;
    /** Kurzname für Debug-Log und Debug-Fenster, z. B. `mongo:<sceneId>`. */
    bezeichnung?: string;
}
/** Ohne Seitenquelle: alle Seiten stehen im Dokument, nachgeladen wird nichts. */
export declare const KEINE_SEITENQUELLE: Seitenquelle;
