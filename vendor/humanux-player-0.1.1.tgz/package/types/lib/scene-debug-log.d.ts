/**
 * Debug-Ausgaben für Szene/Preview/API (Konsolenfilter: `[scene]`).
 *
 * - Entwicklung (`NODE_ENV === development`): immer aktiv.
 * - Produktion: nur wenn `localStorage.setItem("sceneDebug", "1")` gesetzt wurde.
 */
export declare function sceneDebugEnabled(): boolean;
export declare function sceneDebugLog(...args: unknown[]): void;
