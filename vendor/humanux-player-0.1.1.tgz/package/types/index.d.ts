/**
 * Eingang des Pakets `@humanux/player`: was ein Gastgeber braucht, um eine Aufführung zu zeigen —
 * Bühne, Wiedergabe-Zustand, Einhängepunkte und das Format.
 *
 * Vorläufig: Der Vertrag nach außen entsteht mit Etappe 5 des Plans „HumanUX Player herauslösen".
 * Anwendung und Editor dieses Repos beziehen die Dateien des Players bis dahin einzeln
 * (`@humanux/player/src/…`). R-PLAYER-EINGANG-001, docs/specs/entity-player.md.
 */
export { HumanUxPlayer, type DarstellerKlick, type HumanUxPlayerProps } from "./humanux-player";
export { CssStage, type CssStageProps } from "./stage/css-stage";
export type { AppActions, AppState, EditorMode } from "./state/app-store";
export { bindePlayerHook, createPlayerInstanz, PlayerProvider, adresseMitBasis, usePlayerAdresse, usePlayerInstanz, usePlayerZustand, type PlayerInstanz, type PlayerInstanzOptionen, type WiedergabeZustand, } from "./state/player-instanz";
export type { KlickEinhaengen, PlayerEinhaengen } from "./state/player-einhaengen";
export { KEINE_SEITENQUELLE, type SeitenAntwort, type Seitenquelle } from "./state/seitenquelle";
export * from "./format";
