# @commonux/player

Der Common UX Player spielt eine Aufführung ab: Bühnen, Darsteller, Übergänge, Medien. In
diesem Repo nutzen ihn Commoning Methods und der Editor als Quelltext. Fremde Anwendungen
bauen ihn als Bündel ein (`commonux-player-<version>.tgz`).

Regeln: [`docs/specs/entity-player.md`](../../docs/specs/entity-player.md).

## Einbau (React 18 oder 19, z. B. Next.js App Router)

```bash
npm install ./commonux-player-0.2.0.tgz
# pnpm add ./commonux-player-0.2.0.tgz
```

```tsx
import "@commonux/player/styles.css";
import { CommonUxPlayer } from "@commonux/player";
import szene from "./meine-auffuehrung.json";

export function Hintergrund() {
  return (
    <div style={{ position: "fixed", inset: 0 }}>
      <CommonUxPlayer
        szene={szene}
        einpassen="cover"
        durchsichtig
        assetBasis="https://bilder.example.org"
        onDarstellerKlick={({ darstellerId, seiteId }) => console.log(darstellerId, seiteId)}
      />
    </div>
  );
}
```

| Prop | Bedeutung |
|---|---|
| `szene` | Die Aufführung als HumanUX-v2-JSON, als Objekt oder Text. Pflicht. |
| `startSeite` | ID der ersten Bühne. Ohne: die erste der Aufführung. |
| `seitenquelle` | Woher Bühnen kommen, die nicht in `szene` stehen: `{ naechsteSeite, seite }`. Ohne: alle stehen in `szene`. |
| `einhaengen` | Regeln des Gastgebers, z. B. welches Medium nach einer Navigation öffnet. |
| `onDarstellerKlick` | Meldet jeden angenommenen Klick: `{ darstellerId, seiteId }`. |
| `assetBasis` | Basisadresse für Pfade, die mit `/` beginnen (Bilder, SVG-Formen, Medien, Symbole des Players). Gilt beim Montieren. |
| `einpassen` | `contain` (Standard, ganzes Sichtfeld) oder `cover` (füllt den Rahmen). |
| `durchsichtig` | Kein eigener Hintergrund; der Gastgeber scheint durch. |
| `durchlass` | Klicks gehen durch die Bühne hindurch an das, was darunter liegt; nichts in ihr bekommt den Fokus. Für eine Bühne als Hintergrund. Den eigenen Behälter um den Player ebenfalls durchlässig machen (`pointer-events: none`). |
| `bewegung` | `system` (Standard, folgt „Bewegung reduzieren" des Geräts), `voll` oder `reduziert` (Übergänge ohne Bewegung). |
| `seite` | Der Gastgeber führt: die Bühne, die zu sehen ist. Ein Wechsel läuft als Übergang; Klicks werden nur gemeldet, der Player navigiert nicht selbst. |
| `medienMitte` | Wo Media-Overlays sitzen, in Welteinheiten `{ x, y }`. Ohne: die Mitte von Commoning Methods. |
| `darsteller` | Darsteller zur Laufzeit: `{ id, props, entstehung?, name? }[]`. Die Liste ist der ganze Stand — wer fehlt, geht; wer bleibt, behält seine Lage; wer neu ist, entsteht an seinem Entstehungsort. |
| `gespraech` | Ein Gespräch in neutraler Form (Frage, Stand, Antwort, Belege, Folgefragen, Verlauf). Der Player macht daraus Darsteller, mit den Masken `gespraech-…` der Aufführung. |
| `anker`, `leselinie` | Je Darsteller Marken in Bildschirmkoordinaten (`{ id, marken: [{ key, x, y }] }`). Die Marke nächst der Leselinie (Standard 0,4 der Höhe) ersetzt den Ruhe-Ort eines freien Darstellers. |
| `stufe` | `voll` (Standard) oder `blass`: nur Formen und Farben, Deckkraft 0,3, ohne Schrift — als Hintergrund unter Text. |
| `className`, `style` | Für den Rahmen. |

- Der Rahmen `.commonux-player` füllt seinen Platz; die Größe gibt der Gastgeber vor.
- Alle Stile liegen unter `.commonux-player`, auch die der Overlays, und wirken nicht auf die übrige
  Seite. Dunkles Design folgt der Klasse `dark` an einem Vorfahren.
- **Schriften** bringt der Gastgeber mit. Die Textarten nutzen `Metropolitano` und
  `Mazius Display`; fehlen sie, greift die Ersatzschrift. Eigene Familien setzt man an
  `.commonux-player` über `--textart-<id>-family`.
- Eine ungültige Aufführung zeigt die Komponente als Meldung im Rahmen und in der Konsole.
- `@commonux/player/format` liefert Schema, Compiler und Leser ohne React — für Server-Code. Dort
  liegen auch das Gespräch und sein Übersetzer (`uebersetzeGespraech`, `gespraechDarstellerId`).

## Ein Gespräch auf der Bühne

Der Gastgeber übersetzt seine Daten in ein `Gespraech` und reicht es herein; der Player setzt die
Darsteller und die Schwerkraft ordnet sie.

```tsx
import { CommonUxPlayer, gespraechDarstellerId, type Gespraech } from "@commonux/player";

const gespraech: Gespraech = {
  frage: { id: "f1", text: "Wie beginnt ein Commons?" },
  stand: "fertig", // sucht · schreibt · fertig · fehler
  antwort: { text: "Am Anfang steht ein **gemeinsames Anliegen** [1]." },
  belege: [{ id: "dok-7", dokument: "dok-7", nummer: 1, titel: "Rituale des Miteinanders", quelle: "Musterkarte" }],
  folgefragen: [{ id: "f2", text: "Was tun bei Konflikten?" }],
  verlauf: [],
};

<CommonUxPlayer
  szene={szene}
  gespraech={gespraech}
  onDarstellerKlick={({ darstellerId }) => {
    if (darstellerId === gespraechDarstellerId("folgefrage", "f2")) stelleFrage("f2");
  }}
/>;
```

- **Masken:** Die Aufführung braucht in `application.styles` die Masken `gespraech-frage-offen`,
  `gespraech-frage`, `gespraech-blatt`, `gespraech-blatt-gross`, `gespraech-beleg-punkt`,
  `gespraech-beleg`, `gespraech-folgefrage` und `gespraech-perle`. Sie bestimmen Form, Farbe,
  Schrift, Ruhe-Ort und Schwerkraft. Fehlt eine, meldet der Player es in der Konsole und zeigt kein
  Gespräch. Ein Beispiel steht in `src/features/gespraech-nachweis/nachweis-szene.ts`.
- **Dieselbe ID, derselbe Darsteller:** Wird eine Folgefrage zur Frage, gib der neuen Frage die ID
  der Folgefrage; sie fliegt dann von deren Stelle in die Mitte. Ein Beleg mit derselben `id`
  bleibt über Antworten hinweg derselbe Darsteller in derselben Farbe.
- **Lesen als Seite:** `stufe="blass"`, `durchlass`, im Gespräch `lesen: true`, dazu `anker` mit
  der Lage der Zitatmarken (bei jedem Scrollen neu messen, `key` je Marke gleich lassen). Wer je
  Bild neue Anker reicht, hält die übrigen Props stabil; die Bühne rendert dann nicht mit.
- **Bühne direkt** (`CssStage` mit eigener Instanz): `instanz.zustand.getState().setzeLaufzeitDarsteller(…)`
  und `instanz.anker.getState().setzeAnker(…)`.

## Bauen (in diesem Repo)

```bash
npm run pack:datei --workspace @commonux/player
```

Das erzeugt `packages/commonux-player/dist/` und `packages/commonux-player/commonux-player-0.2.0.tgz`.
Der Bau bricht ab, wenn eine Regel der Stile außerhalb von `.commonux-player` liegt.

**Ein neues Bündel bekommt eine neue Version** (`version` in `package.json`). Next.js hält Pakete
in `node_modules` für unveränderlich, solange Name und Version gleich bleiben, und nimmt sonst das
alte Bündel aus seinem Cache (`.next/cache`).

## Lizenz

AGPL-3.0-or-later, siehe `LICENSE`. Wer den Player in einer Anwendung im Netz betreibt und
ihn verändert, muss den veränderten Quelltext den Nutzer:innen zugänglich machen.
