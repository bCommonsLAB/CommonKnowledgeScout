/**
 * Alte Felder der Schwerkraft aus der Unity-Zeit (R-PHYSIK-ALTFELDER-001, docs/specs/entity-physik.md).
 *
 * Sie gehören nicht mehr zum Format. Der Leser einer HumanUX-v2-Aufführung entfernt sie überall, wo
 * Maske, Darsteller oder Phase Felder tragen (`styles`, `defaults`, `entityStates`, `groupStates`,
 * Flow-Zustände, Bühnengruppen). So fehlen sie beim nächsten Speichern. Ihre Werte werden nicht in die
 * neuen Felder übertragen.
 */
export declare const ALTE_PHYSIK_FELDER: readonly ["gravity", "onGravityClass", "density", "maxDist", "doStop", "acceleration"];
/**
 * Entfernt die alten Felder in `application` an Ort und Stelle und liefert, wie viele es waren. Die
 * Namen kommen im Format sonst nirgends als Schlüssel vor; deshalb läuft die Suche über den ganzen
 * Baum. Werte (Texte, Zahlen) bleiben unberührt, nur Schlüssel fallen weg.
 */
export declare function entferneAltePhysikFelder(application: Record<string, unknown>): number;
