/**
 * Rahmen der Overlays (R-PLAYER-RAHMEN-001): wohin Media-Overlay, Ohr-Player, Audio-Dock und
 * Leseblatt rendern und an welchem Rechteck sie sich ausrichten.
 *
 * Ohne Rahmen ist es das Fenster (`document.body`, `window.innerWidth/innerHeight`) — so läuft
 * Commoning Methods. Die Wurzelkomponente `CommonUxPlayer` gibt ihren eigenen Rahmen vor: Dann
 * bleiben die Overlays im Element `.commonux-player`, wo die Stile des Players wirken, und messen
 * sich an ihm.
 */
import { type ReactNode } from "react";
/** Rechteck in Viewport-Koordinaten (wie `getBoundingClientRect`). */
export interface RahmenRechteck {
    left: number;
    top: number;
    width: number;
    height: number;
}
export interface OverlayRahmen {
    /** Element, in das Overlays rendern; `null`, solange der Rahmen noch nicht im DOM steht. */
    ziel: () => HTMLElement | null;
    /** Rechteck, auf das sich Overlays beziehen. */
    rechteck: () => RahmenRechteck;
}
/** Rahmen der Overlays darunter: das Element `element` (oder, solange es fehlt, keiner). */
export declare function OverlayRahmenProvider({ element, children }: {
    element: HTMLElement | null;
    children: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
/** Der Rahmen der Overlays; ohne Provider das Fenster. */
export declare function useOverlayRahmen(): OverlayRahmen;
