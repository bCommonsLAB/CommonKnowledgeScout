import type { Element, ElementProps, RootObject } from "../domain/scene-schema";
/**
 * Wo ein Darsteller entsteht: ein Punkt in Welteinheiten oder die Stelle eines anderen Darstellers
 * (auch eines, der im selben Zug geht).
 */
export type Entstehung = {
    x: number;
    y: number;
} | {
    bei: string;
};
export interface LaufzeitDarsteller {
    /** Stabile ID. Dieselbe ID ist derselbe Darsteller: Er behält seine Lage, wenn sich `props` ändern. */
    id: string;
    /** Erscheinung und Ruhe-Ort, vollständig (in der Regel eine Maske mit Abweichungen). */
    props: ElementProps;
    /** Entstehungsort; ohne Angabe entsteht er an seinem Ruhe-Ort. */
    entstehung?: Entstehung;
    /** Name für Hilfstechnik (`aria-label`). */
    name?: string;
}
/** Dauer, in der ein Darsteller zur Laufzeit erscheint oder Größe und Farbe wechselt (ms). */
export declare const LAUFZEIT_WANDEL_MS = 400;
export declare function istPunkt(e: Entstehung): e is {
    x: number;
    y: number;
};
/** Ein Darsteller zur Laufzeit als Element der Bühne: in allen Phasen dieselbe Erscheinung. */
export declare function laufzeitElement(d: LaufzeitDarsteller): Element;
/** IDs, die schon ein gestalteter Darsteller der Aufführung trägt (R-PLAYER-LAUFZEIT-001-EC-01). */
export declare function vergebeneIds(doc: RootObject, darsteller: readonly LaufzeitDarsteller[]): string[];
/**
 * Hängt die Darsteller zur Laufzeit an jede Bühne des Dokuments, hinter die gestalteten (also
 * darüber gezeichnet). Die Lage ist der Ruhe-Ort aus `props`; vom Entstehungsort dorthin führt die
 * Anbindung der Schwerkraft (R-PLAYER-LAUFZEIT-002).
 */
export declare function mitLaufzeitDarstellern(doc: RootObject, darsteller: readonly LaufzeitDarsteller[]): RootObject;
