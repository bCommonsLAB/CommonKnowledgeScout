/**
 * Eingang des Pakets `@commonux/player`: was ein Gastgeber braucht, um eine Aufführung zu zeigen —
 * Bühne, Wiedergabe-Zustand, Einhängepunkte und das Format.
 *
 * Vorläufig: Der Vertrag nach außen entsteht mit Etappe 5 des Plans „Common UX Player herauslösen".
 * Anwendung und Editor dieses Repos beziehen die Dateien des Players bis dahin einzeln
 * (`@commonux/player/src/…`). R-PLAYER-EINGANG-001, docs/specs/entity-player.md.
 */
export { CommonUxPlayer, type DarstellerKlick, type CommonUxPlayerProps } from "./commonux-player";
export { BLASS_DECKKRAFT, CssStage, type BuehnenStufe, type CssStageProps } from "./stage/css-stage";
export { LAUFZEIT_WANDEL_MS, type Entstehung, type LaufzeitDarsteller, } from "./state/laufzeit-darsteller";
export { ANKER_LESELINIE, ANKER_SCHWELLE_PX, waehleMarke, type AnkerMarke, type DarstellerAnker, } from "./physik/anker";
export { gespraechMaskenAusSzene, type GespraechMaskenErgebnis } from "./gespraech/gespraech-masken";
export type { AppActions, AppState, EditorMode } from "./state/app-store";
export { bindePlayerHook, createPlayerInstanz, PlayerProvider, adresseMitBasis, usePlayerAdresse, usePlayerInstanz, usePlayerZustand, type AnkerZustand, type PlayerInstanz, type PlayerInstanzOptionen, type WiedergabeZustand, } from "./state/player-instanz";
export type { KlickEinhaengen, PlayerEinhaengen } from "./state/player-einhaengen";
export { KEINE_SEITENQUELLE, type SeitenAntwort, type Seitenquelle } from "./state/seitenquelle";
export * from "./format";
