/**
 * `CommonUxPlayer` — die Wurzelkomponente für Gastgeber (R-PLAYER-VERTRAG-001).
 *
 * Ein Gastgeber übergibt eine Aufführung als HumanUX-v2-JSON und bekommt eine Bühne, die sie
 * abspielt: ab der ersten Seite (oder `startSeite`), Klicks führen von Bühne zu Bühne. Was der
 * Player nicht weiß, reicht der Gastgeber herein: Seitenquelle, Einhängepunkte, Basisadresse.
 *
 * Alles liegt in einem Rahmen mit der Klasse `commonux-player`, auch die Overlays
 * (R-PLAYER-RAHMEN-001); die Stile des Players wirken nur darin (R-PLAYER-STIL-001). Der Rahmen
 * füllt seinen Platz — die Größe bestimmt der Gastgeber.
 */
import { type CSSProperties } from "react";
import type { CssViewportFitMode } from "./stage/css-layout";
import { type BuehnenStufe } from "./stage/css-stage";
import { type Gespraech } from "./gespraech/gespraech";
import type { DarstellerAnker } from "./physik/anker";
import type { LaufzeitDarsteller } from "./state/laufzeit-darsteller";
import type { PlayerEinhaengen } from "./state/player-einhaengen";
import type { Seitenquelle } from "./state/seitenquelle";
/** Was ein Klick auf einen Darsteller dem Gastgeber meldet (R-PLAYER-VERTRAG-002). */
export interface DarstellerKlick {
    darstellerId: string;
    seiteId: string | null;
}
export interface CommonUxPlayerProps {
    /** Die Aufführung: HumanUX-v2-JSON als Objekt oder als Text. */
    szene: unknown;
    /** ID der Seite, mit der die Wiedergabe beginnt. Ohne: die erste. Unbekannt: Fehler im Rahmen. */
    startSeite?: string;
    /** Woher Seiten kommen, die nicht in der Szene stehen (R-PLAYER-SEITENQUELLE-001). */
    seitenquelle?: Seitenquelle;
    /** Regeln des Gastgebers (R-PLAYER-EINHAENGEN-001). */
    einhaengen?: PlayerEinhaengen;
    /** Ein Darsteller wurde geklickt (R-PLAYER-VERTRAG-002). */
    onDarstellerKlick?: (klick: DarstellerKlick) => void;
    /**
     * Basisadresse für Pfade, die mit `/` beginnen (R-PLAYER-VERTRAG-003). Gilt beim Montieren; wer
     * sie ändert, gibt der Komponente einen neuen `key`.
     */
    assetBasis?: string;
    /** `contain` (Standard): ganzes Sichtfeld mit Rändern; `cover`: füllt den Rahmen (R-PLAYER-VERTRAG-004). */
    einpassen?: CssViewportFitMode;
    /** Kein eigener Hintergrund: der Gastgeber scheint durch (R-PLAYER-VERTRAG-004). */
    durchsichtig?: boolean;
    /**
     * Klicks gehen durch die Bühne hindurch an das, was darunter liegt; nichts in ihr bekommt den
     * Fokus (R-PLAYER-DURCHLASS-001). Für eine Bühne als Hintergrund.
     */
    durchlass?: boolean;
    /**
     * `system` (Standard): folgt `prefers-reduced-motion`; `voll`: Übergänge wie gestaltet;
     * `reduziert`: Übergänge mit Dauer 0 (R-PLAYER-RUHE-001).
     */
    bewegung?: Bewegung;
    /**
     * Geführter Betrieb (R-PLAYER-GEFUEHRT-001): Der Gastgeber bestimmt die Bühne. Ändert er `seite`,
     * läuft der Übergang wie nach einem Klick; Klicks werden nur gemeldet.
     */
    seite?: string;
    /** Wo Media-Overlays sitzen, in Welteinheiten (R-PLAYER-MEDIENMITTE-001). */
    medienMitte?: {
        x: number;
        y: number;
    };
    /**
     * Darsteller zur Laufzeit (R-PLAYER-LAUFZEIT-001): Die Liste ist der ganze Stand. Wer fehlt,
     * geht; wer bleibt, behält seine Lage; wer neu ist, entsteht an seinem Entstehungsort.
     */
    darsteller?: readonly LaufzeitDarsteller[];
    /**
     * Ein Gespräch (R-PLAYER-GESPRAECH-001): Der Player macht daraus Darsteller mit den Masken
     * `gespraech-…` der Aufführung. Fehlt eine Maske, meldet er es in der Konsole und zeigt kein Gespräch.
     */
    gespraech?: Gespraech;
    /**
     * Anker je Darsteller in Bildschirmkoordinaten (R-PLAYER-ANKER-001): Die Marke nächst der
     * Leselinie ersetzt den Ruhe-Ort eines freien Darstellers.
     */
    anker?: readonly DarstellerAnker[];
    /** Leselinie als Anteil der Rahmenhöhe von oben; Standard 0,4. */
    leselinie?: number;
    /** `blass`: nur Formen und Farben, mit geringer Deckkraft und ohne Schrift (R-PLAYER-STUFE-001). */
    stufe?: BuehnenStufe;
    /** Zusätzliche Klassen und Stile für den Rahmen. */
    className?: string;
    style?: CSSProperties;
}
/** Wie viel Bewegung die Bühne zeigt (R-PLAYER-RUHE-001). */
export type Bewegung = "system" | "voll" | "reduziert";
export declare function CommonUxPlayer(props: CommonUxPlayerProps): import("react/jsx-runtime").JSX.Element;
