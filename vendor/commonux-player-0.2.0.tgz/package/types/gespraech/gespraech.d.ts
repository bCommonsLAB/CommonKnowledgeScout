/**
 * Das Gespräch in neutraler Form und sein Übersetzer zu Darstellern (R-PLAYER-GESPRAECH-001 bis
 * -004). Reine Funktionen: kein Zustand, kein Bezug zu einer Anwendung. Der Gastgeber übersetzt
 * seine Daten in ein {@link Gespraech}; der Player macht daraus Darsteller zur Laufzeit.
 */
import type { ElementProps } from "../domain/scene-schema";
import type { LaufzeitDarsteller } from "../state/laufzeit-darsteller";
export type GespraechStand = "sucht" | "schreibt" | "fertig" | "fehler";
export interface GespraechBeleg {
    /** Stabil über Antworten hinweg: dasselbe Dokument bleibt derselbe Darsteller. */
    id: string;
    /** Belege desselben Dokuments sind verwandt und tragen dieselbe Farbe. */
    dokument: string;
    /** Zitatmarke; gilt nur in dieser Antwort. */
    nummer: number;
    titel: string;
    quelle?: string;
    /** Zahl der Punkte, solange gesucht oder geschrieben wird (Standard 1, höchstens 5). */
    fundstellen?: number;
    /** Farbe des Dokuments (`#RRGGBB`); ohne Angabe wählt der Übersetzer sie aus der Palette. */
    farbe?: string;
}
export interface Gespraech {
    frage: {
        id: string;
        text: string;
    };
    stand: GespraechStand;
    /** Inline-Markdown wie Textplatten. */
    antwort?: {
        text: string;
    };
    belege: GespraechBeleg[];
    /** Ohne `id` leitet der Übersetzer sie aus dem Text ab. */
    folgefragen: {
        id?: string;
        text: string;
    }[];
    /** Frühere Fragen, älteste zuerst. */
    verlauf: {
        id: string;
        kurzfrage: string;
    }[];
    /** Ansicht des Antwortblatts; `gross` zeigt mehr Text und drängt die anderen nach außen. */
    blatt?: "klein" | "gross";
    /**
     * Der Gast liest die Antwort als Seite über der Bühne: Blatt und Frage sind dann keine
     * Hindernisse, damit sich die Belege hinter ihre Zitatmarken legen können (R-PLAYER-ANKER-001).
     */
    lesen?: boolean;
}
/** Rollen der Gesprächsteile; jede hat ihre Maske in der Aufführung (R-PLAYER-GESPRAECH-003). */
export declare const GESPRAECH_ROLLEN: readonly ["frageOffen", "frage", "blatt", "blattGross", "belegPunkt", "beleg", "folgefrage", "perle"];
export type GespraechRolle = (typeof GESPRAECH_ROLLEN)[number];
/** Je Rolle die vollständige Maske. */
export type GespraechMasken = Record<GespraechRolle, ElementProps>;
/** Name der Maske je Rolle in `application.styles` der Aufführung. */
export declare const GESPRAECH_MASKEN_NAMEN: Record<GespraechRolle, string>;
/** Teile, aus denen eine Darsteller-ID entsteht. */
export type GespraechTeil = "frage" | "blatt" | "beleg" | "folgefrage" | "perle";
/** Stabile Darsteller-ID eines Gesprächsteils (R-PLAYER-GESPRAECH-002). */
export declare function gespraechDarstellerId(teil: GespraechTeil, id: string): string;
/** ID eines zusätzlichen Punkts einer Fundstelle (ab der zweiten). */
export declare function gespraechPunktId(belegId: string, n: number): string;
/** ID einer Folgefrage: die gegebene, sonst aus dem Text abgeleitet. */
export declare function folgefrageId(f: {
    id?: string;
    text: string;
}): string;
/** Sättigung und Helligkeit der Dokumentfarben (R-PLAYER-GESPRAECH-004): kräftig, Schrift bleibt lesbar. */
export declare const DOKUMENT_FARBE: {
    readonly saettigung: 0.62;
    readonly helligkeit: 0.6;
};
/**
 * Farbe eines Dokuments: dieselbe über alle Antworten (R-PLAYER-GESPRAECH-004). Ohne Palette ein
 * Farbton aus der Streuung des Namens; mit Palette deren Eintrag an der gestreuten Stelle.
 */
export declare function farbeFuerDokument(dokument: string, farben?: readonly string[]): string;
/** Höchste Zahl der Punkte je Beleg, solange gesucht wird. */
export declare const FUNDSTELLEN_MAX = 5;
/** Beim Schreiben kreisen die Punkte langsamer als beim Suchen. */
export declare const UMLAUF_BEIM_SCHREIBEN = 0.4;
export interface GespraechOptionen {
    /** Eigene Palette für Dokumente. */
    farben?: readonly string[];
}
/**
 * Übersetzt ein Gespräch in Darsteller zur Laufzeit (R-PLAYER-GESPRAECH-002). Lagen rechnet der
 * Übersetzer nicht: Der Ruhe-Ort steht in der Maske der Rolle, den Rest tut die Schwerkraft.
 */
export declare function uebersetzeGespraech(gespraech: Gespraech, masken: GespraechMasken, optionen?: GespraechOptionen): LaufzeitDarsteller[];
