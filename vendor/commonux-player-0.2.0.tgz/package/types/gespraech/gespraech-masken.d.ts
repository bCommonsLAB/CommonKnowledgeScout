import { type GespraechMasken } from "./gespraech";
export type GespraechMaskenErgebnis = {
    ok: true;
    masken: GespraechMasken;
} | {
    ok: false;
    fehlend: string[];
};
/**
 * Liest die Masken aller Rollen aus einer Aufführung (HumanUX-v2-JSON als Objekt oder Text). Fehlt
 * eine, gibt es kein Gespräch: Das Ergebnis nennt die fehlenden Namen, einen Ersatz gibt es nicht.
 */
export declare function gespraechMaskenAusSzene(szene: unknown): GespraechMaskenErgebnis;
