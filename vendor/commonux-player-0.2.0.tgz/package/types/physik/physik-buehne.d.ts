/**
 * Physik auf der Bühne (docs/specs/entity-physik.md): verbindet den reinen Physik-Kern mit den
 * Darstellern der Bühne.
 *
 * - Die Bühne meldet bei jedem Render ihre Teilnehmer: Darsteller auf oberster Ebene, die frei sind,
 *   die anderen ausweichen lassen (`solid`) oder eine Verwandtschaft tragen. Die Lage aus Maske und
 *   Phase ist der Ruhe-Ort; im Übergang folgt er dem Übergang (R-PHYSIK-BEWEGUNG-002).
 * - Ein eigener Takt rechnet in festen Schritten (R-PHYSIK-SCHRITT-001) und verschiebt freie
 *   Darsteller über die CSS-Eigenschaft `translate`, ohne dass React neu rendert
 *   (R-PHYSIK-ZEICHNEN-001). `translate` gehört zu keinem CSS-Übergang der Bühne.
 * - Ruht die Bühne, rechnet der Takt nicht weiter (R-PHYSIK-RUHE-001).
 * - Bei reduzierter Bewegung stehen freie Darsteller ohne Bewegung in ihrer Ruhelage
 *   (R-PHYSIK-REDUZIERT-001).
 * - Ein neuer freier Darsteller beginnt an seinem Entstehungsort (R-PLAYER-LAUFZEIT-002).
 * - Anker des Gastgebers ersetzen den Ruhe-Ort eines freien Darstellers (R-PLAYER-ANKER-001).
 */
import { type RefObject } from "react";
import type { ElementProps } from "../domain/scene-schema";
import { type Entstehung } from "../state/laufzeit-darsteller";
import { type AnkerEingabe } from "./anker";
import { type PhysikKoerper, type Vec } from "./physik-kern";
/** Ein Darsteller, wie die Bühne ihn der Physik meldet. */
export type PhysikTeilnehmer = Omit<PhysikKoerper, "lage" | "geschw"> & {
    /** Wo ein neuer freier Darsteller beginnt; ohne Angabe an seiner letzten Stelle, sonst am Ruhe-Ort. */
    entstehung?: Entstehung;
};
/** Woher die Anker kommen: lesen und Änderungen abonnieren (die Instanz des Players). */
export interface AnkerQuelle {
    getState: () => AnkerEingabe;
    subscribe: (beiAenderung: () => void) => () => void;
}
/** So lange gleitet ein geführter Darsteller von seinem Entstehungsort an seinen Platz (ms). */
export declare const AUFTRITT_MS = 600;
/**
 * Teilnehmer aus den Props eines Darstellers auf oberster Ebene. `null`, wenn er für die Physik
 * nichts bedeutet: geführt, nicht `solid` und ohne Verwandtschaft. Mit `immer` entsteht auch dann
 * ein Teilnehmer — für einen Darsteller, der an einem Entstehungsort auftritt.
 */
export declare function teilnehmerAusProps(id: string, p: ElementProps, worldW: number, worldH: number, immer?: boolean): PhysikTeilnehmer | null;
export interface PhysikBuehneOptionen {
    /** Der Behälter der Bühne; darin liegen die Darsteller mit `data-trace-id`. */
    containerRef: RefObject<HTMLElement | null>;
    /** Teilnehmer dieses Renders. */
    teilnehmer: readonly PhysikTeilnehmer[];
    /**
     * Lage der übrigen Darsteller auf oberster Ebene (geführt, ohne Bedeutung für die Kräfte). Wird
     * ein freier Darsteller so einer, läuft sein Versatz gegen diese Lage aus (R-PHYSIK-BEWEGUNG-002).
     */
    uebrigeOrte?: ReadonlyMap<string, Vec>;
    pxPerWorld: number;
    /** Nur in der Wiedergabe; im Bearbeiten stehen alle auf ihrem Ruhe-Ort. */
    aktiv: boolean;
    bewegungReduziert: boolean;
    /** Läuft gerade ein Übergang zwischen Bühnen oder Phasen? */
    imUebergang: boolean;
    /** Dauer des Übergangs in ms: so lange läuft der Versatz eines Darstellers aus, der geführt wird. */
    uebergangMs: number;
    /** Anker des Gastgebers (R-PLAYER-ANKER-001). */
    anker?: AnkerQuelle;
    /** Bildschirmpunkt → Welt, mit dem Rechteck des Behälters; nötig für Anker. */
    weltAusBildschirm?: (rect: DOMRectReadOnly, x: number, y: number) => Vec;
}
/**
 * Hängt die Physik an eine Bühne. Ohne freie Darsteller tut der Hook nichts (R-PHYSIK-BEWEGUNG-001-EC-01).
 *
 * Die Bühne darf `teilnehmer` noch während ihres Renders füllen: Der Hook liest die Liste erst in
 * einem Effekt nach dem Render, nie während des Renders.
 */
export declare function usePhysikBuehne(o: PhysikBuehneOptionen): void;
