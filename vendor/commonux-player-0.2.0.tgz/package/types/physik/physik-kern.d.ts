/**
 * Physik-Kern der Bühne (docs/specs/entity-physik.md).
 *
 * Eine reine Rechnung: Körper hinein, Körper nach einem festen Schritt heraus. Kein Zugriff auf
 * Bühne, DOM oder Uhr (R-PHYSIK-SCHRITT-001). Gerechnet wird in Welteinheiten (Sichtfeld 28 × 16,
 * Mitte 0/0, +y oben) und Sekunden.
 *
 * Kräfte auf einen freien Körper:
 * - Anker mit Umlauf (R-PHYSIK-ANKER-001)
 * - Abstoßung mit der Form (R-PHYSIK-ABSTOSSUNG-001)
 * - die eine Vorliebe (R-PHYSIK-VORLIEBE-001, -002)
 * - Rand (R-PHYSIK-RAND-001)
 * - Dämpfung, Höchstgeschwindigkeit und Ruhe (R-PHYSIK-RUHE-001)
 *
 * Vorlage: `Gravity.cs` (Unity, Repo `humanux`) und `Force2Body` (Babylon, Repo `human`); die
 * Abweichungen stehen in R-PHYSIK-VORLIEBE-002.
 */
import type { PhysikVorliebe } from "../domain/scene-schema";
export interface Vec {
    x: number;
    y: number;
}
/** Form eines Körpers: Kreis oder (abgerundetes) Rechteck, Maße als halbe Kanten. */
export type KoerperForm = {
    art: "kreis";
    radius: number;
} | {
    art: "rechteck";
    halbB: number;
    halbH: number;
    eckenradius: number;
};
export interface PhysikKoerper {
    id: string;
    /** Frei: Kräfte bewegen ihn. Geführt: er steht auf seinem Ruhe-Ort. */
    frei: boolean;
    /** Nur für geführte: freie Körper weichen ihm aus. */
    solid: boolean;
    /** Ruhe-Ort aus Maske und Phase. */
    ruheOrt: Vec;
    lage: Vec;
    /** Welteinheiten je Sekunde. */
    geschw: Vec;
    form: KoerperForm;
    /** `sizeX × sizeY × weight` (R-PHYSIK-MASSE-001). */
    masse: number;
    /** Umlauf −1 … 1, positiv gegen den Uhrzeigersinn. */
    umlauf: number;
    kin: string;
    vorliebe: {
        art: PhysikVorliebe;
        /** Verwandtschaft des Ziels; leer = die eigene. */
        zu: string;
        staerke: number;
        reichweite: number;
        abstand: number;
    };
}
export interface PhysikRand {
    minX: number;
    maxX: number;
    minY: number;
    maxY: number;
}
export interface PhysikWelt {
    koerper: readonly PhysikKoerper[];
    rand: PhysikRand;
    /** Wie viele Schritte in Folge sich nichts mehr bewegt hat (R-PHYSIK-RUHE-001). */
    ruheSchritte: number;
}
/** Logische Fläche der Bühne (R-PHYSIK-RAND-001). */
export declare const BUEHNEN_RAND: PhysikRand;
/**
 * Feste Werte der Hausregeln (R-PHYSIK-HAUSREGELN-001). Startwerte nach der Probe in P1
 * (Q-physik-03); die Aufführung stellt sie nicht ein.
 */
export declare const PHYSIK_WERTE: {
    /** Fester Schritt in Sekunden (R-PHYSIK-SCHRITT-001). */
    readonly dt: number;
    /** Federstärke des Ankers. */
    readonly kAnker: 4;
    /** Stärke der Vorliebe je Masse des Ziels. */
    readonly g: 2;
    /** Kleinster Abstand in der Formel der Vorliebe. */
    readonly dMin: 0.5;
    /** Höchste Beschleunigung aus einer Vorliebe. */
    readonly aVorliebeMax: 20;
    /** Steifigkeit der Abstoßung (Beschleunigung je Welteinheit Überlappung). */
    readonly kAbstoss: 400;
    /** Spalt, den Körper zueinander halten. */
    readonly spalt: 0.1;
    /** Steifigkeit des Rands. */
    readonly kRand: 400;
    /** Dämpfung je Schritt. */
    readonly daempfung: 0.92;
    /** Höchstgeschwindigkeit in Welteinheiten je Sekunde. */
    readonly vMax: 12;
    /** Kleinste Masse in der Rechnung, damit leichte Körper stabil bleiben. */
    readonly masseMin: 0.05;
    /** Höchste Lagekorrektur je Schritt beim Auflösen von Überlappungen (Welteinheiten). */
    readonly korrekturMax: 0.05;
    /** Durchgänge der Lagekorrektur je Schritt. */
    readonly korrekturDurchgaenge: 3;
    /** Unter dieser Geschwindigkeit (Welteinheiten je Sekunde) gilt ein Körper als still. */
    readonly ruheV: 0.05;
    /** Eine halbe Sekunde still: die Bühne ruht. */
    readonly ruheSchritte: 30;
    /** Nullstelle von 1 + 2·ln(q)/q: Gleichgewicht beim Wunschabstand (R-PHYSIK-VORLIEBE-002). */
    readonly q0: 0.703467;
};
/** Wie weit eine Form vom Mittelpunkt in Richtung `n` (Einheitsvektor) reicht. */
export declare function ausdehnung(form: KoerperForm, n: Vec): number;
/**
 * Beschleunigung aus einer Vorliebe auf einen Körper mit Masse `m` durch ein Ziel mit Masse `mt`
 * im Abstand `d`, als Betrag in Richtung des Ziels (negativ = weg). R-PHYSIK-VORLIEBE-002; die
 * Masse des Körpers kürzt sich aus `F / m`.
 */
export declare function vorliebeBetrag(art: PhysikVorliebe, staerke: number, mt: number, d: number, abstand: number): number;
/**
 * Ein fester Schritt (R-PHYSIK-SCHRITT-001). Liefert eine neue Welt; die alte bleibt unverändert.
 * Geführte Körper stehen auf ihrem Ruhe-Ort. `ohneUmlauf` für reduzierte Bewegung
 * (R-PHYSIK-REDUZIERT-001).
 */
export declare function schritt(welt: PhysikWelt, optionen?: {
    ohneUmlauf?: boolean;
}): PhysikWelt;
/** Ruht die Bühne? Dann rechnet der Player nicht weiter (R-PHYSIK-RUHE-001). */
export declare function ruht(welt: PhysikWelt): boolean;
/**
 * Rechnet ohne Umlauf, bis die Welt ruht oder `maxSchritte` erreicht sind — die Ruhelage bei
 * reduzierter Bewegung (R-PHYSIK-REDUZIERT-001).
 */
export declare function ruhelage(welt: PhysikWelt, maxSchritte?: number): PhysikWelt;
