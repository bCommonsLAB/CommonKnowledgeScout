/**
 * Anker vom Gastgeber (R-PLAYER-ANKER-001, -002): Der Gastgeber nennt je Darsteller Marken in
 * Bildschirmkoordinaten, etwa die Zitatmarken eines Belegs im Text. Die nächste Marke an der
 * Leselinie ersetzt den Ruhe-Ort des freien Darstellers; die Schwerkraft führt ihn dorthin.
 *
 * Reine Rechnung; den Zustand (welche Marke gilt) hält die Anbindung an die Bühne.
 */
import { type KoerperForm, type PhysikRand, type Vec } from "./physik-kern";
/** Eine Marke in Bildschirmkoordinaten (wie `clientX`/`clientY`). */
export interface AnkerMarke {
    /** Bleibt gleich, solange es dieselbe Marke ist — daran erkennt der Player sie beim Scrollen wieder. */
    key: string;
    x: number;
    y: number;
}
export interface DarstellerAnker {
    /** ID des Darstellers. */
    id: string;
    /** Seine Marken; ohne Marken gilt der Ruhe-Ort aus der Maske. */
    marken: readonly AnkerMarke[];
}
/** Was der Gastgeber setzt. */
export interface AnkerEingabe {
    anker: readonly DarstellerAnker[];
    /** Leselinie als Anteil der Höhe des Rahmens, von oben (Standard 0,4). */
    leselinie: number;
}
export declare const ANKER_LESELINIE = 0.4;
/**
 * Schwelle in Bildpunkten (R-PLAYER-ANKER-002): Eine andere Marke übernimmt erst, wenn sie der
 * Leselinie um mehr als diesen Betrag näher ist als die geltende.
 */
export declare const ANKER_SCHWELLE_PX = 24;
/**
 * Wählt die Marke, die der Leselinie am nächsten ist. Die bisher geltende bleibt, solange keine
 * andere um mehr als die Schwelle näher ist — so springt ein Darsteller nicht zwischen zwei fast
 * gleich nahen Marken hin und her.
 */
export declare function waehleMarke(marken: readonly AnkerMarke[], leselinieY: number, bisherKey: string | null, schwellePx?: number): AnkerMarke | null;
/**
 * Hält einen Ankerort so im sichtbaren Teil der Bühne, dass die ganze Form darin bleibt. Eine Marke
 * außerhalb des Bilds zieht den Darsteller also nur bis an den Rand (R-PLAYER-ANKER-001).
 */
export declare function ankerOrtImBild(ort: Vec, form: KoerperForm, sichtbar: PhysikRand): Vec;
