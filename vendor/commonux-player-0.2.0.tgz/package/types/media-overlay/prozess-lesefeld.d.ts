/**
 * Lesefeld für den Beschreibungstext eines Prozessschritts — steht direkt auf der Bühne
 * (kein Klick-Overlay). Vorbild ist der Methoden-Lesetext: Einleitung fett, darunter der Rest.
 *
 * - Zugeklappt: höchstens {@link LESEFELD_ZEILEN} Zeilen, bei Überlänge die Mehr-lesen-Blase.
 * - Aufgeklappt: ganzer Text, das Feld scrollt in seiner Box.
 * - Kopieren und Maximieren oben rechts; Maximieren öffnet das Leseblatt in Bühnenfarbe.
 * - Zugeklappt stehen Überschrift (eigener Darsteller, `titelId`) und Text zusammen senkrecht
 *   mittig auf der Bühne; beim Aufklappen rücken beide an ihre autorierte Position hoch.
 * - Den Anteil der Überschrift trägt die Bühne (`onVersatz` → {@link mitLesefeldVersatz}), damit
 *   sie im Bühnenwechsel in einem Zug fliegt.
 *
 * R-PROZESS-TXT-LESEFELD-001, R-PROZESS-TXT-LESEFELD-002, R-PROZESS-TXT-LESEFELD-003.
 */
import { type RefObject } from "react";
import { type RootObject } from "../domain/scene-schema";
/** Sichtbare Zeilen im zugeklappten Lesefeld. */
export declare const LESEFELD_ZEILEN = 5;
/** Höhe (px) von `zeilen` Zeilen Fließtext · Text im Bühnenmaß. */
export declare function lesefeldKlappHoehePx(pxPerWorld: number, zeilen?: number): number;
/**
 * Versatz nach unten, der den Block [Titel-Oberkante … Text-Unterkante] senkrecht auf die
 * Bühnenmitte setzt. Nie negativ — der Block rückt nur nach unten, nie über die autorierte Lage.
 */
export declare function ruheVersatzZurMittePx(blockObenPx: number, blockUntenPx: number, mittePx: number): number;
/**
 * R-PROZESS-TXT-LESEFELD-003: rechnet den Mitte-Versatz in die Lage der Überschriften ein — je
 * Bühne nur für die Überschrift des dortigen Lesefelds, in allen drei Phasen. `versatzWelt` ist
 * nach der ID des Lesefeld-Darstellers geschlüsselt (Welt-Einheiten, positiv = nach unten).
 * Weil der Versatz so zur Lage auf der Bühne gehört, führt ihn der Bühnenwechsel mit.
 */
export declare function mitLesefeldVersatz(doc: RootObject, versatzWelt: Readonly<Record<string, number>>): RootObject;
/**
 * Autorierte Oberkante (Ebenen-px, wie `style.top` minus halbe Höhe) der Überschrift auf der Bühne
 * des Lesefelds `feldId` — Messbasis für den Versatz, unabhängig davon, wo die Überschrift gerade
 * im Flug steht (R-PROZESS-TXT-LESEFELD-003).
 */
export declare function lesefeldTitelObenPx(doc: RootObject | null | undefined, feldId: string, titelId: string, pxPerWorld: number): number | undefined;
export declare function ProzessLesefeld({ einleitung, volltext, pxPerWorld, buehneRef, farbe, titelId, titelObenPx, zentrieren, onVersatz, }: {
    einleitung: string;
    volltext?: string;
    pxPerWorld: number;
    /** Bühnen-Container — seine Farbe wird die Blattfarbe des Readers. */
    buehneRef: RefObject<globalThis.Element | null>;
    farbe?: string;
    /** Darsteller der Überschrift — rückt zugeklappt mit in die Mitte. */
    titelId?: string;
    /** Autorierte Oberkante der Überschrift auf dieser Bühne (Ebenen-px), {@link lesefeldTitelObenPx}. */
    titelObenPx?: number;
    /** Aus (Editor): Block bleibt an seiner autorierten Lage (R-PROZESS-TXT-LESEFELD-002). */
    zentrieren?: boolean;
    /** Meldet den Versatz (px) — die Bühne rückt die Überschrift damit (R-PROZESS-TXT-LESEFELD-003). */
    onVersatz?: (px: number) => void;
}): import("react/jsx-runtime").JSX.Element;
