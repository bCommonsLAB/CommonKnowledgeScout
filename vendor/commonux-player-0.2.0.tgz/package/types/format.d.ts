/**
 * Eingang `@commonux/player/format`: Schema, Compiler und Leser des Szenenformats — ohne React.
 * Für Server-Code und für Gastgeber, die eine Aufführung nur lesen oder prüfen
 * (R-PLAYER-EINGANG-001, docs/specs/entity-player.md).
 */
export { readSceneFromJson, readSceneFromJsonText, SceneParseError } from "./io/scene-reader";
export { compileHumanUxToRootObject, isHumanUxV2Raw, parseHumanUxRootObject } from "./domain/humanux-compiler";
export type { App, EditPhase, Element, ElementProps, Page, RootObject, SceneGroupNode, SceneNode, } from "./domain/scene-schema";
export type { HumanUxEntityDefinition, HumanUxGroupDefinition, HumanUxRootObject, HumanUxView, } from "./domain/humanux-authoring-schema";
export { FUNDSTELLEN_MAX, DOKUMENT_FARBE, GESPRAECH_MASKEN_NAMEN, GESPRAECH_ROLLEN, farbeFuerDokument, folgefrageId, gespraechDarstellerId, gespraechPunktId, uebersetzeGespraech, type Gespraech, type GespraechBeleg, type GespraechMasken, type GespraechOptionen, type GespraechRolle, type GespraechStand, type GespraechTeil, } from "./gespraech/gespraech";
